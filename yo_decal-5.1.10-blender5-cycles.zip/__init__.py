# -*- coding: utf-8 -*-
# ============================================================
#  曲面贴花 SurfDecal v1.1.0
#  实体网格贴花插件(非材质方案) · Blender 4.0.2+
#
#  技术路线(参考业界成熟做法):
#   · DECALmachine / Topology Guides 的网格贴花范式:
#       细分(Subdivision SIMPLE) → 收缩包裹(Shrinkwrap, 表面上方悬浮)
#       → [可选 实体化(Solidify)] → 法线融合(Data Transfer 自定义法线)
#   · 法线融合让贴花继承目标曲面的着色, 视觉上"长"在表面上
#   · 目标为纯平直着色(flat shading)时自动跳过法线融合(DM 同款策略)
#   · 兼容性: 4.0.x 需要 use_auto_smooth=True 才能显示自定义法线;
#     4.1+ 该属性已移除, 自定义法线默认生效 —— 本插件按版本自动处理
#
#  导入(v1.1 新增):
#   · SVG: 调用 Blender 自带 SVG 曲线导入器(未启用时自动启用),
#     转网格 → 合并 → 归一化尺寸 → 可选自动吸附到目标
#   · PNG/JPG 两种方式:
#     - 贴图面片(默认): 按图像比例生成细分面片, 建立
#       图像→BaseColor/Alpha 透明材质 —— 载体是实体网格, 形状由alpha呈现,
#       物体级关闭投影, 背面剔除, 混合/阴影字段按版本 hasattr 兼容
#     - 矢量化轮廓(纯几何, 无需材质): 先矢量化 ——
#     alpha/明度阈值 → Marching Squares 提取轮廓(带线性插值)
#     → RDP 简化 → 2D 曲线填充(偶奇规则自动处理孔洞) → 转网格
#   · v1.1.1: 转换/合并一律走数据API(new_from_object + bmesh),
#     不依赖操作符上下文 —— convert/join 的 poll 要求"活动base且被选中",
#     temp_override 覆盖不到, 在文件浏览器上下文中执行必然失败
#   · v1.3.1: 交互投放锁定视口区域并用窗口坐标换算(鼠标滑到面板/
#     视口外不再出错); 每次确认手动推送撤销步(逐张可Ctrl+Z);
#     导入后进入投放改为定时器延迟, 等文件浏览器关闭后再启动modal,
#     规避跨窗口拉起modal+UNDO快照造成的 ID user decrement 报错刷屏
#   · v1.4.0: 支持集合实例(Group Pro类编组)作为目标 —— 命中实例时按
#     实例矩阵把贴花换算进源集合空间并链接到源集合, 所有实例同步显示;
#     大场景防卡: 目标求值面数超上限时预览阶段隐藏吸附/法线修改器
#     (确认后生效); 撤销改为结束时一次推送; 最近表面对齐改用求值网格
#   · v1.5.0: 极简目标流 —— 导入前选中要吸附的物体即可(普通网格或
#     Group Pro式组实例空物体), 导入后直接吸附(新默认); 组实例改为
#     确认/导入时一次性烘焙贴合并父级到实例空物体, 不再改动集合链接
#     (修复"物体不在视图层无法隐藏"崩溃); 隐藏/选择操作全部加保护
#   · v1.6.0: 移除"目标表面"栏与指定按钮 —— 目标恒为所选/活动物体;
#     导入吸附的落点锚定到目标原点的最近表面(之后G移动可在表面滑动)
#   · v1.7.0: 新增[缩放贴花] —— 作用于底面网格而非物体缩放(物体保持
#     缩放1), 先吸收已有的S缩放, 放大时自动提升细分级别保证曲面贴合;
#     直接按S会同时放大悬浮间距并稀释顶点密度, 曲面上会变形
#   · v1.7.1: [切换吸附方式]一键切换 最近表面点⇄沿法线投射(按活动贴花
#     当前方式统一翻转所选); 最近表面点在拐角处有歧义, 相邻顶点会吸到
#     不同侧的面导致破面折叠 —— 跨强曲率的贴花切投射+双向通常可修复
#   · v2.0.0: 双轨发布 —— 本单文件为 legacy 版(4.0.2+, 在 5.x 也可用
#     "Install legacy Add-on" 安装); 另有 Extension 包(blender_manifest
#     .toml, 供 4.2+/5.2 LTS 在 获取扩展→从磁盘安装); SVG 导入兜底同时
#     尝试 legacy 模块名与 bl_ext 扩展命名空间, 均失败时提示到扩展平台
#   · v2.1.0: 贴花缩放改为逐张记录(物体属性"贴花缩放", 面板直接拖动,
#     互不串值; 缩放按钮改为批量乘法且不再继承上次系数);
#     投放所选物体保留原有绕法线旋转与整套吸附设置(投影/表面点、
#     悬浮间距、细分、厚度、法线融合), 不再被面板参数重置
#   · v2.2.0: 忽略布尔切割体(默认开) —— 投放射线穿过线框/边界框显示
#     或被布尔修改器引用(含集合操作数)的物体, 直接命中切割后的表面;
#     目标解析与组实例内的最近面搜索同样避开切割体
#   · v2.3.0: 硬边贴花逻辑 —— 投射模式在投射深度=0时按贴花包围尺寸
#     自动限深: 溢出硬边的部分不再射穿开口贴到后方表面(分裂), 而是
#     保持与命中面共面悬空; 新建默认改为投射(最近表面点跨硬边会折叠);
#     固化新增可选[裁掉未贴合面], 一键清除悬空溢出
#   · v2.4.0/2.6.0: [硬边包裹贴合] —— 测地线展开(v2.6.0重写):
#     在目标三角面上沿直线行走, 跨边时按共享边把方向展开到邻面,
#     弧长精确保持 → 90°硬边正好折过去, 曲面同理。各顶点独立求解,
#     不再有"最近点在凸棱处病态 → 整张塌成一条线"的失败模式。
#     烘焙操作: 细分先被应用、吸附修改器被移除(形状即结果),
#     v2.7.0 增加变形裁剪: 三面交汇的角点处总角≠360°(高斯曲率集中),
#     平面铺到锥点必然撕裂或重叠 —— 数学必然, 非缺陷; 故按边长拉伸比
#     裁掉超差的面(棱边折叠区拉伸≈1不受影响), 效果同真实贴纸剪口。
#     v2.8.0: ①锚点改用"沿贴花-Z射线命中的面"(退化时才回落最近点) ——
#     之前用最近点, 贴花骑在棱上时最近点落在棱线上, 取到哪一侧全凭运气,
#     切平面框架随之偏转, 图案看起来是斜的; ②框架改用最小旋转把贴花Z
#     转到表面法线(与投影同为正交单位框架, 但忠实保留贴花自身转角);
#     v2.10.0: 折缝切分 —— 跨凸角的四边形是一条弦, 必然从角内部穿过
#     (最深约 格子边长/4, 远大于悬浮间距), 整排会沉入实体被挡住, 看起来
#     像"少一条边"。故在折缝处二分定位并切开边, 新顶点正好落在棱线上、
#     沿两面法线的角平分线抬升 —— 每个面都完整落在单一平面上, 不再跨角。
#     v2.10.1: 切边后连接同面内的缝点(等价编辑模式J键), 折缝成为真实
#     边环 —— edge_split只插点不分面, 跨缝面是含缝点的五/六边形; 折缝
#     与网格线平行时其三角化碰巧无害, 斜穿网格时三角扇会跨过折线,
#     每个三角又是跨角的弦, 呈一排锯齿(诊断特征: 顶点增加而面数不变)。
#     v2.10.2: 折缝穿过既有顶点的退化处理 —— 偶数网格正对棱居中摆放时
#     折缝恰好压在网格线上, 线上顶点落面随机、切分在两侧列乱切成一条
#     一格宽的裂带; 现改为切点距端点6%以内时吸附既有顶点(不切分),
#     折缝沿既有边时跳过; 缝点抬升量修正为 offset/cos(半折角), 落在与
#     两面等距的悬浮壳上(原先缝排下陷约30%)。
#     v2.9.0: 包裹后给折角超阈值的边打硬边标记 —— 包裹后网格自身带有
#     真实折角, 全平滑着色会把折缝两侧法线平均掉, 视觉上是一条暗带,
#     很容易误判为"裂开一条缝"(几何其实完好: 面数不变、拉伸1.00)。
#     ③裁剪的压缩下限独立且放宽到0.35 —— 跨90°折的格子弦长天然是路径长
#     的0.707倍, 按1/容差判定会把折缝整排误裁; ④输出拉伸/压缩诊断数值。
#     法线融合/实体化保留为活修改器;
#     包裹前的网格与吸附设置会备份为数据块, 随时[还原包裹];
#     再次包裹会自动先还原 —— 移动位置后重新包裹即可(非破坏工作流)
#   · v2.11.0: 污迹系统 —— 共享节点组 SD_污迹 + 目标物体的Object坐标:
#     目标材质与贴花材质采样同一个组、同一坐标空间, 污迹跨贴花边界连续
#     (脏纹从墙面直接流进贴花)。可影响 基础色/粗糙度/Alpha磨损。
#     目标材质里已有 SD_污迹 组时自动复用该组并同步参数, 不重复注入。
#     v2.11.1: 污迹可填自定义贴图 —— 组内 图像纹理(BOX三平面投影, 走同一
#     Object坐标), 填了贴图就用贴图、留空用程序化噪波; 因组为共享数据块,
#     贴图对目标与贴花自动是同一张同一空间, 无需分别设置。
#   · v2.12.0: 污迹以"表面"为单位 —— 选中墙面(或其上任一张贴花)即可把
#     该目标上的全部贴花一起处理(默认); 另有 所选贴花 / 场景全部 两档。
#     之前只处理选中的那一张, 同一面上的其他贴花不受影响。
#   · v2.13.0: 污迹通道重构 —— 粗糙度为主通道(灰尘/磨损的物理表现主要在
#     粗糙度), 基础色降为可选且默认关闭, Alpha磨损独立; 每通道各有影响量,
#     量为0时该通道节点不创建/自动移除。包裹的细分改用bmesh就地细分,
#     不再调 modifier_apply —— 贴花上还有阵列/镜像时后者会把它们一起烘进去。
#   · v2.14.0: 污迹坐标空间可选, 默认世界坐标 —— Object坐标 =
#     世界坐标×目标矩阵逆, 目标有未应用的缩放会把污迹同比拉歪, 未应用的
#     旋转会让"竖向条痕"跟着物体局部Z而非重力方向; 世界坐标对二者免疫,
#     且阵列/实例的每个副本因世界位置不同而自然获得不同污迹。
#     Object模式保留(随物体移动), 并按目标缩放做补偿。
#     另加[应用目标旋转缩放]: 应用后自动还原子级世界变换, 贴花不会跑位;
#     非均匀缩放也会破坏包裹的弧长计算, 这个按钮同时解决那个问题。
#   · v2.15.0: 自适应细分 —— 在贴花覆盖范围内射线采样目标法线, 按最大
#     法线偏差定级: 平面(<3°)给0级(576面→36面), 缓曲1级, 中曲2级,
#     强曲/硬边3~4级, 并以面板"细分级别"为上限。采样命中不足时回落为
#     面板值(宁可多面也不欠贴合)。级别会记在贴花上, 面板可见。
#   · v2.16.0: 污迹三项修正 —— ①参数与贴图实时生效(改动即推送到共享组与
#     所有已注入材质, 不必再点应用); ②程序化噪波频率修正(Detail 10→4,
#     Distortion 0.6→0), 原设置在常用尺度下全是高频碎纹, 糊成一片灰白;
#     ③新增[预览污迹]: 临时接一个自发光输出, 无光照直看污迹本身的灰度,
#     再点一次恢复 —— 判断图案对不对不用手动连线。
#   · v2.16.1: "使用贴图"开关改按组内图像节点的实际内容判断 —— 原先按
#     面板槽位判断, 在节点编辑器里手动填图时槽位仍为空, 开关为0, 于是
#     "组里有图却仍走噪波"; 同步也不再用空槽位覆盖已填的图, 而是把手填的
#     图采纳回面板。清空改由[回到程序化污迹]显式执行。
#   · v2.17.0: 坐标空间新增"目标包围盒归一化"(默认)并可选平面投影 ——
#     BOX三平面是按坐标空间轴向投影的: 世界坐标下, 墙一旦不是轴对齐
#     (旋转过或弧面)纹理就被斜投、按1/cos拉伸并在轴切换处涂抹。
#     归一化局部空间把目标包围盒映射到0~1, 并自动把最薄的轴旋成投影法向,
#     配平面投影即"正面平铺到墙面", 不受目标缩放与旋转值影响。
#   · v2.17.1: 默认回到三平面投影, 归一化按"等比"处理 —— 平面投影只用
#     坐标XY, 只在垂直于薄轴的两个面成立, 其余四面纹理仅沿一个方向变化,
#     呈横向条带(立方体三边等长时"薄轴"任取, 正面也会中招);
#     且三平面要求各轴等比, 原先的逐轴归一化会让各面纹理比例不同。
#     现在: 三平面=等比缩放不置换; 平面=逐轴归一化+薄轴置换(仅墙/板)。
#   · v2.17.2: 坐标链路纳入实时同步 —— 之前改"投影方式/坐标空间"只更新了
#     图像节点的投影, 归一化Mapping要等点[应用污迹]才重算; 于是出现
#     "面板显示三平面、实际坐标仍是平面用的逐轴归一化"的错配, 各轴纹理
#     比例差数倍, 表现为被拉伸的竖条纹。目标物体名记在组节点上以便复算。
#   · v2.18.0/2.18.1: 坐标空间新增"目标UV(传递)" —— 即 DECALmachine 所谓的
#     texture matching: 用 Data Transfer 把目标UV层传到贴花, 贴花以墙面
#     自己的UV采样污迹, 逐点1:1对应, 无投影推算故无拉伸/条纹。贴花自身UV
#     更名为 SD_DecalUV 并显式绑定, 免被同名传入层顶替。
#     但布尔/阵列做出的硬表面常有退化UV(面在UV里塌成线或零面积), 用它采样
#     会把纹理沿一条线拉满整面(表现: 只有一个面正常、其余全是竖条纹)。
#     故 v2.18.1 加UV体检: 按UV面积/3D面积比统计退化占比, 超5%即自动回落到
#     包围盒归一化+三平面, 并报出原因; 诊断也会输出UV体检结果。
#   · v2.17.3: "污迹缩放"的单位随坐标空间而变, 极易误解 ——
#     归一化空间下它是"跨整个目标平铺几次"(0.5=只显示半张图, 被放大两倍多,
#     呈巨大色块); Object/世界空间下它是"每米平铺几次"。默认值提到4.0,
#     并在面板实时显示换算结果(跨目标几次 / 多少米一次)。
#   · v3.2.x: 匹配属性组补回(删污迹时连带丢失, 会导致匹配报错);
#     UV传递配置顺序修正并加校验回写(写 use_poly_data 会清空 data_types_loops,
#     致修改器"看起来正常却不传数据", 贴花移动时UV不再更新);
#     粗糙度偏移默认改0(精确匹配优先); 移除[修复UV传递]按钮 ——
#     修复逻辑已内建, 重跑[匹配目标材质]即可修好既有场景。
#   · v2.5.0: 贴花库 —— 偏好设置里指定文件夹, N面板预览图网格中挑选
#     曾导入/使用过的贴花(本文件已用图像 + 库文件夹内 图片/SVG),
#     一键放置; [收录到库]把本文件贴花图像复制进库文件夹
#
#  用法:
#   1. N 面板 → "贴花" 页签; 目标恒为所选/活动物体, 无需指定
#   2. [交互投放贴花]: 表面移动实时预览, 滚轮缩放, R 旋转,
#      左键确认, Shift+左键连续投放, 右键/Esc 结束
#   3. [投放所选物体]: 把活动网格(如刚导入的图形)当贴花交互投放,
#      Shift+左键连续盖章(复制体共享网格数据)
#   4. [吸附所选到目标]: 网格/曲线/文字一键吸附(曲线/文字自动转网格),
#      默认先对齐到最近表面点(位置贴合+朝向沿法线, 保留自转)
#   5. [导入为贴花]: 导入前先选中要吸附的物体(网格或组实例),
#      SVG / PNG/JPG 导入后自动吸附上去; 也可选进入交互投放/仅导入
#   6. [缩放贴花]: 选中贴花后在"所选贴花"区使用, F9面板拖动系数;
#      共享网格的盖章副本会先独立化再缩放
#   6b.[硬边包裹贴合] / [还原包裹]: 折过硬边与撤回, 可反复;
#      [贴花库]: 选库中贴花 → 放置(按"导入后"设置吸附/投放)
#   7. [固化为独立实体]: 应用全部贴花修改器, 烘焙为独立网格,
#      解除与目标的父级, 并把旋转/缩放烘入网格(外观不变,
#      物体变换归为 旋转0/缩放1, 之后可自由应用变换), 均可开关
# ============================================================

# Extension 版: 元数据由 blender_manifest.toml 提供

import math
import json
import os
import re as R
import shutil
from pathlib import Path
from types import SimpleNamespace

import bpy
import bpy.utils.previews
import bmesh
import numpy as np
from bpy.app.handlers import persistent
from mathutils import Vector, Matrix, Quaternion, Euler
from bpy_extras import view3d_utils
from bpy_extras.io_utils import ImportHelper

# ---------- 常量 ----------
MOD_PREFIX  = "SD_"
MOD_SUBSURF = "SD_细分"
MOD_SHRINK  = "SD_吸附"
MOD_SOLID   = "SD_实体化"
MOD_NORMAL  = "SD_法线融合"
MOD_EDGE_FIELD = "SD_几何边缘场"
SD_VERSION  = (5, 1, 10)                 # 与扩展 manifest 版本保持一致;
                                        # 扩展版无 bl_info, 代码只引用此常量
KEY_TARGET  = "surfdecal_target"
KEY_STATE   = "sd_state"        # LIVE / GEOMETRY_FROZEN(§2.2)
KEY_DECAL_ID = "sd_decal_id"    # 持久贴花ID, 与父子关系无关
KEY_TARGET_ID = "sd_target_id"  # 持久目标ID, 父级被解除后仍能找回
KEY_REST    = "surfdecal_rest_mesh"     # 包裹前网格备份数据块名
KEY_REST_P  = "surfdecal_rest_params"   # 包裹前吸附设置

_lib_previews = None                    # bpy.utils.previews 集合
_lib_items = []                         # 枚举项缓存(必须保持引用防GC)


# ============================================================
#  纯计算函数(不依赖 bpy, 便于单测)
# ============================================================

def build_tri_adjacency(T):
    """三角网格半边邻接。局部边 i = (i, (i+1)%3)。
    返回 (邻接三角形, 邻接局部边), 形状 (nt,3), -1 表示边界。"""
    nt = len(T)
    a = np.minimum(T, np.roll(T, -1, axis=1)).reshape(-1)
    b = np.maximum(T, np.roll(T, -1, axis=1)).reshape(-1)
    order = np.lexsort((b, a))
    sa, sb = a[order], b[order]
    same = (sa[1:] == sa[:-1]) & (sb[1:] == sb[:-1])
    idx = np.nonzero(same)[0]
    nbr = np.full(nt * 3, -1, dtype=np.int64)
    h1, h2 = order[idx], order[idx + 1]
    nbr[h1] = h2
    nbr[h2] = h1
    has = nbr >= 0
    nbr_tri = np.where(has, nbr // 3, -1)
    nbr_edge = np.where(has, nbr % 3, -1)
    return nbr_tri.reshape(nt, 3), nbr_edge.reshape(nt, 3)


def region_triangles(V, T, center, radius):
    """只保留贴花附近的三角形(大场景加速)。返回 (V2, T2)。"""
    dv = V - np.asarray(center, dtype=np.float64)
    keep_v = np.einsum("ij,ij->i", dv, dv) <= radius * radius
    keep_t = keep_v[T].any(axis=1)
    if not keep_t.any():
        return V, T
    T2 = T[keep_t]
    used = np.unique(T2)
    remap = np.full(len(V), -1, dtype=np.int64)
    remap[used] = np.arange(len(used), dtype=np.int64)
    return V[used], remap[T2]


def tri_cache(Vl, Tl):
    """预计算每三角形几何(纯Python元组, 供热循环高速访问)。
    布局: 0-2 A, 3-5 u, 6-8 v, 9-11 n, 12 den, 13-15 单位法线, 16-18 质心。"""
    out = []
    for t in Tl:
        ax, ay, az = Vl[t[0]]
        bx, by, bz = Vl[t[1]]
        cx, cy, cz = Vl[t[2]]
        ux, uy, uz = bx - ax, by - ay, bz - az
        vx, vy, vz = cx - ax, cy - ay, cz - az
        nx = uy * vz - uz * vy
        ny = uz * vx - ux * vz
        nz = ux * vy - uy * vx
        den = nx * nx + ny * ny + nz * nz
        L = math.sqrt(den) if den > 0.0 else 1.0
        if den <= 1e-30:
            den = 1e-30
        out.append((ax, ay, az, ux, uy, uz, vx, vy, vz, nx, ny, nz, den,
                    nx / L, ny / L, nz / L,
                    (ax + bx + cx) / 3.0, (ay + by + cy) / 3.0,
                    (az + bz + cz) / 3.0))
    return out


def trace_geodesic(tri, p, d, dist, Vl, Tl, nbrT, nbrE, TC, max_cross=256):
    """沿三角网格表面走直线(测地线): 面内直行, 跨边时把方向按共享边展开到
    邻面 —— 硬边处正好折过去, 弧长精确保持(贴纸包箱角的行为)。
    tri 起始三角形; p 起点; d 单位方向; dist 弧长。
    返回 (终点, 终点所在三角形)。遇边界(开口/洞)则在该面内直飞出去。"""
    px, py, pz = p
    dx, dy, dz = d
    remaining = float(dist)
    skip = -1
    tiny = 1e-9 * max(1.0, float(dist))
    stall = 0
    for _ in range(max_cross):
        c = TC[tri]
        wx, wy, wz = px - c[0], py - c[1], pz - c[2]
        ux, uy, uz = c[3], c[4], c[5]
        vx, vy, vz = c[6], c[7], c[8]
        nx, ny, nz, den = c[9], c[10], c[11], c[12]
        # 重心坐标: β=((w×v)·n)/den, γ=((u×w)·n)/den, α=1-β-γ
        beta = ((wy * vz - wz * vy) * nx + (wz * vx - wx * vz) * ny
                + (wx * vy - wy * vx) * nz) / den
        gamma = ((uy * wz - uz * wy) * nx + (uz * wx - ux * wz) * ny
                 + (ux * wy - uy * wx) * nz) / den
        alpha = 1.0 - beta - gamma
        # 方向的重心变化率(d为单位向量 → 参数t即真实距离)
        db = ((dy * vz - dz * vy) * nx + (dz * vx - dx * vz) * ny
              + (dx * vy - dy * vx) * nz) / den
        dg = ((uy * dz - uz * dy) * nx + (uz * dx - ux * dz) * ny
              + (ux * dy - uy * dx) * nz) / den
        da = -db - dg
        best_t = -1.0
        best_e = -1
        for x, r, le in ((alpha, da, 1), (beta, db, 2), (gamma, dg, 0)):
            if le == skip or r >= -1e-15:
                continue
            t = -x / r
            if t < -1e-9:
                continue
            if best_e < 0 or t < best_t:
                best_t, best_e = t, le
        if best_e < 0 or best_t >= remaining:   # 本面内走完
            return ((px + dx * remaining, py + dy * remaining,
                     pz + dz * remaining), tri)
        if best_t <= tiny:                      # 贴着顶点走: 防打转
            stall += 1
            if stall > 8:
                return ((px + dx * remaining, py + dy * remaining,
                         pz + dz * remaining), tri)
        else:
            stall = 0
        px += dx * best_t
        py += dy * best_t
        pz += dz * best_t
        remaining -= best_t
        nxt = nbrT[tri][best_e]
        if nxt < 0:                             # 边界: 直飞出去
            return ((px + dx * remaining, py + dy * remaining,
                     pz + dz * remaining), tri)
        skip = nbrE[tri][best_e]                # 邻面中的入边(换面前取)
        i0 = Tl[tri][best_e]
        i1 = Tl[tri][(best_e + 1) % 3]
        v0 = Vl[i0]
        v1 = Vl[i1]
        ex, ey, ez = v1[0] - v0[0], v1[1] - v0[1], v1[2] - v0[2]
        el = math.sqrt(ex * ex + ey * ey + ez * ez)
        if el <= 1e-20:
            return ((px, py, pz), tri)
        ex, ey, ez = ex / el, ey / el, ez / el
        dpar = dx * ex + dy * ey + dz * ez      # 沿棱分量守恒 = 展开
        pp = 1.0 - dpar * dpar
        pp = math.sqrt(pp) if pp > 0.0 else 0.0
        cn = TC[nxt]
        gx, gy, gz = cn[16] - px, cn[17] - py, cn[18] - pz
        s = gx * ex + gy * ey + gz * ez
        ix, iy, iz = gx - s * ex, gy - s * ey, gz - s * ez
        il = math.sqrt(ix * ix + iy * iy + iz * iz)
        if il <= 1e-20:
            return ((px, py, pz), tri)
        ix, iy, iz = ix / il, iy / il, iz / il  # 邻面内、垂直棱、朝面内
        dx = dpar * ex + pp * ix
        dy = dpar * ey + pp * iy
        dz = dpar * ez + pp * iz
        dl = math.sqrt(dx * dx + dy * dy + dz * dz)
        if dl <= 1e-20:
            return ((px, py, pz), tri)
        dx, dy, dz = dx / dl, dy / dl, dz / dl
        px += (cn[16] - px) * 1e-7              # 轻微内推, 防数值抖动
        py += (cn[17] - py) * 1e-7
        pz += (cn[18] - pz) * 1e-7
        tri = nxt
    return ((px, py, pz), tri)


def distorted_faces(faces, rest_co, out_co, scale, tol, floor=0.35):
    """按边长比找出变形超差的面。
    faces: 面的顶点索引序列; rest_co: 平面静止坐标(局部, 未缩放);
    out_co: 展开后坐标(目标局部空间); scale: 局部→目标的尺度;
    tol: 拉伸上限; floor: 压缩下限(固定且宽松) ——
    跨折缝的格子直线弦长天然短于路径长(90°折为0.707倍), 属正常折叠,
    不可按 1/tol 判定, 否则折缝整排会被误裁。
    返回 (超差面索引列表, 最大拉伸比, 最小压缩比)。"""
    bad = []
    worst = 1.0
    tightest = 1.0
    lo = floor
    for fi, vs in enumerate(faces):
        n = len(vs)
        flag = False
        for k in range(n):
            i = vs[k]
            j = vs[(k + 1) % n]
            ax, ay = rest_co[i][0], rest_co[i][1]
            bx, by = rest_co[j][0], rest_co[j][1]
            r0 = math.sqrt((ax - bx) ** 2 + (ay - by) ** 2) * scale
            if r0 <= 1e-12:
                continue
            p = out_co[i]
            q = out_co[j]
            r1 = math.sqrt((p[0] - q[0]) ** 2 + (p[1] - q[1]) ** 2
                           + (p[2] - q[2]) ** 2)
            ratio = r1 / r0
            if ratio > worst:
                worst = ratio
            if ratio < tightest:
                tightest = ratio
            if ratio > tol or ratio < lo:
                flag = True
        if flag:
            bad.append(fi)
    return bad, worst, tightest


def target_tri_arrays(context, target):
    """目标求值后的三角网格 (V, T), 目标局部空间。失败返回 (None, None)。"""
    try:
        ev = target.evaluated_get(context.evaluated_depsgraph_get())
        me = ev.to_mesh()
    except (RuntimeError, AttributeError):
        return None, None
    try:
        if hasattr(me, "calc_loop_triangles"):  # 4.x 需显式计算
            me.calc_loop_triangles()
        nv = len(me.vertices)
        nt = len(me.loop_triangles)
        if nv == 0 or nt == 0:
            return None, None
        V = np.empty(nv * 3, dtype=np.float64)
        me.vertices.foreach_get("co", V)
        T = np.empty(nt * 3, dtype=np.int64)
        me.loop_triangles.foreach_get("vertices", T)
        return V.reshape(nv, 3), T.reshape(nt, 3)
    finally:
        try:
            ev.to_mesh_clear()
        except (RuntimeError, AttributeError):
            pass


def grid_data(size_x, size_y, div):
    """生成 size_x × size_y、每边 div 个面的平面网格数据, 面朝 +Z。"""
    n = max(1, int(div))
    sx = size_x / n
    sy = size_y / n
    hx = size_x / 2.0
    hy = size_y / 2.0
    verts = []
    for j in range(n + 1):
        for i in range(n + 1):
            verts.append((i * sx - hx, j * sy - hy, 0.0))
    faces = []
    for j in range(n):
        for i in range(n):
            a = j * (n + 1) + i
            faces.append((a, a + 1, a + n + 2, a + n + 1))
    return verts, faces


def polygon_area(pts):
    """鞋带公式带符号面积: 逆时针为正。"""
    s = 0.0
    n = len(pts)
    for i in range(n):
        x0, y0 = pts[i]
        x1, y1 = pts[(i + 1) % n]
        s += x0 * y1 - x1 * y0
    return 0.5 * s


def rdp(points, tol):
    """Ramer-Douglas-Peucker 折线简化(迭代实现, 避免递归深度限制)。"""
    n = len(points)
    if tol <= 0.0 or n < 3:
        return list(points)
    keep = [False] * n
    keep[0] = keep[-1] = True
    stack = [(0, n - 1)]
    tol2 = tol * tol
    while stack:
        i, j = stack.pop()
        if j <= i + 1:
            continue
        ax, ay = points[i]
        bx, by = points[j]
        dx, dy = bx - ax, by - ay
        seg2 = dx * dx + dy * dy
        dmax, k = -1.0, -1
        for m in range(i + 1, j):
            px, py = points[m]
            if seg2 == 0.0:
                d2 = (px - ax) ** 2 + (py - ay) ** 2
            else:
                t = ((px - ax) * dx + (py - ay) * dy) / seg2
                t = 0.0 if t < 0.0 else (1.0 if t > 1.0 else t)
                cx, cy = ax + t * dx, ay + t * dy
                d2 = (px - cx) ** 2 + (py - cy) ** 2
            if d2 > dmax:
                dmax, k = d2, m
        if dmax > tol2:
            keep[k] = True
            stack.append((i, k))
            stack.append((k, j))
    return [p for p, f in zip(points, keep) if f]


def simplify_loop(loop, tol):
    """对闭合轮廓做 RDP 简化(首尾接合后处理)。"""
    if tol <= 0.0 or len(loop) < 5:
        return loop
    out = rdp(loop + [loop[0]], tol)
    if len(out) >= 2 and out[0] == out[-1]:
        out = out[:-1]
    return out if len(out) >= 3 else loop


# Marching Squares 有向线段表(内部区域恒在行进方向左侧):
# 外轮廓逆时针、孔洞顺时针 —— 正好匹配曲线填充的常规约定。
# 角点编号: c0=左下 c1=右下 c2=右上 c3=左上, case = c0|c1<<1|c2<<2|c3<<3
CASE_SEGMENTS = {
    1:  (('B', 'L'),), 2:  (('R', 'B'),), 3:  (('R', 'L'),), 4:  (('T', 'R'),),
    6:  (('T', 'B'),), 7:  (('T', 'L'),), 8:  (('L', 'T'),), 9:  (('B', 'T'),),
    11: (('R', 'T'),), 12: (('L', 'R'),), 13: (('B', 'R'),), 14: (('L', 'B'),),
}


def extract_contours(field, threshold):
    """Marching Squares 等值线提取。
    field: numpy 2D float32 (h, w), threshold: 等值面阈值。
    返回闭合轮廓列表, 点为 (x, y) 浮点像素坐标(含 1 像素零填充偏移)。
    线段端点以"网格边"为键做拼接, 避免浮点坐标哈希误差; 鞍点用中心均值消歧。"""
    h, w = field.shape
    f = np.zeros((h + 2, w + 2), dtype=np.float32)   # 零填充保证轮廓闭合
    f[1:-1, 1:-1] = field
    u = (f >= threshold).astype(np.uint8)
    cases = (u[:-1, :-1] | (u[:-1, 1:] << 1)
             | (u[1:, 1:] << 2) | (u[1:, :-1] << 3))
    ys, xs = np.nonzero((cases != 0) & (cases != 15))

    segs = {}
    for y, x in zip(ys.tolist(), xs.tolist()):
        case = int(cases[y, x])
        edges = {'B': ('H', x, y), 'T': ('H', x, y + 1),
                 'L': ('V', x, y), 'R': ('V', x + 1, y)}
        if case == 5 or case == 10:
            center = (f[y, x] + f[y, x + 1]
                      + f[y + 1, x] + f[y + 1, x + 1]) * 0.25 >= threshold
            if case == 5:
                pairs = (('B', 'R'), ('T', 'L')) if center else (('B', 'L'), ('T', 'R'))
            else:
                pairs = (('L', 'B'), ('R', 'T')) if center else (('R', 'B'), ('L', 'T'))
        else:
            pairs = CASE_SEGMENTS[case]
        for a, c in pairs:
            segs[edges[a]] = edges[c]

    def edge_point(e):
        kind, x, y = e
        if kind == 'H':
            v0 = float(f[y, x]); v1 = float(f[y, x + 1])
            s = 0.5 if v1 == v0 else (threshold - v0) / (v1 - v0)
            return (x + s, float(y))
        v0 = float(f[y, x]); v1 = float(f[y + 1, x])
        s = 0.5 if v1 == v0 else (threshold - v0) / (v1 - v0)
        return (float(x), y + s)

    loops = []
    while segs:
        start, cur = segs.popitem()
        chain = [start]
        closed = False
        while True:
            chain.append(cur)
            nxt = segs.pop(cur, None)
            if nxt is None:
                break
            if nxt == start:
                closed = True
                break
            cur = nxt
        if closed and len(chain) >= 3:
            loops.append([edge_point(e) for e in chain])
    return loops


def field_from_pixels(arr, mode):
    """从 (h, w, c) 像素数组按模式取标量场: alpha / 明度 / 明度反相。"""
    c = arr.shape[2]
    if mode == 'AUTO':
        if c >= 4 and float(arr[..., 3].min()) < 0.999:
            mode = 'ALPHA'          # alpha 通道有变化, 优先用 alpha
        else:
            mode = 'LUMA'
    if mode == 'ALPHA':
        if c >= 4:
            return arr[..., 3].astype(np.float32)
        return np.ones(arr.shape[:2], dtype=np.float32)
    rgb = arr[..., :3]
    f = (rgb[..., 0] * 0.2126 + rgb[..., 1] * 0.7152 + rgb[..., 2] * 0.0722)
    if mode == 'LUMA_INV':
        f = 1.0 - f
    return f.astype(np.float32)


def pool_field(f, max_res):
    """均值池化降采样到长边不超过 max_res, 返回 (场, 缩放系数 k)。"""
    h, w = f.shape
    k = max(1, int(math.ceil(max(h, w) / float(max_res))))
    if k == 1:
        return f, 1
    hh = (h // k) * k
    ww = (w // k) * k
    g = f[:hh, :ww].reshape(hh // k, k, ww // k, k).mean(axis=(1, 3))
    return g.astype(np.float32), k


# ============================================================
#  bpy 工具函数
# ============================================================

def _new_uid():
    """短随机ID, 用于贴花/目标的持久标识。"""
    import uuid
    return uuid.uuid4().hex[:12]


def ensure_target_id(target):
    """给目标物体打持久ID(只写一次)。"""
    if target is None:
        return ""
    tid = target.get(KEY_TARGET_ID)
    if not tid:
        tid = _new_uid()
        target[KEY_TARGET_ID] = tid
    return tid


def bind_decal_target(decal, target):
    """建立贴花↔目标的双重关联: 名字(可读) + 持久ID(可靠)。
    §2.2: 目标关联不能只依赖父子关系, 用户解除父级后仍要能找回。"""
    if decal is None:
        return
    if not decal.get(KEY_DECAL_ID):
        decal[KEY_DECAL_ID] = _new_uid()
    if target is not None:
        decal[KEY_TARGET] = target.name
        decal[KEY_TARGET_ID] = ensure_target_id(target)


def decal_state(obj):
    """贴花生命周期状态: LIVE(可编辑几何) / GEOMETRY_FROZEN(几何已烘死)。"""
    if obj is None:
        return ""
    return obj.get(KEY_STATE, "LIVE") if is_decal(obj) else ""


def is_frozen(obj):
    return decal_state(obj) == "GEOMETRY_FROZEN"


def is_decal(obj):
    """带SD修改器, 或带贴花标记(包裹后修改器可能已被烘焙形状取代)。"""
    return (obj is not None and obj.type == 'MESH'
            and (any(m.name.startswith(MOD_PREFIX) for m in obj.modifiers)
                 or KEY_TARGET in obj or KEY_REST in obj
                 or KEY_DECAL_ID in obj))       # 固化后靠持久ID仍是贴花


def is_wrapped(obj):
    """是否已硬边包裹(存在可还原的备份)。"""
    return obj is not None and bool(obj.get(KEY_REST))


def decal_target_of(context, obj):
    """读取贴花记录的目标物体。先按名字, 再按持久ID回退 ——
    目标被改名或父级被解除后仍能找回(§2.2)。"""
    name = obj.get(KEY_TARGET, "")
    if name:
        t = context.scene.objects.get(name) or bpy.data.objects.get(name)
        if t is not None and t.type == 'MESH':
            return t
    tid = obj.get(KEY_TARGET_ID, "")
    if tid:
        for o in bpy.data.objects:
            # 贴花自身也保存目标ID，不能在名字失效后把自己误认成目标。
            if (o != obj and o.type == 'MESH' and not is_decal(o)
                    and o.get(KEY_TARGET_ID) == tid):
                # 此解析函数会在面板 draw() 中调用，必须保持只读。
                # 名字缓存失效时直接依赖持久ID回退，避免绘制期间写 ID 数据。
                return o
    if obj.parent is not None and obj.parent.type == 'MESH':
        return obj.parent                       # 最后回退到父级
    return None


def target_is_smooth_shaded(target, sample=20000):
    """目标是否含平滑着色面。全平直着色时法线融合无意义, 应跳过。
    大网格抽样检查, 避免遍历百万面。"""
    polys = target.data.polygons
    n = len(polys)
    if n == 0:
        return False
    step = max(1, n // sample)
    for i in range(0, n, step):
        if polys[i].use_smooth:
            return True
    return False


def ensure_smooth_shading(obj):
    """贴花面全部平滑着色; 4.0.x 额外开启自动平滑以显示自定义法线,
    4.1+ 已移除该属性, 自定义法线默认生效, 无需处理。"""
    me = obj.data
    for poly in me.polygons:                # 变量名避开 p(全文件 p 专指属性组)
        poly.use_smooth = True
    if hasattr(me, "use_auto_smooth"):          # Blender 4.0.x
        me.use_auto_smooth = True
        if hasattr(me, "auto_smooth_angle"):
            me.auto_smooth_angle = math.pi      # 180°: 不按角度分硬边, 只吃自定义法线


def subdivide_mesh_simple(me, levels):
    """就地简单细分(不改形状)。用bmesh而非 modifier_apply ——
    贴花上若还有阵列/镜像等修改器, 后者会把它们一起烘进网格。"""
    lv = max(1, min(6, int(levels)))
    cuts = (2 ** lv) - 1
    bm = bmesh.new()
    bm.from_mesh(me)
    bmesh.ops.subdivide_edges(bm, edges=bm.edges[:], cuts=cuts,
                              use_grid_fill=True)
    bm.to_mesh(me)
    bm.free()
    me.update()


def _expanded_vertex_ring(obj, protected):
    expanded = set(protected)
    for edge in obj.data.edges:
        if any(vertex in protected for vertex in edge.vertices):
            expanded.update(edge.vertices)
    return expanded


def edge_decimate_protection(obj):
    """Return base-vertex indices that must survive edge-aware decimation.

    The visible edge band is normally sampled on the subdivided, wrapped
    result.  Map those visible samples back to the nearest vertices of the
    wrapped base mesh, then preserve the surrounding rings.  Sampling only
    the unsubdivided points misses an edge that passes between base vertices
    and was the reason the effect disappeared after planar dissolve.

    ``None`` means an active edge effect could not be mapped safely, so the
    caller must skip decimation rather than destroy it.
    """
    uses_edge = any(edge_enabled(slot.material) for slot in obj.material_slots)
    if not uses_edge:
        return set()
    edge_modifier = obj.modifiers.get(MOD_EDGE_FIELD)
    if edge_modifier is None:
        attribute = obj.data.attributes.get(EDGE_FIELD_ATTR)
        if (attribute is None
                or len(attribute.data) != len(obj.data.vertices)):
            return None
        protected = {
            index for index, item in enumerate(attribute.data)
            if item.value > 1e-6
        }
        if not protected:
            return set()
        return _expanded_vertex_ring(obj, protected)

    modifiers = list(obj.modifiers)
    edge_index = modifiers.index(edge_modifier)
    visibility = [(modifier, modifier.show_viewport)
                  for modifier in modifiers]
    try:
        # First sample the actual field that the material sees: subdivision,
        # wrapping and the edge-field modifier stay enabled; later modifiers
        # are irrelevant and may change the point domain.
        for index, modifier in enumerate(modifiers):
            if index > edge_index:
                modifier.show_viewport = False
        bpy.context.view_layer.update()
        depsgraph = bpy.context.evaluated_depsgraph_get()
        evaluated = obj.evaluated_get(depsgraph)
        mesh = evaluated.to_mesh()
        try:
            attribute = mesh.attributes.get(EDGE_FIELD_ATTR)
            if attribute is None or len(attribute.data) != len(mesh.vertices):
                return None
            hot_positions = [
                mesh.vertices[index].co.copy()
                for index, item in enumerate(attribute.data)
                if item.value > 1e-6
            ]
        finally:
            evaluated.to_mesh_clear()

        if not hot_positions:
            return set()

        # Evaluate the same wrapped stack without managed subdivision.  Its
        # point order now matches the editable base mesh, while positions are
        # still comparable with the fully evaluated samples above.  The edge
        # field itself may add bounded sampling topology, so it must also be
        # disabled for this base pass.
        for modifier in modifiers:
            if modifier.name == MOD_SUBSURF:
                modifier.show_viewport = False
        edge_modifier.show_viewport = False
        bpy.context.view_layer.update()
        evaluated = obj.evaluated_get(depsgraph)
        mesh = evaluated.to_mesh()
        try:
            if len(mesh.vertices) != len(obj.data.vertices):
                return None
            base_positions = [vertex.co.copy() for vertex in mesh.vertices]
        finally:
            evaluated.to_mesh_clear()
    finally:
        for modifier, was_visible in visibility:
            modifier.show_viewport = was_visible
        bpy.context.view_layer.update()

    protected = set()
    for point in hot_positions:
        nearest = min(
            range(len(base_positions)),
            key=lambda index: (base_positions[index] - point).length_squared,
        )
        protected.add(nearest)
    # Two rings keep the local cells that subdivision uses to reconstruct the
    # field, while flat regions farther from the target edge can still merge.
    protected = _expanded_vertex_ring(obj, protected)
    return _expanded_vertex_ring(obj, protected)


def dissolve_decal(obj, angle_deg=1.0, protected_vertices=None):
    """有限融并减面: 合并夹角小于阈值的共面区域。
    平面贴花可退到最少面数; 已包裹的贴花因折缝已标为硬边(delimit=SHARP),
    折线会被保留, 只合并两侧的平坦区。UV在平面区域是仿射的, 融并无损。
    protected_vertices 及其相连边不参与融并，用于保留边缘磨损采样带。
    返回 (前, 后) 面数。"""
    me = obj.data
    before = len(me.polygons)
    if before < 2:
        return before, before
    ang = max(0.05, float(angle_deg))
    bm = bmesh.new()
    bm.from_mesh(me)
    bm.verts.ensure_lookup_table()
    protected = set(protected_vertices or ())
    dissolve_verts = [v for v in bm.verts if v.index not in protected]
    dissolve_edges = [
        edge for edge in bm.edges
        if all(vertex.index not in protected for vertex in edge.verts)
    ]
    try:
        bmesh.ops.dissolve_limit(bm, angle_limit=math.radians(ang),
                                 verts=dissolve_verts, edges=dissolve_edges,
                                 delimit={'MATERIAL', 'SHARP', 'SEAM'})
    except (RuntimeError, TypeError):
        bm.free()
        return before, before
    bm.to_mesh(me)
    bm.free()
    me.update()
    return before, len(me.polygons)



def mark_fold_sharp(obj, angle_deg=30.0):
    """给折角超过阈值的边打硬边标记。包裹后的贴花自身是折面, 若全平滑,
    90°折缝处法线会被平均, 呈现一条暗带(易被误认为裂口)。
    4.0.x 由 ensure_smooth_shading 开启的自动平滑会尊重硬边标记;
    4.1+/5.x 硬边直接生效。返回标记的边数。"""
    me = obj.data
    if not me.polygons:
        return 0
    bm = bmesh.new()
    bm.from_mesh(me)
    thr = math.radians(angle_deg)
    n = 0
    for e in bm.edges:
        if len(e.link_faces) != 2:
            continue
        try:
            ang = e.calc_face_angle()
        except (ValueError, RuntimeError):
            continue
        if ang > thr:
            e.smooth = False                # False = 硬边(use_edge_sharp)
            n += 1
    bm.to_mesh(me)
    bm.free()
    me.update()
    return n


def clear_stack(obj):
    groups = []
    for modifier in obj.modifiers:
        if (modifier.name.startswith(MOD_PREFIX)
                and modifier.type == 'NODES' and modifier.node_group is not None):
            groups.append(modifier.node_group)
    for name in [m.name for m in obj.modifiers]:
        if name.startswith(MOD_PREFIX):
            obj.modifiers.remove(obj.modifiers[name])
    for group in groups:
        if group.users == 0 and group.get(KEY_ROLE) == "geometry_edge_field":
            bpy.data.node_groups.remove(group)


def decal_reach(obj):
    """贴花的局部投射距离: 网格包围盒对角一半×0.75, 下限0.05。
    覆盖曲率贴合所需行程, 又不至于射穿硬边后的开口。"""
    me = obj.data
    if not me.vertices:
        return 0.1
    xs = [v.co.x for v in me.vertices]
    ys = [v.co.y for v in me.vertices]
    zs = [v.co.z for v in me.vertices]
    dx = max(xs) - min(xs)
    dy = max(ys) - min(ys)
    dz = max(zs) - min(zs)
    return max(0.05, 0.5 * math.sqrt(dx * dx + dy * dy + dz * dz) * 0.75)


def _drop_rest_mesh(obj):
    """释放旧备份数据块。"""
    name = obj.get(KEY_REST)
    if not name:
        return
    m = bpy.data.meshes.get(name)
    if m is not None:
        m.use_fake_user = False
        if m.users == 0:
            bpy.data.meshes.remove(m)


def store_rest_state(obj):
    """备份包裹前的网格与吸附设置(供还原/重新包裹)。"""
    _drop_rest_mesh(obj)
    rest = obj.data.copy()
    rest.name = obj.data.name + "_rest"
    rest.use_fake_user = True                   # 无物体引用也不被清理
    obj[KEY_REST] = rest.name
    sp = stack_params_for(obj, None)
    if sp is not None:
        obj[KEY_REST_P] = {
            "wrap_method": sp.wrap_method,
            "offset": float(sp.offset),
            "project_limit": float(sp.project_limit),
            "subsurf_levels": int(sp.subsurf_levels),
            "use_solidify": bool(sp.use_solidify),
            "thickness": float(sp.thickness),
            "use_normal_transfer": bool(sp.use_normal_transfer),
            "normal_mix": float(sp.normal_mix),
        }


def rest_params_of(obj, fallback_p):
    """读回备份的吸附设置。"""
    raw = obj.get(KEY_REST_P)
    if raw is None:
        return fallback_p
    d = raw.to_dict() if hasattr(raw, "to_dict") else dict(raw)
    return SimpleNamespace(
        wrap_method=d.get("wrap_method", 'PROJECT'),
        offset=d.get("offset", 0.002),
        project_limit=d.get("project_limit", 0.0),
        subsurf_levels=int(d.get("subsurf_levels", 2)),
        use_solidify=bool(d.get("use_solidify", False)),
        thickness=d.get("thickness", 0.01),
        use_normal_transfer=bool(d.get("use_normal_transfer", True)),
        normal_mix=d.get("normal_mix", 1.0),
    )


def restore_rest_state(context, obj, rebuild=True):
    """还原到包裹前: 换回备份网格并重建吸附栈。备份本体保留。"""
    name = obj.get(KEY_REST)
    rest = bpy.data.meshes.get(name) if name else None
    if rest is None:
        return False
    old_me = obj.data
    fresh = rest.copy()                         # 用副本, 备份留着可再还原
    fresh.name = old_me.name
    fresh.use_fake_user = False
    obj.data = fresh
    if old_me.users == 0:
        bpy.data.meshes.remove(old_me)
    if rebuild:
        target = decal_target_of(context, obj)
        if target is not None:
            build_stack(obj, target,
                        rest_params_of(obj, context.scene.surfdecal))
    ensure_smooth_shading(obj)
    return True


def clear_rest_state(obj):
    """丢弃备份(固化后不再需要)。"""
    _drop_rest_mesh(obj)
    for k in (KEY_REST, KEY_REST_P):
        if k in obj:
            del obj[k]


def get_prefs(context):
    """插件偏好设置; 模块名不匹配时返回 None。"""
    try:
        return context.preferences.addons[__name__].preferences
    except (KeyError, AttributeError):
        return None


def library_dir_path(context):
    """贴花库文件夹的绝对路径(未设置或不存在则空)。"""
    prefs = get_prefs(context)
    raw = getattr(prefs, "library_dir", "") if prefs is not None else ""
    if not raw:
        return ""
    path = bpy.path.abspath(raw)
    return path if os.path.isdir(path) else ""


# ---- §9 贴花库: 导入时登记, 扫描只读 ----
KEY_LIB_ASSET = "sd_library_asset"      # 由本插件导入并登记的库成员
KEY_LIB_SRC = "sd_import_source"
KEY_LIB_KIND = "sd_library_kind"        # DECAL_BASE = 贴花主图
KEY_LIB_PATH = "sd_source_path"
LIB_BASE_EXTS = (".png", ".jpg", ".jpeg")
# 允许登记的来源。§9.3 的本意是"磨损/法线/表面匹配的贴图一律不得进库",
# 而不是"只有一个算子能进库" —— 外部插件烘出的独立贴花图同样是主图。
LIB_SRC_IMPORT = "surfdecal.import_image"
LIB_SRC_ADD = "surfdecal.library_add"
LIB_SOURCES = (LIB_SRC_IMPORT, LIB_SRC_ADD)
LIB_MANIFEST = "surfdecal_library.json"


def library_manifest_path(context=None):
    directory = library_dir_path(context or bpy.context)
    return os.path.join(directory, LIB_MANIFEST) if directory else ""


def _read_library_manifest(context=None):
    path = library_manifest_path(context)
    if not path or not os.path.isfile(path):
        return {"schema": 1, "assets": []}
    try:
        with open(path, "r", encoding="utf-8") as handle:
            data = json.load(handle)
    except (OSError, ValueError, TypeError):
        return {"schema": 1, "assets": []}
    assets = data.get("assets", []) if isinstance(data, dict) else []
    return {"schema": 1, "assets": [a for a in assets
                                     if isinstance(a, dict)]}


def _write_library_manifest(data, context=None):
    path = library_manifest_path(context)
    if not path:
        return False
    temp = path + ".tmp"
    try:
        with open(temp, "w", encoding="utf-8") as handle:
            json.dump(data, handle, ensure_ascii=False, indent=2)
        os.replace(temp, path)
        return True
    except OSError:
        try:
            if os.path.exists(temp):
                os.remove(temp)
        except OSError:
            pass
        return False


def _manifest_register_asset(path, context=None, source=LIB_SRC_IMPORT):
    normalized = _norm_path(path)
    if not normalized or os.path.splitext(normalized)[1].lower() not in LIB_BASE_EXTS:
        return False
    data = _read_library_manifest(context)
    assets = [item for item in data["assets"]
              if _norm_path(item.get("path", "")) != normalized]
    assets.append({
        "path": normalized,
        "kind": "DECAL_BASE",
        "source": source if source in LIB_SOURCES else LIB_SRC_IMPORT,
    })
    data["assets"] = assets
    return _write_library_manifest(data, context)


def _manifest_unregister_asset(path, context=None):
    normalized = _norm_path(path)
    data = _read_library_manifest(context)
    old = data["assets"]
    data["assets"] = [item for item in old
                      if _norm_path(item.get("path", "")) != normalized]
    return len(old) != len(data["assets"]) and _write_library_manifest(data, context)


def _norm_path(p):
    """规范化路径, 用于去重(避免 .001 与同名文件造成重复条目)。"""
    if not p:
        return ""
    try:
        return os.path.normcase(os.path.abspath(bpy.path.abspath(p)))
    except (AttributeError, TypeError, ValueError):
        return str(p)


def register_library_asset(img, path="", context=None, write_manifest=True,
                           source=LIB_SRC_IMPORT):
    """登记为贴花库成员 —— 只有导入操作有权调用(§9.3)。
    Wear / Edge / Normal / Height 的选图与表面匹配复制的纹理都不得登记。"""
    if img is None:
        return False
    src = path or getattr(img, "filepath", "")
    if os.path.splitext(src or img.name)[1].lower() not in LIB_BASE_EXTS:
        return False                    # 只收 PNG/JPG 主图
    img[KEY_LIB_ASSET] = True
    img[KEY_LIB_SRC] = source if source in LIB_SOURCES else LIB_SRC_IMPORT
    img[KEY_LIB_KIND] = "DECAL_BASE"
    img[KEY_LIB_PATH] = _norm_path(src)
    if write_manifest:
        _manifest_register_asset(src, context, source)
    return True


def unregister_library_asset(img, context=None):
    """取消登记 —— 不删原文件, 也不动贴花材质(§9.5)。"""
    if img is None:
        return False
    hit = False
    source_path = img.get(KEY_LIB_PATH, "") or getattr(img, "filepath", "")
    for k in (KEY_LIB_ASSET, KEY_LIB_SRC, KEY_LIB_KIND, KEY_LIB_PATH):
        if k in img:
            del img[k]
            hit = True
    if hit:
        _manifest_unregister_asset(source_path, context)
    return hit


def is_library_asset(img):
    """是否已登记的贴花库成员。四个条件必须同时满足(§9.2)。"""
    if img is None:
        return False
    if not img.get(KEY_LIB_ASSET):
        return False
    if img.get(KEY_LIB_KIND) != "DECAL_BASE":
        return False
    if img.get(KEY_LIB_SRC) not in LIB_SOURCES:
        return False
    ext = os.path.splitext(img.get(KEY_LIB_PATH, "")
                           or getattr(img, "filepath", "")
                           or img.name)[1].lower()
    return ext in LIB_BASE_EXTS


def library_images_in_file():
    """已登记的库成员。只读查询: 不遍历材质节点, 不补写任何标记。
    (旧实现会把磨损/边缘/法线/目标材质的图一起塞进库里。)"""
    found = {}
    for img in bpy.data.images:
        if not is_library_asset(img):
            continue
        key = img.get(KEY_LIB_PATH) or img.name     # 按路径去重, 不按图片名
        if key not in found:
            found[key] = img
    return [found[k] for k in sorted(found)]


def scan_library(context):
    """重建贴花库条目 —— 纯只读(§9.3)。
    只列已登记的成员; 库目录里未登记的文件保持普通文件状态, 不自动显示。"""
    global _lib_items
    items = []
    idx = 0
    seen = set()
    # 跨 .blend 持久化只读取 manifest 中由插件登记过的路径；绝不扫描目录
    # 中的所有图片，因此磨损/法线/随手截图不会被误收录。
    manifest = _read_library_manifest(context)
    for entry in manifest["assets"]:
        if (entry.get("kind") != "DECAL_BASE"
                or entry.get("source") not in LIB_SOURCES):
            continue
        path = entry.get("path", "")
        if (os.path.splitext(path)[1].lower() not in LIB_BASE_EXTS
                or not os.path.isfile(path)):
            continue
        try:
            image = bpy.data.images.load(path, check_existing=True)
        except (RuntimeError, OSError):
            continue
        register_library_asset(image, path, context, write_manifest=False,
                               source=entry.get("source", LIB_SRC_IMPORT))
    for img in library_images_in_file():
        key = img.get(KEY_LIB_PATH) or img.name
        if key in seen:
            continue
        seen.add(key)
        try:
            img.preview_ensure()
            icon = img.preview.icon_id
        except (AttributeError, RuntimeError):
            icon = 0
        label = os.path.splitext(bpy.path.basename(
            img.get(KEY_LIB_PATH, "") or img.name))[0] or img.name
        items.append(("IMG:" + img.name, label, "贴花库", icon, idx))
        idx += 1
    _lib_items = items
    return len(items)



def library_enum_items(self, context):
    return _lib_items or [('NONE', "(空)", "点[刷新]扫描贴花库", 0, 0)]


def create_image_decal_object(context, img, width, blend, luma_alpha, grid):
    """图像 → 贴花面片物体(按图像比例生成网格并建立alpha材质)。"""
    w, h = img.size
    if w == 0 or h == 0:
        return None
    base = os.path.splitext(bpy.path.basename(img.filepath))[0] or img.name
    size_y = width * (h / float(w))
    me = make_decal_mesh(base, width, size_y, max(1, grid))
    obj = bpy.data.objects.new(base, me)
    context.collection.objects.link(obj)
    use_luma = luma_alpha and img.channels < 4
    hard = False                            # Cycles 不需要alpha量化
    sig = decal_mat_signature(img, blend, use_luma, hard)
    shared = (find_shared_decal_material(sig)
              if getattr(bpy.context.scene.surfdecal, "share_materials", True)
              else None)
    if shared is not None:
        me.materials.append(shared)
    else:
        newmat = make_alpha_decal_material(base, img, blend, use_luma, hard)
        auto_name_material(newmat, img)     # 材质统一命名
        me.materials.append(newmat)
    obj.visible_shadow = False              # 贴花不投影
    return obj


def stack_params_for(obj, fallback_p):
    """读取贴花现有SD修改器设置, 生成与面板同形的参数对象;
    无栈时回落到面板参数。用于重投放时保留每张贴花自己的设置。"""
    ms = obj.modifiers.get(MOD_SHRINK)
    if ms is None:
        return fallback_p
    msolid = obj.modifiers.get(MOD_SOLID)
    msub = obj.modifiers.get(MOD_SUBSURF)
    mnorm = obj.modifiers.get(MOD_NORMAL)
    return SimpleNamespace(
        wrap_method=ms.wrap_method if ms.wrap_method in
            {'NEAREST_SURFACEPOINT', 'PROJECT'} else 'NEAREST_SURFACEPOINT',
        offset=ms.offset,
        project_limit=ms.project_limit,
        subsurf_levels=msub.levels if msub is not None else 0,
        use_solidify=msolid is not None,
        thickness=msolid.thickness if msolid is not None else 0.01,
        use_normal_transfer=mnorm is not None,
        normal_mix=mnorm.mix_factor if mnorm is not None else 1.0,
    )


KEY_AUTOSUB = "surfdecal_auto_subdiv"   # 旧版自适应定级记录，仅用于兼容清理
FINALIZE_FLAT_ANGLE = 0.1


def sample_target_flatness(obj, target, samples=4):
    """按贴花真实几何覆盖点下方的目标法线判定平坦度。

    返回采样法线的最大两两夹角(度)。只使用贴花顶点与面中心，不使用外接
    矩形；因此 SVG/镂空贴花空白区里的曲面或硬边不会污染最终固化判定。

    用 BVH 的 find_nearest 从每个覆盖点探测；它返回点到面的精确距离，
    因而在目标由少量大面组成时也不依赖目标面心是否落进贴花范围。
    """
    from mathutils.bvhtree import BVHTree
    try:
        dg = bpy.context.evaluated_depsgraph_get()
        ev = target.evaluated_get(dg)
        me = ev.to_mesh()
    except (AttributeError, RuntimeError):
        return None
    try:
        if not me.polygons or not obj.data.vertices:
            return None
        try:
            bvh = BVHTree.FromObject(target, dg)
        except (RuntimeError, ValueError, TypeError):
            return None
        mw = obj.matrix_world
        inv = target.matrix_world.inverted()
        nmat = inv.transposed().to_3x3()
        points = [v.co.copy() for v in obj.data.vertices]
        points.extend(poly.center.copy() for poly in obj.data.polygons)
        if not points:
            return None
        # 最终固化才执行一次，允许比实时放置更完整的采样；超大底网格仍设上限。
        limit = max(64, (max(2, int(samples)) + 1) ** 2 * 8)
        if len(points) > limit:
            step = (len(points) - 1) / float(limit - 1)
            points = [points[round(i * step)] for i in range(limit)]
        xs = [point.x for point in points]
        ys = [point.y for point in points]
        zs = [point.z for point in points]
        minx, maxx = min(xs), max(xs)
        miny, maxy = min(ys), max(ys)
        minz, maxz = min(zs), max(zs)
        # 覆盖半径(目标局部尺度), 用于把探测扩展到贴花脚下的邻接面
        span = ((mw @ Vector((maxx, maxy, maxz))
                 - mw @ Vector((minx, miny, minz))).length)
        sc = target.matrix_world.to_scale()
        s_avg = max(1e-9, (abs(sc.x) + abs(sc.y) + abs(sc.z)) / 3.0)
        reach = max(span * 0.6 / s_avg, 1e-5)
        normals = []
        for point in points:
            query = inv @ (mw @ point)
            hit = bvh.find_nearest(query, reach)
            if hit is None or hit[0] is None:
                continue
            normals.append((nmat @ hit[1]).normalized())
        if len(normals) < 2:
            return None
        mind = 1.0
        for a in range(len(normals)):
            for b in range(a + 1, len(normals)):
                d = normals[a].dot(normals[b])
                if d < mind:
                    mind = d
        return math.degrees(math.acos(max(-1.0, min(1.0, mind))))
    finally:
        try:
            ev.to_mesh_clear()
        except (AttributeError, RuntimeError):
            pass



def build_stack(obj, target, p, preview_hidden=False):
    """按当前参数重建贴花修改器栈。
    顺序: 细分 → 吸附 → [实体化] → [法线融合]
    preview_hidden: 预览阶段隐藏吸附/法线融合(两者每次求值都要建目标BVH,
    大场景下逐帧重建会卡死交互), 确认时再以 False 重建。
    返回 True 表示因目标平直着色而跳过了法线融合。"""
    clear_stack(obj)
    skipped_normal = False

    # 编辑阶段始终保留用户指定的完整细分：贴花可能在确认后继续移动到曲面或
    # 跨过硬折线，若在导入/放置时按当前位置降级，Shrinkwrap 将没有足够顶点。
    levels = int(p.subsurf_levels)
    if KEY_AUTOSUB in obj:
        del obj[KEY_AUTOSUB]
    if levels > 0:
        m = obj.modifiers.new(MOD_SUBSURF, 'SUBSURF')
        m.subdivision_type = 'SIMPLE'
        m.levels = levels
        m.render_levels = levels
        m.show_only_control_edges = True

    m = obj.modifiers.new(MOD_SHRINK, 'SHRINKWRAP')
    m.target = target
    m.wrap_mode = 'ABOVE_SURFACE'   # 沿表面法线悬浮, 防深度冲突
    m.offset = p.offset
    m.show_viewport = not preview_hidden
    if p.wrap_method == 'PROJECT':
        m.wrap_method = 'PROJECT'
        m.use_project_z = True
        m.use_negative_direction = True
        m.use_positive_direction = True
        lim = p.project_limit
        if lim <= 0.0:                  # 0=自动: 按贴花尺寸限深, 防射穿开口
            lim = decal_reach(obj)
        m.project_limit = lim
    else:
        m.wrap_method = 'NEAREST_SURFACEPOINT'

    if p.use_solidify:
        m = obj.modifiers.new(MOD_SOLID, 'SOLIDIFY')
        m.thickness = p.thickness
        m.offset = 1.0              # 厚度朝外生长, 底面贴住表面
        m.use_even_offset = True

    if p.use_normal_transfer:
        if target_is_smooth_shaded(target):
            m = obj.modifiers.new(MOD_NORMAL, 'DATA_TRANSFER')
            m.object = target
            m.use_loop_data = True
            m.data_types_loops = {'CUSTOM_NORMAL'}
            m.loop_mapping = 'POLYINTERP_NEAREST'
            m.mix_factor = p.normal_mix
            m.show_viewport = not preview_hidden
        else:
            skipped_normal = True

    bind_decal_target(obj, target)          # 名字 + 持久ID 双重关联
    if not preview_hidden:
        for slot in obj.material_slots:
            mat = slot.material
            if (edge_enabled(mat)
                    and (getattr(mat, "sd_edge_weight", 0.0) > 0.0
                         or bool(slot_nodes(mat, SLOT_EDGE)))):
                ensure_geometry_edge_field(
                    obj, target, mat.sd_edge_angle, mat.sd_edge_width)
    ensure_smooth_shading(obj)
    return skipped_normal


def parent_keep_transform(obj, target):
    """父级到目标且保持世界变换, 目标移动时贴花跟随。"""
    obj.parent = target
    obj.matrix_parent_inverse = target.matrix_world.inverted()


def clear_parent_keep_transform(obj):
    """解除真实父级但保持世界变换；持久目标绑定由 IDProperties 继续维护。"""
    if obj is None or obj.parent is None:
        return False
    world_matrix = obj.matrix_world.copy()
    obj.parent = None
    obj.matrix_parent_inverse = Matrix.Identity(4)
    obj.matrix_world = world_matrix
    return True


def conform_object(obj, target, p):
    """吸附单个物体: 修改器栈 + 可选父级。返回是否跳过法线融合。"""
    skipped = build_stack(obj, target, p)
    if p.parent_to_target:
        parent_keep_transform(obj, target)
    return skipped


def matrices_close(a, b, tol=1e-4):
    """两个4x4矩阵是否逐元素接近。"""
    for i in range(4):
        for j in range(4):
            if abs(a[i][j] - b[i][j]) > tol:
                return False
    return True


def collect_boolean_cutters(objects):
    """收集被布尔修改器引用的物体名(含集合操作数)。"""
    cutters = set()
    for o in objects:
        for m in o.modifiers:
            if m.type != 'BOOLEAN':
                continue
            ob = getattr(m, "object", None)
            if ob is not None:
                cutters.add(ob.name)
            col = getattr(m, "collection", None)
            if col is not None:
                for c in col.all_objects:
                    cutters.add(c.name)
    return cutters


def is_cutter_like(obj, cutters):
    """是否像布尔切割体: 线框/边界框显示, 或被任一布尔修改器引用。"""
    return (obj.display_type in {'WIRE', 'BOUNDS'}
            or (cutters is not None and obj.name in cutters))


def safe_hide(obj, state):
    """隐藏/显示物体; 物体不在当前视图层时静默跳过(避免崩溃)。"""
    try:
        obj.hide_set(state)
    except RuntimeError:
        pass


def instance_source_matrix(empty):
    """集合实例的空间映射: 源世界坐标 → 实例世界坐标。"""
    col = empty.instance_collection
    return empty.matrix_world @ Matrix.Translation(-col.instance_offset)


def find_instance_empty(context, orig, inst_mat):
    """根据射线命中的实例矩阵, 反查对应的集合实例空物体(用于父级)。"""
    try:
        want = inst_mat @ orig.matrix_world.inverted()
    except ValueError:
        return None
    for e in context.scene.objects:
        if e.type != 'EMPTY' or e.instance_collection is None:
            continue
        if e.instance_collection.all_objects.get(orig.name) is None:
            continue
        if matrices_close(instance_source_matrix(e), want, 1e-3):
            return e
    return None


def target_is_heavy(context, target, limit):
    """目标求值后的面数是否超过实时预览上限。"""
    if limit <= 0:
        return False
    try:
        ev = target.evaluated_get(context.evaluated_depsgraph_get())
        return len(ev.data.polygons) > limit
    except (AttributeError, RuntimeError):
        return False


def snap_object_to_surface(context, obj, target):
    """把物体挪到目标最近表面点, +Z对齐表面法线(最小弧旋转, 保留绕法线自转)。
    用求值后的目标网格(包含阵列等修改器的结果)。"""
    depsgraph = context.evaluated_depsgraph_get()
    inv = target.matrix_world.inverted()
    loc_local = inv @ obj.matrix_world.translation
    try:
        ok, co, normal, _idx = target.evaluated_get(
            depsgraph).closest_point_on_mesh(loc_local)
    except RuntimeError:
        return False
    if not ok:
        return False
    world_co = target.matrix_world @ co
    n_world = (inv.transposed().to_3x3() @ normal).normalized()
    mw = obj.matrix_world
    cur_z = (mw.to_3x3() @ Vector((0.0, 0.0, 1.0))).normalized()
    delta = cur_z.rotation_difference(n_world)
    obj.matrix_world = Matrix.LocRotScale(
        world_co, delta @ mw.to_quaternion(), mw.to_scale())
    return True


def find_view3d_context(context):
    """找一个非临时窗口里的3D视口, 返回 (window, area, region)。"""
    for win in context.window_manager.windows:
        scr = win.screen
        if scr is None or getattr(scr, "is_temporary", False):
            continue                            # 跳过文件浏览器等临时窗口
        for area in scr.areas:
            if area.type == 'VIEW_3D':
                for region in area.regions:
                    if region.type == 'WINDOW':
                        return win, area, region
    return None, None, None


def _deferred_place():
    """定时器回调: 等文件浏览器关闭、主界面恢复后再启动交互投放。
    在导入的 execute 里直接跨窗口起 modal 会与撤销快照打架。"""
    win, area, region = find_view3d_context(bpy.context)
    if win is None:
        return None
    try:
        with bpy.context.temp_override(window=win, area=area, region=region):
            bpy.ops.surfdecal.place('INVOKE_DEFAULT', use_selected=True)
    except RuntimeError:
        pass
    return None                                 # 返回None=只执行一次


def schedule_deferred_place():
    """合并重复请求，在文件浏览器退出后启动所选贴花的交互投放。"""
    if not bpy.app.timers.is_registered(_deferred_place):
        bpy.app.timers.register(_deferred_place, first_interval=0.0)


def resolve_target(context, exclude=None):
    """吸附目标 = 所选: 活动网格优先, 否则任一所选网格。
    默认先避开布尔切割体, 若所选只剩切割体则放行(尊重明确意图)。"""
    p = context.scene.surfdecal
    cutters = (collect_boolean_cutters(context.scene.objects)
               if p.ignore_cutters else None)
    ao = context.active_object
    for strict in (True, False):
        for o in ([ao] if ao is not None else []) + list(
                context.selected_objects):
            if o is None or o.type != 'MESH' or o is exclude:
                continue
            if strict and cutters is not None and is_cutter_like(o, cutters):
                continue
            return o
    return None


def make_decal_mesh(name, size_x, size_y, div):
    """创建带 0-1 UV 的贴花面片网格。"""
    verts, faces = grid_data(size_x, size_y, div)
    me = bpy.data.meshes.new(name)
    me.from_pydata(verts, [], faces)
    me.update()
    uv = me.uv_layers.new(name="UVMap")
    ix = 1.0 / size_x if size_x else 1.0
    iy = 1.0 / size_y if size_y else 1.0
    for loop in me.loops:
        co = me.vertices[loop.vertex_index].co
        uv.data[loop.index].uv = (co.x * ix + 0.5, co.y * iy + 0.5)
    return me


def add_planar_uvs(me):
    """按 XY 包围盒生成平面 UV(导入图形用)。"""
    if not me.loops or me.uv_layers:
        return                              # 已有UV则不重复创建
    xs = [v.co.x for v in me.vertices]
    ys = [v.co.y for v in me.vertices]
    minx, miny = min(xs), min(ys)
    d = max(max(xs) - minx, max(ys) - miny) or 1.0
    uv = me.uv_layers.new(name="UVMap")
    for loop in me.loops:
        co = me.vertices[loop.vertex_index].co
        uv.data[loop.index].uv = ((co.x - minx) / d, (co.y - miny) / d)


def mesh_face_up(me):
    """平面网格统一朝 +Z(法线朝下则整体翻转)。"""
    if me.polygons and sum(f.normal.z for f in me.polygons) < 0.0:
        me.flip_normals()


def merge_close_verts(me, dist=1e-6):
    """按距离合并顶点(导入合并后的保险清理)。"""
    bm = bmesh.new()
    bm.from_mesh(me)
    bmesh.ops.remove_doubles(bm, verts=bm.verts, dist=dist)
    bm.to_mesh(me)
    bm.free()
    me.update()


def new_mesh_from_object(obj, depsgraph):
    """取物体求值后的网格数据副本(等价"转换为网格", 不依赖操作符上下文)。
    物体必须已链接到场景中 depsgraph 才能求值它; 无几何时返回 None。"""
    try:
        me = bpy.data.meshes.new_from_object(obj.evaluated_get(depsgraph))
    except RuntimeError:
        return None
    if me is not None and len(me.vertices) == 0:
        bpy.data.meshes.remove(me)
        return None
    return me


def replace_with_mesh_object(context, obj, depsgraph):
    """把曲线/文字物体原位替换为网格物体(同名同变换同集合)。
    失败(无可填充几何)返回 None 且保留原物体。"""
    me = new_mesh_from_object(obj, depsgraph)
    if me is None:
        return None
    new = bpy.data.objects.new(obj.name, me)
    new.matrix_world = obj.matrix_world.copy()
    cols = list(obj.users_collection) or [context.collection]
    for c in cols:
        c.objects.link(new)
    old_name = obj.name
    data, otype = obj.data, obj.type
    bpy.data.objects.remove(obj, do_unlink=True)
    if data is not None and data.users == 0 and otype in {'CURVE', 'FONT'}:
        bpy.data.curves.remove(data)        # FONT 数据也存于 bpy.data.curves
    new.name = old_name
    try:
        new.select_set(True)
    except RuntimeError:
        pass                                # 不在当前视图层时忽略
    return new


def join_mesh_datas(mesh_list, name):
    """bmesh 累加合并多个网格数据块(替代 join 操作符, 上下文无关)。"""
    bm = bmesh.new()
    for me in mesh_list:
        bm.from_mesh(me)
    joined = bpy.data.meshes.new(name)
    bm.to_mesh(joined)
    bm.free()
    return joined


KEY_MAT_SIG = "sd_sig"
LEGACY_WEAR_TAG = "SDW_"  # 只识别旧文件节点，不再创建旧磨损系统


def decal_mat_signature(image, blend, luma, hard):
    """同一张图 + 同一套设置 → 同一个签名 → 共享同一个材质。"""
    return "%s|%s|%d|%d" % (image.name if image else "", blend,
                            int(bool(luma)), int(bool(hard)))


def material_is_customized(mat):
    """材质是否已被定制过(接入 Bridge / 磨损 / 边缘 / 匹配 / 浮雕节点)。
    定制过的材质不能再被新贴花共享 —— 签名只记"图+设置", 接了磨损也不会变,
    所以单看签名会让新导入的贴花认领别人调好的材质。"""
    if mat is None or not mat.use_nodes:
        return False
    if mat.get(KEY_NO_MERGE):
        return True
    for n in mat.node_tree.nodes:
        if n.name.startswith((MATCH_TAG, LEGACY_WEAR_TAG, RELIEF_TAG,
                              SLOT_WEAR, SLOT_EDGE, SPLIT_TAG,
                              TINT_TAG)):
            return True
        if (n.bl_idname == 'ShaderNodeGroup' and n.node_tree is not None
                and n.node_tree.name == BRIDGE_GROUP):
            return True
    return False


def find_shared_decal_material(sig):
    """找可共享的贴花材质: 签名相同 且 尚未被定制。"""
    for m in bpy.data.materials:
        if (m.get(KEY_MAT_SIG) == sig and m.use_nodes
                and not material_is_customized(m)):
            return m
    return None


def make_alpha_decal_material(name, image, blend, luma_alpha=False,
                              hard_alpha=False):
    """图像→BaseColor/Alpha 的贴花透明材质。
    blend: 'CLIP'/'HASHED'/'BLEND'; luma_alpha: 无alpha通道时用明度当alpha。
    节点按 bl_idname 查找(开启"翻译新建数据"时默认节点名会被本地化);
    混合/阴影属性按版本 hasattr 设置(旧EEVEE与4.2+ EEVEE Next字段不同)。"""
    mat = bpy.data.materials.new(name)
    mat.use_nodes = True
    nt = mat.node_tree
    bsdf = next((n for n in nt.nodes
                 if n.bl_idname == 'ShaderNodeBsdfPrincipled'), None)
    out = next((n for n in nt.nodes
                if n.bl_idname == 'ShaderNodeOutputMaterial'), None)
    if bsdf is None:
        bsdf = nt.nodes.new('ShaderNodeBsdfPrincipled')
    if out is None:
        out = nt.nodes.new('ShaderNodeOutputMaterial')
    if not out.inputs["Surface"].links:
        nt.links.new(bsdf.outputs["BSDF"], out.inputs["Surface"])

    tex = nt.nodes.new('ShaderNodeTexImage')
    tex.image = image
    tex.location = (bsdf.location.x - 360.0, bsdf.location.y - 40.0)
    nt.links.new(tex.outputs["Color"], bsdf.inputs["Base Color"])
    a_src = tex.outputs["Alpha"]
    if luma_alpha:
        bw = nt.nodes.new('ShaderNodeRGBToBW')
        bw.location = (bsdf.location.x - 170.0, bsdf.location.y - 260.0)
        nt.links.new(tex.outputs["Color"], bw.inputs["Color"])
        a_src = bw.outputs["Val"]
    if hard_alpha:                          # 量化到0/1: 光追下边缘才干净
        gt = nt.nodes.new('ShaderNodeMath')
        gt.operation = 'GREATER_THAN'
        gt.name = "Alpha硬化"
        gt.inputs[1].default_value = 0.5
        gt.location = (bsdf.location.x - 170.0, bsdf.location.y - 400.0)
        nt.links.new(a_src, gt.inputs[0])
        a_src = gt.outputs[0]
    nt.links.new(a_src, bsdf.inputs["Alpha"])

    # Cycles: Alpha 输入本身就是透明, 没有混合模式可选。
    # blend 只保留在材质签名里, 用于区分不同批次的贴花材质。
    mat.use_transparent_shadow = True           # 镂空处不投影
    mat.use_backface_culling = True             # 单面贴花; 仅影响实体视图
    mat[KEY_MAT_SIG] = decal_mat_signature(image, blend, luma_alpha,
                                           hard_alpha)
    return mat


def normalize_flat_object(context, obj, width):
    """把物体变换烘入网格, 按包围盒居中并缩放到指定宽度, 放到 3D 游标。"""
    me = obj.data
    me.transform(obj.matrix_world)
    obj.matrix_world = Matrix.Identity(4)
    xs = [v.co.x for v in me.vertices]
    ys = [v.co.y for v in me.vertices]
    if not xs:
        return
    minx, maxx = min(xs), max(xs)
    miny, maxy = min(ys), max(ys)
    w = maxx - minx
    s = width / w if w > 1e-9 else 1.0
    cx = (minx + maxx) * 0.5
    cy = (miny + maxy) * 0.5
    me.transform(Matrix.Translation((-cx * s, -cy * s, 0.0))
                 @ Matrix.Diagonal((s, s, s, 1.0)))
    me.update()
    obj.location = context.scene.cursor.location


def bake_conform_instanced(context, decal, target, p, world_loc, inst_mat,
                           quat, scale):
    """组实例目标的一次性烘焙贴合:
    换算到源空间就位 → 建栈 → 求值烘入网格 → 变换回实例位置 →
    尝试父级到实例空物体。实例无法被修改器实时跟随, 只能烘焙。
    返回 (ok, skipped_normal, empty_or_None)。"""
    src_fix = target.matrix_world @ inst_mat.inverted()   # 实例世界→源世界
    decal.matrix_world = src_fix @ Matrix.LocRotScale(world_loc, quat, scale)
    skipped = build_stack(decal, target, p)
    depsgraph = context.evaluated_depsgraph_get()
    me = None
    try:
        me = bpy.data.meshes.new_from_object(
            decal.evaluated_get(depsgraph),
            preserve_all_data_layers=True, depsgraph=depsgraph)
    except RuntimeError:
        me = None
    if me is None or len(me.vertices) == 0:
        if me is not None:
            bpy.data.meshes.remove(me)
        clear_stack(decal)
        return False, skipped, None
    old = decal.data
    decal.data = me                             # 材质随网格数据保留
    clear_stack(decal)
    if KEY_TARGET in decal:
        del decal[KEY_TARGET]
    if old.users == 0:
        bpy.data.meshes.remove(old)
    ensure_smooth_shading(decal)
    decal.matrix_world = (inst_mat @ target.matrix_world.inverted()
                          @ decal.matrix_world)  # 源世界→实例世界
    empty = find_instance_empty(context, target, inst_mat)
    if empty is not None and getattr(p, "parent_to_target", True):
        parent_keep_transform(decal, empty)
    return True, skipped, empty


def conform_to_instance_empty(context, decal, empty, p, anchor_world):
    """把贴花吸附到组实例(空物体)上: 在源空间找离锚点最近的网格表面,
    烘焙贴合后回到实例位置。返回 (ok, skipped_normal)。"""
    col = empty.instance_collection
    M_i = instance_source_matrix(empty)
    p_src = M_i.inverted() @ Vector(anchor_world)          # 锚点→源世界
    depsgraph = context.evaluated_depsgraph_get()
    cutters = (collect_boolean_cutters(col.all_objects)
               if getattr(p, "ignore_cutters", True) else None)
    best = None
    for m in col.all_objects:
        if m.type != 'MESH':
            continue
        if cutters is not None and is_cutter_like(m, cutters):
            continue                            # 组内切割体不作为吸附面
        inv = m.matrix_world.inverted()
        try:
            ok, co, normal, _i = m.evaluated_get(
                depsgraph).closest_point_on_mesh(inv @ p_src)
        except RuntimeError:
            continue
        if not ok:
            continue
        w = m.matrix_world @ co
        d = (w - p_src).length
        if best is None or d < best[0]:
            n_w = (inv.transposed().to_3x3() @ normal).normalized()
            best = (d, m, w, n_w)
    if best is None:
        return False, False
    _d, target, co_src, n_src = best
    inst_mat = M_i @ target.matrix_world
    loc_inst = M_i @ co_src
    n_inst = (M_i.inverted().transposed().to_3x3() @ n_src).normalized()
    quat = n_inst.to_track_quat('Z', 'Y')
    ok, skipped, _e = bake_conform_instanced(
        context, decal, target, p, loc_inst, inst_mat,
        quat, decal.matrix_world.to_scale())
    return ok, skipped


def resolve_import_target(context):
    """导入吸附目标: 活动物体 > 任一所选; 网格或组实例空物体。"""
    p = context.scene.surfdecal
    cutters = (collect_boolean_cutters(context.scene.objects)
               if p.ignore_cutters else None)
    active = context.active_object
    # 活动物体决定“吸附到所选物体”的语义。贴花虽然也是 Mesh，但不能
    # 成为另一张贴花的目标；此时由导入收尾统一回退到交互投放。
    if active is not None and is_decal(active):
        return None
    cands = []
    if active is not None:
        cands.append(active)
    cands.extend(context.selected_objects)
    for strict in (True, False):
        for o in cands:
            if o is None:
                continue
            if o.type == 'MESH':
                if is_decal(o):
                    continue
                if (strict and cutters is not None
                        and is_cutter_like(o, cutters)):
                    continue
                return o
            if o.type == 'EMPTY' and o.instance_collection is not None:
                return o
    return None


def finish_imported_decal(op, context, obj, p, after, target):
    """导入收尾: UV、法线朝上、选中激活; 按选择进入交互投放/直接吸附/仅导入。"""
    mesh_face_up(obj.data)
    add_planar_uvs(obj.data)
    for o in context.selected_objects:
        o.select_set(False)
    obj.select_set(True)
    context.view_layer.objects.active = obj

    auto_name_decal(obj, target)            # 有无目标都立即同步命名对象与材质
    if after == 'CONFORM' and target is None:
        after = 'PLACE'
        op.report({'WARNING'},
                  "没有有效的吸附目标（贴花不能作为目标），已自动切换为交互投放")
    if after == 'CONFORM':
        if target.type == 'EMPTY':
            ok, skipped = conform_to_instance_empty(
                context, obj, target, p, target.matrix_world.translation)
            if not ok:
                schedule_deferred_place()
                op.report({'WARNING'},
                          "组实例内未找到可吸附网格，已自动切换为交互投放")
                return
            msg = "已吸附到组实例 %s (烘焙贴合, 随组移动)" % target.name
        else:
            obj.location = target.matrix_world.translation  # 锚到目标原点
            snap_object_to_surface(context, obj, target)
            skipped = conform_object(obj, target, p)
            msg = "已吸附到 %s (G移动可在表面滑动)" % target.name
        if skipped:
            msg += " (目标为平直着色, 已跳过法线融合)"
        op.report({'INFO'}, msg)
        return
    if after == 'PLACE':
        # 不在文件浏览器上下文里直接起modal, 交给定时器在下个主循环启动
        schedule_deferred_place()
        op.report({'INFO'}, "已导入, 进入交互投放: 把鼠标移到表面上摆放")
        return
    op.report({'INFO'},
              "已导入到3D游标; 可用[投放所选物体]或[吸附所选到目标]")


# ============================================================
#  属性
# ============================================================


def _match_settings_update(self, context):
    """已建立匹配后，面板参数变化直接重建目标通道，不要求再次点按钮。"""
    try:
        if context is None or context.scene is None:
            return
        decals, _targets = gather_scope(context, self)
        seen = set()
        for decal in decals:
            target = decal_target_of(context, decal) or decal.parent
            if target is None or not target.material_slots:
                continue
            target_mat = target.material_slots[0].material
            uv_name = None
            if target.type == 'MESH' and uv_health(target)[0]:
                uv_name = ensure_target_uv(decal, target, context)
            for slot in decal.material_slots:
                mat = slot.material
                if mat is None or mat.as_pointer() in seen:
                    continue
                seen.add(mat.as_pointer())
                match_target_material(mat, target_mat, target, uv_name, self)
    except (AttributeError, RuntimeError, ReferenceError):
        pass


class SD_Props(bpy.types.PropertyGroup):
    parent_to_target: bpy.props.BoolProperty(
        name="父级到目标", default=True,
        description="投放/吸附后把贴花设为目标的子级, 跟随目标一起移动")
    size: bpy.props.FloatProperty(
        name="贴花尺寸", default=0.5, min=0.001,
        subtype='DISTANCE', description="交互投放时贴花平面的边长")
    grid: bpy.props.IntProperty(
        name="底面网格", default=6, min=1, max=64,
        description="投放平面每边的面数")
    # RNA 标识沿用 4.x 的 auto_subdiv 以读取旧 .blend；实际语义已迁到固化阶段。
    auto_subdiv: bpy.props.BoolProperty(
        name="固化时优化平面细分", default=True,
        description="编辑时始终保留完整细分；固化前检测贴花覆盖区域，"
                    "纯平面移除无意义的细分，曲面与硬折面保留并固化")
    subsurf_levels: bpy.props.IntProperty(
        name="细分级别", default=2, min=0, max=4,
        description="编辑阶段使用的简单细分级别(不改形状)，"
                    "为曲面与硬折面贴合提供足够顶点")
    offset: bpy.props.FloatProperty(
        name="悬浮间距", default=0.002, min=0.0,
        precision=4, step=0.1, subtype='DISTANCE',
        description="贴花悬浮在表面上方的距离, 防止深度冲突闪烁; 曲率越大需要越大")
    wrap_method: bpy.props.EnumProperty(
        name="吸附方式",
        items=[
            ('PROJECT', "沿法线投射",
             "沿贴花自身Z轴双向投射, 硬边/开口处稳定(推荐); "
             "投射深度0=按贴花尺寸自动限深"),
            ('NEAREST_SURFACEPOINT', "最近表面点",
             "各方向吸附, G移动可在表面滑动; 跨硬边会折叠"),
        ],
        default='PROJECT')
    project_limit: bpy.props.FloatProperty(
        name="投射深度", default=0.0, min=0.0, subtype='DISTANCE',
        description="投射距离上限; 0=按贴花包围尺寸自动限制"
                    "(防止溢出部分射穿开口贴到后方表面)")
    live_limit: bpy.props.IntProperty(
        name="实时预览面数上限", default=200000, min=0, soft_max=5000000,
        description="目标求值后面数超过此值时, 投放预览阶段隐藏吸附/法线修改器"
                    "(确认后生效), 防止大场景逐帧重建BVH卡顿; 0=始终实时")
    library_item: bpy.props.EnumProperty(
        name="贴花库", items=library_enum_items,
        description="曾导入/使用过的贴花与库文件夹中的文件")
    lib_width: bpy.props.FloatProperty(
        name="放置宽度", default=0.5, min=0.001, subtype='DISTANCE',
        description="从贴花库放置时的物理宽度(高度按图像比例)")
    lib_after: bpy.props.EnumProperty(
        name="放置后",
        items=[
            ('CONFORM', "吸附到选中物体", "吸附到当前选中的网格或组实例"),
            ('PLACE', "进入交互投放", "在表面滑动摆放"),
            ('NONE', "仅放到游标", "只创建物体"),
        ],
        default='CONFORM')
    match_rough: bpy.props.BoolProperty(
        name="粗糙度", default=True,
        description="把目标的粗糙度复制给贴花(常量抄数值, 贴图整链复制)",
        update=_match_settings_update)
    match_rough_offset: bpy.props.FloatProperty(
        name="粗糙度偏移", default=0.0, min=-0.5, max=0.5,
        description="默认0=与目标完全一致。想要喷漆/丝印的手感可给 "
                    "0.05~0.15, 让标识比基底略糙",
        update=_match_settings_update)
    match_normal: bpy.props.BoolProperty(
        name="微表面法线", default=False,
        description="接入目标的法线贴图(绑定传入UV)。切线空间朝向不一致时"
                    "方向会错 —— 看着不对就关掉, 大尺度法线由法线融合负责",
        update=_match_settings_update)
    match_normal_strength: bpy.props.FloatProperty(
        name="法线强度", default=0.4, min=0.0, max=2.0,
        update=_match_settings_update)
    match_wear: bpy.props.BoolProperty(
        name="磨损侵蚀", default=False,
        description="用目标的污渍侵蚀贴花Alpha(独立的磨损系统更好用)",
        update=_match_settings_update)
    match_wear_source: bpy.props.EnumProperty(
        name="磨损来源",
        items=[
            ('ROUGH', "目标粗糙度", "复用已复制的粗糙度链(需开启粗糙度匹配)"),
            ('BASE', "目标基础色", "用目标的基础色贴图作污渍依据"),
            ('IMAGE', "指定图像", "自己指定一张污渍/磨损图"),
        ],
        default='ROUGH', update=_match_settings_update)
    match_wear_image: bpy.props.PointerProperty(
        name="磨损贴图", type=bpy.types.Image, update=_match_settings_update)
    match_wear_threshold: bpy.props.FloatProperty(
        name="阈值", default=0.5, min=0.0, max=1.0,
        update=_match_settings_update)
    match_wear_softness: bpy.props.FloatProperty(
        name="过渡宽度", default=0.25, min=0.01, max=1.0,
        update=_match_settings_update)
    match_wear_invert: bpy.props.BoolProperty(
        name="反相", default=False,
        description="约定白=保留图案; 磨损图相反时勾上",
        update=_match_settings_update)
    match_wear_amount: bpy.props.FloatProperty(
        name="侵蚀强度", default=0.0, min=0.0, max=1.0,
        description="0=不用这条(推荐用独立的磨损系统)",
        update=_match_settings_update)
    scope: bpy.props.EnumProperty(
        name="作用范围",
        items=[
            ('TARGET', "整个表面的贴花",
             "选中墙面或其上任一张贴花, 处理该目标上的全部贴花(推荐)"),
            ('SELECTED', "仅所选贴花", "只处理当前选中的贴花"),
            ('ALL', "场景中全部贴花", "一次性统一整个场景"),
        ],
        default='TARGET')


    share_materials: bpy.props.BoolProperty(
        name="同图共享材质", default=True,
        description="导入时同一张贴图+同一套设置的贴花共用一个材质, 避免材质槽"
                    "爆炸。之后给某张单独加磨损/粗糙度匹配时会自动分家(写时复制), "
                    "整面统一处理时则继续共享")
    ignore_cutters: bpy.props.BoolProperty(
        name="忽略布尔切割体", default=True,
        description="投放/吸附时穿过线框(边界框)显示或被布尔修改器引用的"
                    "切割体, 直接命中切割后的表面(切口壁)")
    use_normal_transfer: bpy.props.BoolProperty(
        name="法线融合", default=True,
        description="从目标传递自定义法线, 贴花着色与曲面无缝衔接; 目标为平直着色时自动跳过")
    normal_mix: bpy.props.FloatProperty(
        name="融合强度", default=1.0, min=0.0, max=1.0)
    use_solidify: bpy.props.BoolProperty(
        name="实体化厚度", default=False,
        description="给贴花加厚度, 做凸起面板/铭牌/格栅")
    thickness: bpy.props.FloatProperty(
        name="厚度", default=0.01, min=0.0, subtype='DISTANCE')


# ============================================================
#  操作符: 交互投放(新建平面 / 投放所选)
# ============================================================

class SURFDECAL_OT_place(bpy.types.Operator):
    """在物体表面移动鼠标实时预览吸附效果。
滚轮: 缩放  R: 旋转15°(Shift反向)
左键: 确认  Shift+左键: 连续投放(盖章)  右键/Esc: 结束"""
    bl_idname = "surfdecal.place"
    bl_label = "交互投放贴花"
    bl_options = {'REGISTER'}                   # 撤销由每次确认手动push

    use_selected: bpy.props.BoolProperty(
        name="投放所选物体", default=False,
        options={'HIDDEN', 'SKIP_SAVE'},
        description="用活动网格物体作为贴花(而非新建平面)")

    @classmethod
    def poll(cls, context):
        return context.mode == 'OBJECT'

    def invoke(self, context, event):
        area = context.area
        # 延迟导入会借用任意 VIEW_3D 上下文来启动 modal；多视口布局中，
        # 那个借用视口不一定是鼠标实际所在的视口。优先按窗口坐标重新定位
        # 鼠标所在的 VIEW_3D Area（鼠标在其侧栏/标题栏内也算该 Area）。
        win = context.window
        screen = win.screen if win is not None else None
        if screen is not None:
            for candidate in screen.areas:
                if (candidate.type == 'VIEW_3D'
                        and candidate.x <= event.mouse_x
                        < candidate.x + candidate.width
                        and candidate.y <= event.mouse_y
                        < candidate.y + candidate.height):
                    area = candidate
                    break
        if area is None or area.type != 'VIEW_3D':
            self.report({'WARNING'}, "请在3D视口中使用")
            return {'CANCELLED'}
        region = None
        for r in area.regions:
            if r.type == 'WINDOW':
                region = r
                break
        rv3d = getattr(area.spaces.active, "region_3d", None)
        if region is None or rv3d is None:
            self.report({'WARNING'}, "未找到可用的3D视口区域")
            return {'CANCELLED'}
        self._area = area                       # 锁定视口, 不随鼠标位置漂移
        self._region = region
        self._rv3d = rv3d

        p = context.scene.surfdecal
        self._cutters = (collect_boolean_cutters(context.scene.objects)
                         if p.ignore_cutters else None)
        self.decal = None
        self.owns_decal = True          # 由本操作创建(取消时删除)
        self.target = None
        self.angle = 0.0
        self.scale_factor = 1.0
        self.base_scale = Vector((1.0, 1.0, 1.0))
        self.last_hit = None
        self.placed = 0
        self._instanced = False                 # 当前命中的是组实例
        self._inst_mat = Matrix.Identity(4)     # 命中实例副本的世界矩阵
        self._heavy = False                     # 目标超重: 预览隐藏重修改器
        self._stack_params = None               # 所选贴花的原有栈设置快照
        self._restore = None            # 投放所选物体取消时的还原信息

        if self.use_selected:
            obj = context.active_object
            if obj is None or obj.type != 'MESH':
                self.report({'ERROR'}, "请先选中一个网格物体作为贴花")
                return {'CANCELLED'}
            self.decal = obj
            self.owns_decal = False
            self.base_scale = obj.matrix_world.to_scale()
            # 保留原有绕法线的自转: 从当前朝向反解 track 框架下的扭转角
            q = obj.matrix_world.to_quaternion()
            z_axis = (q @ Vector((0.0, 0.0, 1.0))).normalized()
            twist = z_axis.to_track_quat('Z', 'Y').inverted() @ q
            self.angle = 2.0 * math.atan2(twist.z, twist.w)
            # 保留该贴花现有的吸附方式/间距/细分/厚度/法线融合设置
            self._stack_params = (stack_params_for(obj, None)
                                  if is_decal(obj) else None)
            self._restore = {
                "matrix": obj.matrix_world.copy(),
                "parent": obj.parent,
                "pinv": obj.matrix_parent_inverse.copy(),
                "key": obj.get(KEY_TARGET, None),
                "had_stack": is_decal(obj),
                "cols": list(obj.users_collection),
            }

        context.window_manager.modal_handler_add(self)
        context.workspace.status_text_set(
            "移动: 定位 | 滚轮: 缩放 | R: 旋转15°(Shift反向) | "
            "左键: 确认  Shift+左键: 连续投放 | 右键/Esc: 结束")
        self._update(context, event)
        return {'RUNNING_MODAL'}

    def modal(self, context, event):
        try:
            self._area.tag_redraw()
        except ReferenceError:                  # 视口区域已被关闭
            self._discard_preview(context)
            return self._finish(context)

        if event.type == 'MOUSEMOVE':
            self._update(context, event)

        elif event.type in {'WHEELUPMOUSE', 'WHEELDOWNMOUSE'}:
            if event.ctrl:                      # Ctrl+滚轮留给视图缩放
                return {'PASS_THROUGH'}
            self.scale_factor *= 1.1 if event.type == 'WHEELUPMOUSE' else 1.0 / 1.1
            self._apply_transform()

        elif event.type == 'R' and event.value == 'PRESS':
            self.angle += math.radians(-15.0 if event.shift else 15.0)
            self._apply_transform()

        elif event.type == 'LEFTMOUSE' and event.value == 'PRESS':
            if self.last_hit is None:
                self.report({'WARNING'}, "当前鼠标位置没有可吸附表面")
                return {'RUNNING_MODAL'}
            if self.decal is not None and self.target is not None:
                self._confirm(context)
                self.placed += 1
                if event.shift:
                    self._continue_with_duplicate(context)
                else:
                    return self._finish(context)

        elif event.type in {'RIGHTMOUSE', 'ESC'}:
            self._discard_preview(context)
            return self._finish(context)

        elif event.type == 'MIDDLEMOUSE':       # 视图旋转/平移直通
            return {'PASS_THROUGH'}

        return {'RUNNING_MODAL'}

    # ----- 内部 -----

    def _ray(self, context, origin, direction, tries=12):
        """场景射线检测: 穿透预览贴花自身与布尔切割体(线框显示或被布尔
        引用), 直接命中切割后的表面。
        返回 (命中点, 法线, 源物体, 命中实例的世界矩阵) —— 命中集合实例时
        矩阵是该实例副本的, 与源物体自身矩阵不同, 用于空间换算。"""
        scene = context.scene
        depsgraph = context.evaluated_depsgraph_get()
        for _ in range(tries):
            result, loc, normal, _idx, obj, mat = scene.ray_cast(
                depsgraph, origin, direction)
            if not result:
                return None
            orig = obj.original if obj is not None else None
            if (orig is not None and orig is not self.decal
                    and orig.type == 'MESH'
                    and not (self._cutters is not None
                             and is_cutter_like(orig, self._cutters))):
                return loc, normal.normalized(), orig, mat.copy()
            origin = loc + direction * 1e-4     # 穿过: 贴花自身/切割体/非网格
        return None

    def _update(self, context, event):
        region = self._region
        mx = event.mouse_x - region.x           # 窗口坐标 → 区域坐标
        my = event.mouse_y - region.y
        if not (0 <= mx < region.width and 0 <= my < region.height):
            if self.decal is not None:          # 鼠标在锁定视口之外: 隐藏预览
                safe_hide(self.decal, True)
            self.last_hit = None
            return
        coord = (mx, my)
        direction = view3d_utils.region_2d_to_vector_3d(region, self._rv3d, coord)
        origin = view3d_utils.region_2d_to_origin_3d(region, self._rv3d, coord)
        hit = self._ray(context, origin, direction)
        if hit is None:
            if self.decal is not None:
                safe_hide(self.decal, True)
            self.last_hit = None
            return

        loc, normal, target, inst_mat = hit
        p = context.scene.surfdecal
        if self.decal is None:                  # 平面模式: 首次命中才创建
            me = make_decal_mesh("贴花", p.size, p.size, p.grid)
            self.decal = bpy.data.objects.new("贴花", me)
            context.collection.objects.link(self.decal)
        safe_hide(self.decal, False)

        instanced = not matrices_close(inst_mat, target.matrix_world)
        if target is not self.target or instanced != self._instanced:
            self.target = target
            self._instanced = instanced
            self._inst_mat = inst_mat.copy()
            if instanced:                       # 组实例: 预览刚性, 确认时烘焙
                clear_stack(self.decal)
                self.report({'INFO'},
                            "组实例目标: 预览为刚性, 确认时烘焙贴合")
            else:
                self._heavy = target_is_heavy(context, target, p.live_limit)
                sp = self._stack_params if self._stack_params is not None else p
                build_stack(self.decal, target, sp,
                            preview_hidden=self._heavy)
                if self._heavy:
                    self.report({'INFO'}, "目标较重: 预览为刚性, 确认后贴合")
        elif instanced:
            self._inst_mat = inst_mat.copy()    # 同目标的另一个实例副本
        self.last_hit = (loc, normal)
        self._apply_transform()

    def _apply_transform(self):
        if self.decal is None or self.last_hit is None:
            return
        loc, normal = self.last_hit
        quat = (normal.to_track_quat('Z', 'Y')
                @ Quaternion((0.0, 0.0, 1.0), self.angle))
        self.decal.matrix_world = Matrix.LocRotScale(
            loc, quat, self.base_scale * self.scale_factor)

    def _confirm(self, context):
        p = context.scene.surfdecal
        sp = self._stack_params if self._stack_params is not None else p
        d = self.decal
        if self._instanced:                     # 组实例: 一次性烘焙贴合
            loc, normal = self.last_hit
            quat = (normal.to_track_quat('Z', 'Y')
                    @ Quaternion((0.0, 0.0, 1.0), self.angle))
            ok, skipped, empty = bake_conform_instanced(
                context, d, self.target, sp, loc, self._inst_mat,
                quat, self.base_scale * self.scale_factor)
            if not ok:
                self.report({'WARNING'}, "组实例烘焙贴合失败, 保留为刚性放置")
            else:
                self.report({'INFO'},
                            "已烘焙贴合到组实例" + ("" if empty is not None
                            else " (未找到实例空物体, 不随组移动)"))
        else:
            skipped = build_stack(d, self.target, sp)  # 确认: 按快照全量重建
            if p.parent_to_target:
                parent_keep_transform(d, self.target)
        auto_name_decal(d, self.target)      # 投放即统一命名
        try:
            for o in context.selected_objects:
                o.select_set(False)
            d.select_set(True)
            context.view_layer.objects.active = d
        except RuntimeError:
            pass
        if skipped:
            self.report({'INFO'},
                        "目标 %s 为平直着色, 已跳过法线融合" % self.target.name)

    def _continue_with_duplicate(self, context):
        """Shift确认后复制一份继续投放(共享网格数据的盖章模式)。"""
        src = self.decal
        new = src.copy()                        # 修改器随物体复制, 网格数据共享
        cols = list(src.users_collection)       # 沿用源贴花的集合(实例内可见)
        if cols:
            for c in cols:
                c.objects.link(new)
        else:
            context.collection.objects.link(new)
        self.decal = new
        self.owns_decal = True
        self._restore = None

    def _discard_preview(self, context):
        d = self.decal
        if d is None:
            return
        if self.owns_decal:
            me = d.data
            bpy.data.objects.remove(d, do_unlink=True)
            if me.users == 0:
                bpy.data.meshes.remove(me)
        else:
            # 投放所选物体被取消: 还原变换/父级/集合/贴花目标
            r = self._restore
            safe_hide(d, False)
            for c in list(d.users_collection):
                if c not in r["cols"]:
                    c.objects.unlink(d)
            for c in r["cols"]:
                if c.objects.get(d.name) is None:
                    try:
                        c.objects.link(d)
                    except RuntimeError:
                        pass
            d.parent = r["parent"]
            d.matrix_parent_inverse = r["pinv"]
            d.matrix_world = r["matrix"]
            if r["had_stack"]:
                if r["key"]:
                    old = (context.scene.objects.get(r["key"])
                           or bpy.data.objects.get(r["key"]))
                    if old is not None and old.type == 'MESH':
                        build_stack(d, old, self._stack_params
                                    or context.scene.surfdecal)
            else:
                clear_stack(d)
                if KEY_TARGET in d:
                    del d[KEY_TARGET]
        self.decal = None

    def _finish(self, context):
        context.workspace.status_text_set(None)
        if self.placed == 0:
            return {'CANCELLED'}
        bpy.ops.ed.undo_push(message="投放贴花 ×%d" % self.placed)
        self.report({'INFO'}, "已投放 %d 张贴花" % self.placed)
        return {'FINISHED'}


# ============================================================
#  操作符: 吸附 / 同步 / 固化
# ============================================================

class SURFDECAL_OT_conform(bpy.types.Operator):
    """把所选网格作为贴花吸附到目标表面(曲线/文字自动转为网格, 适合SVG导入的图形)。
默认先把每个贴花对齐到目标最近表面点(位置+法线朝向, 保留自转);
目标取面板指定物体, 未指定则取活动物体"""
    bl_idname = "surfdecal.conform"
    bl_label = "吸附所选到目标"
    bl_options = {'REGISTER', 'UNDO'}

    snap: bpy.props.BoolProperty(
        name="对齐到最近表面", default=True,
        description="吸附前把贴花挪到目标最近表面点并沿法线朝外(保留绕法线的自转); "
                    "关闭则仅添加修改器, 位置不动")

    @classmethod
    def poll(cls, context):
        return context.mode == 'OBJECT'

    def execute(self, context):
        p = context.scene.surfdecal
        target = resolve_target(context)
        inst_empty = None
        if target is None:
            ao = context.active_object
            if (ao is not None and ao.type == 'EMPTY'
                    and ao.instance_collection is not None):
                inst_empty = ao                 # 选中的是组实例
        if target is None and inst_empty is None:
            self.report({'ERROR'},
                        "未指定目标: 请先选中要吸附的网格或组实例(活动物体即目标)")
            return {'CANCELLED'}

        sel = [o for o in context.selected_objects
               if o is not target and o is not inst_empty]
        plain = [o for o in sel if o.type == 'MESH']
        conv = [o for o in sel if o.type in {'CURVE', 'FONT'}]
        converted = []
        if conv:                        # 曲线/文字原位替换为网格(数据API, 无poll问题)
            depsgraph = context.evaluated_depsgraph_get()
            for o in conv:
                new = replace_with_mesh_object(context, o, depsgraph)
                if new is None:
                    self.report({'WARNING'}, "%s: 无可填充几何, 已跳过" % o.name)
                else:
                    converted.append(new)

        decals = plain + converted
        if not decals:
            self.report({'ERROR'}, "所选物体中没有可作为贴花的网格/曲线/文字")
            return {'CANCELLED'}

        skipped = False
        snap_fail = 0
        for o in decals:
            if inst_empty is not None:          # 组实例: 就近烘焙贴合
                ok, skip1 = conform_to_instance_empty(
                    context, o, inst_empty, p, o.matrix_world.translation)
                if not ok:
                    snap_fail += 1
                skipped = skip1 or skipped
            else:
                if self.snap and not snap_object_to_surface(context, o, target):
                    snap_fail += 1
                skipped = conform_object(o, target, p) or skipped

        tname = inst_empty.name if inst_empty is not None else target.name
        msg = "已把 %d 个物体吸附到 %s" % (len(decals), tname)
        if skipped:
            msg += " (目标为平直着色, 已跳过法线融合)"
        if snap_fail:
            msg += " (%d 个未能对齐到表面)" % snap_fail
        self.report({'INFO'}, msg)
        return {'FINISHED'}


class SURFDECAL_OT_refresh(bpy.types.Operator):
    """按当前面板参数重建所选贴花的修改器栈。
移动贴花或调整参数后使用"""
    bl_idname = "surfdecal.refresh"
    bl_label = "同步参数"
    bl_options = {'REGISTER', 'UNDO'}

    @classmethod
    def poll(cls, context):
        return context.mode == 'OBJECT'

    def execute(self, context):
        p = context.scene.surfdecal
        count = 0
        for o in context.selected_objects:
            if o.type != 'MESH':
                continue
            if is_wrapped(o):               # 重建吸附会抹掉包裹形状
                self.report({'WARNING'},
                            "%s: 已包裹, 已跳过(需要改参数请先[还原包裹])"
                            % o.name)
                continue
            target = decal_target_of(context, o)
            if target is None:
                if is_decal(o):
                    self.report({'WARNING'}, "%s: 原目标已丢失, 跳过" % o.name)
                continue
            build_stack(o, target, p)
            count += 1
        if count == 0:
            self.report({'ERROR'}, "所选物体中没有可重建的贴花")
            return {'CANCELLED'}
        self.report({'INFO'}, "已重建 %d 个贴花" % count)
        return {'FINISHED'}


def _decal_scale_update(self, context):
    """物体属性"贴花缩放"回调: 按新旧比值缩放网格本体, 逐张独立记录。
    放大时按累计倍数自动提升细分(以首次记录的级别为基准)。"""
    obj = self
    if not is_decal(obj) or is_wrapped(obj):    # 已包裹: 需先还原再缩放
        return
    prev = obj.get("_sd_scale_applied", 1.0)
    new = obj.surfdecal_scale
    if abs(new - prev) < 1e-6:
        return
    me = obj.data
    if me.users > 1:                            # 盖章副本共享网格: 先独立
        obj.data = me = me.copy()
    r = new / prev
    me.transform(Matrix.Diagonal((r, r, r, 1.0)))
    me.update()
    obj["_sd_scale_applied"] = new
    m = obj.modifiers.get(MOD_SUBSURF)
    if m is not None:
        base = obj.get("_sd_subsurf_base")
        if base is None:
            base = m.levels
            obj["_sd_subsurf_base"] = base
        add = (max(0, int(math.ceil(math.log2(new))))
               if new > 1.0 else 0)
        m.levels = min(6, int(base) + add)
        m.render_levels = m.levels


class SURFDECAL_OT_toggle_wrap(bpy.types.Operator):
    """切换所选贴花的吸附方式: 最近表面点 ⇄ 沿法线投射(Z轴双向)。
最近表面点适合平缓表面且G移动可滑动; 贴花跨越强曲率/拐角出现
破面折叠时, 切到投射通常可修复。按活动贴花的当前方式统一翻转"""
    bl_idname = "surfdecal.toggle_wrap"
    bl_label = "切换吸附方式"
    bl_options = {'REGISTER', 'UNDO'}

    @classmethod
    def poll(cls, context):
        return context.mode == 'OBJECT'

    def execute(self, context):
        p = context.scene.surfdecal
        decals = [o for o in context.selected_objects
                  if o.type == 'MESH'
                  and o.modifiers.get(MOD_SHRINK) is not None]
        if not decals:
            self.report({'ERROR'}, "所选物体中没有带吸附修改器的贴花")
            return {'CANCELLED'}
        ao = context.active_object
        ref = (ao.modifiers.get(MOD_SHRINK)
               if ao is not None and ao.type == 'MESH' else None)
        if ref is None:
            ref = decals[0].modifiers[MOD_SHRINK]
        to_project = ref.wrap_method != 'PROJECT'
        for o in decals:
            m = o.modifiers[MOD_SHRINK]
            if to_project:
                m.wrap_method = 'PROJECT'
                m.use_project_z = True
                m.use_negative_direction = True
                m.use_positive_direction = True
                lim = p.project_limit
                m.project_limit = lim if lim > 0.0 else decal_reach(o)
            else:
                m.wrap_method = 'NEAREST_SURFACEPOINT'
            m.wrap_mode = 'ABOVE_SURFACE'       # 两种方式都保持悬浮
        name = "沿法线投射(Z轴双向)" if to_project else "最近表面点"
        self.report({'INFO'}, "已把 %d 个贴花切换为 %s" % (len(decals), name))
        return {'FINISHED'}


class SURFDECAL_OT_wrap(bpy.types.Operator):
    """硬边包裹贴合: 测地线展开 —— 贴花像贴纸一样折过硬边/包过箱角。
在目标表面上沿直线行走, 跨边时按共享边展开方向, 弧长精确保持;
每个顶点独立计算, 不会塌成一条线。
烘焙操作: 细分先被应用、吸附修改器被移除(网格形状即结果),
法线融合与实体化保留; 备份自动留存, 可[还原包裹]或移动后重新包裹"""
    bl_idname = "surfdecal.wrap_bake"
    bl_label = "硬边包裹贴合"
    bl_options = {'REGISTER', 'UNDO'}

    min_cells: bpy.props.IntProperty(
        name="最小格数(每边)", default=20, min=0, max=64,
        description="包裹前把贴花细分到每边至少这么多格 —— 折缝要落在格子"
                    "内部才能精确切分, 太粗会被吸附到格线上并错位")
    region_mult: bpy.props.FloatProperty(
        name="搜索区域倍数", default=3.0, min=1.5, max=10.0,
        description="参与计算的目标区域 = 贴花半径 × 此倍数; "
                    "贴花要绕很远时加大")
    cut_creases: bpy.props.BoolProperty(
        name="折缝切分", default=True,
        description="在折棱处把跨角的面切开, 新顶点落在棱线上并沿角平分线"
                    "抬升 —— 否则跨凸角的面是一条弦, 会沉入实体(约格子边长"
                    "的1/4), 整排被挡住, 看起来像少了一条边")
    trim_distortion: bpy.props.BoolProperty(
        name="裁掉变形区", default=True,
        description="删除边长拉伸/压缩超出容差的面 —— 三面交汇的角点处"
                    "无法无损铺开(曲率集中), 裁掉相当于真实贴纸的剪口; "
                    "棱边折叠区拉伸≈1, 不受影响")
    trim_tol: bpy.props.FloatProperty(
        name="拉伸容差", default=1.6, min=1.05, max=6.0,
        description="边长被拉伸超过此倍数的面视为变形区")
    sharp_angle: bpy.props.FloatProperty(
        name="硬边角度(度)", default=30.0, min=1.0, max=180.0,
        description="折角超过此度数的边标为硬边。包裹后网格自身有折角, "
                    "全平滑会把折缝法线平均掉, 呈现一条暗带")
    trim_floor: bpy.props.FloatProperty(
        name="压缩下限", default=0.35, min=0.05, max=0.9,
        description="边长压缩到此比例以下才算变形区。跨90°折的格子弦长"
                    "天然是路径长的0.707倍, 属正常折叠, 故下限须放宽")

    @classmethod
    def poll(cls, context):
        return context.mode == 'OBJECT'

    def execute(self, context):
        count = 0
        fails = 0
        for o in context.selected_objects:
            if not is_decal(o):
                continue
            target = decal_target_of(context, o)
            if target is None:
                self.report({'WARNING'}, "%s: 无目标记录, 跳过" % o.name)
                continue
            if o.data.users > 1:
                o.data = o.data.copy()
            if is_wrapped(o):               # 已包裹: 先还原再按新位置重包裹
                restore_rest_state(context, o, rebuild=True)
            store_rest_state(o)             # 备份包裹前状态(可还原)
            ms = o.modifiers.get(MOD_SHRINK)
            offset = ms.offset if ms is not None else 0.002
            msub = o.modifiers.get(MOD_SUBSURF)
            lv = 0
            if msub is not None:                # 先落实顶点密度(bmesh就地)
                lv = int(msub.levels)
                o.modifiers.remove(msub)
                if lv > 0:
                    subdivide_mesh_simple(o.data, lv)
            # 保证最小密度: 折缝需落在格子内部才能被精确切分, 网格太粗时
            # 切点会被吸附到最近格线上, 折线错位并出现暗缝
            if self.min_cells > 0:
                while (len(o.data.polygons) < self.min_cells ** 2
                       and lv < 6):
                    subdivide_mesh_simple(o.data, 1)
                    lv += 1
            if not self._wrap_one(context, o, target, offset):
                restore_rest_state(context, o, rebuild=True)
                clear_rest_state(o)
                fails += 1
                continue
            if ms is not None and MOD_SHRINK in o.modifiers:
                o.modifiers.remove(o.modifiers[MOD_SHRINK])
            ensure_smooth_shading(o)
            ns = mark_fold_sharp(o, self.sharp_angle)   # 折缝打硬边
            if ns:
                self.report({'INFO'},
                            "%s: 已标记 %d 条折缝为硬边" % (o.name, ns))
            count += 1
        if count == 0:
            self.report({'ERROR'},
                        "没有可包裹的贴花(需有目标记录; 失败 %d 个)" % fails)
            return {'CANCELLED'}
        msg = "已包裹 %d 个贴花(可[还原包裹]或移动后重新包裹)" % count
        if fails:
            msg += "; %d 个失败已还原" % fails
        self.report({'INFO'}, msg)
        return {'FINISHED'}

    def _wrap_one(self, context, obj, target, offset):
        """单个贴花的测地线展开 + 折缝切分。成功返回 True。"""
        from mathutils.bvhtree import BVHTree
        me = obj.data
        nv0 = len(me.vertices)
        if nv0 == 0:
            return False
        if nv0 > 20000:
            self.report({'WARNING'},
                        "%s: 顶点过多(%d), 请降低细分级别后再包裹"
                        % (obj.name, nv0))
            return False

        V, T = target_tri_arrays(context, target)
        if V is None:
            self.report({'WARNING'}, "%s: 目标网格不可用" % obj.name)
            return False

        # 贴花局部 → 目标局部
        M = np.array(target.matrix_world.inverted() @ obj.matrix_world,
                     dtype=np.float64)
        R = M[:3, :3]
        anchor = M[:3, 3]                       # 贴花原点(网格中心)
        scale = float(np.mean(np.linalg.norm(R, axis=0)))
        if scale <= 1e-12:
            return False
        co0 = np.empty(nv0 * 3, dtype=np.float64)
        me.vertices.foreach_get("co", co0)
        co0 = co0.reshape(nv0, 3)
        radius2d = float(np.max(np.linalg.norm(co0[:, :2], axis=1))) * scale
        rad = max(radius2d * self.region_mult, radius2d + abs(offset) * 8.0,
                  1e-4)
        V, T = region_triangles(V, T, anchor, rad)
        nbrT, nbrE = build_tri_adjacency(T)
        Vl = V.tolist()
        Tl = T.tolist()
        TC = tri_cache(Vl, Tl)
        nbrTl = nbrT.tolist()
        nbrEl = nbrE.tolist()

        try:
            bvh = BVHTree.FromPolygons(Vl, Tl, all_triangles=True)
        except (RuntimeError, ValueError, TypeError):
            self.report({'WARNING'}, "%s: 目标BVH构建失败" % obj.name)
            return False

        # 锚点: 优先取"贴花正对着的面"(沿自身-Z投射), 而非最近点 ——
        # 骑在棱上时最近点会落在棱线, 取到哪一侧随机, 框架会跟着偏转
        zc = R @ np.array((0.0, 0.0, 1.0))
        zn = float(np.linalg.norm(zc))
        hit = None
        if zn > 1e-12:
            zc = zc / zn
            try:
                rc = bvh.ray_cast(Vector((anchor + zc * (rad * 0.5)).tolist()),
                                  Vector((-zc).tolist()), rad * 2.0)
            except (RuntimeError, ValueError, TypeError):
                rc = None
            if rc is not None and rc[0] is not None:
                hit = rc
        if hit is None:                         # 回落: 最近表面点
            hit = bvh.find_nearest(Vector(anchor.tolist()))
        if hit is None or hit[0] is None:
            self.report({'WARNING'}, "%s: 找不到落点, 请把贴花靠近表面"
                        % obj.name)
            return False
        start_p = (hit[0].x, hit[0].y, hit[0].z)
        start_tri = int(hit[2])

        # 锚点切平面正交框架: 最小旋转把贴花Z转到表面法线, 再取其X/Y
        c0 = TC[start_tri]
        n0 = np.array((c0[13], c0[14], c0[15]), dtype=np.float64)
        ax = []
        for k in range(3):
            v = R @ np.eye(3)[k]
            ln = float(np.linalg.norm(v))
            if ln < 1e-12:
                return False
            ax.append(v / ln)
        zq = Vector((float(ax[2][0]), float(ax[2][1]), float(ax[2][2])))
        nq = Vector((float(n0[0]), float(n0[1]), float(n0[2])))
        if zq.dot(nq) < -0.5:
            self.report({'WARNING'},
                        "%s: 贴花正面朝向表面内侧, 结果可能翻转" % obj.name)
        q = zq.rotation_difference(nq)
        e1v = q @ Vector((float(ax[0][0]), float(ax[0][1]), float(ax[0][2])))
        e2v = q @ Vector((float(ax[1][0]), float(ax[1][1]), float(ax[1][2])))
        e1 = np.array((e1v.x, e1v.y, e1v.z), dtype=np.float64)
        e2 = np.array((e2v.x, e2v.y, e2v.z), dtype=np.float64)
        start_np = np.array(start_p, dtype=np.float64)

        def trace_xy(x, y):
            """平面坐标 → (展开点, 落点面法线)。"""
            r = math.sqrt(x * x + y * y) * scale
            if r <= 1e-9:
                return start_np, n0
            d = e1 * x + e2 * y
            dn = float(np.linalg.norm(d))
            if dn <= 1e-12:
                return start_np, n0
            d = d / dn
            p, tri = trace_geodesic(
                start_tri, start_p, (float(d[0]), float(d[1]), float(d[2])),
                r, Vl, Tl, nbrTl, nbrEl, TC)
            c = TC[tri]
            return (np.array(p, dtype=np.float64),
                    np.array((c[13], c[14], c[15]), dtype=np.float64))

        bm = bmesh.new()
        bm.from_mesh(me)                        # 此时 bm 里是平面静止坐标
        bm.verts.ensure_lookup_table()
        vnorm = {}
        for v in bm.verts:
            vnorm[v] = trace_xy(v.co.x, v.co.y)[1]

        # 折缝切分: 二分定位棱线在平面参数上的位置, 切开并抬到等距壳上;
        # 切点距端点很近(折缝压在网格线上)时改为吸附既有顶点, 不切分
        crease = set()
        cuts = 0
        snaps = 0
        if self.cut_creases:
            thr = math.cos(math.radians(self.sharp_angle))
            eps = 0.06                          # 距端点6%以内: 吸附
            plan = []
            for e in list(bm.edges):
                v0, v1 = e.verts
                na, nb = vnorm.get(v0), vnorm.get(v1)
                if na is None or nb is None:
                    continue
                if float(np.dot(na, nb)) >= thr:    # 同一平面, 无需切
                    continue
                a = np.array((v0.co.x, v0.co.y), dtype=np.float64)
                b = np.array((v1.co.x, v1.co.y), dtype=np.float64)
                lo, hi = 0.0, 1.0
                for _ in range(12):                 # 二分到 ~0.02% 精度
                    mid = (lo + hi) * 0.5
                    p2 = a + (b - a) * mid
                    nm = trace_xy(float(p2[0]), float(p2[1]))[1]
                    if float(np.dot(nm, na)) >= thr:
                        lo = mid
                    else:
                        hi = mid
                t = (lo + hi) * 0.5
                s = na + nb                         # 角平分线
                ls = float(np.linalg.norm(s))
                if ls <= 1e-9:
                    continue
                bvec = s / ls
                chalf = max(0.2, float(np.dot(bvec, na)))   # cos(半折角)
                neff = bvec / chalf             # 抬到与两面等距的悬浮壳
                if t < eps:                     # 折缝穿过既有顶点: 吸附
                    vnorm[v0] = neff
                    crease.add(v0)
                    snaps += 1
                elif t > 1.0 - eps:
                    vnorm[v1] = neff
                    crease.add(v1)
                    snaps += 1
                else:
                    plan.append((e, v0, t, neff))
            for e, v0, t, neff in plan:
                if not e.is_valid:
                    continue
                ea, eb = e.verts
                if ea in crease and eb in crease:
                    continue                    # 边本身沿折缝: 不切
                try:
                    _ne, nvert = bmesh.utils.edge_split(e, v0, t)
                except (ValueError, RuntimeError, TypeError):
                    continue
                vnorm[nvert] = neff
                crease.add(nvert)
                cuts += 1
        if crease:
            try:                                # 缝点连成真实边环(分面)
                bmesh.ops.connect_verts(bm, verts=list(crease))
            except (RuntimeError, ValueError, TypeError):
                pass

        # 统一写回(先算全部, 再赋值 —— v.co 在算完前仍是平面坐标)
        flat = []
        outs = []
        for v in bm.verts:
            x, y, z = v.co.x, v.co.y, v.co.z
            p, nn = trace_xy(x, y)
            n = vnorm[v] if v in crease else nn
            flat.append((x, y, z))
            outs.append(p + n * (offset + z * scale))
        Mi = np.array(obj.matrix_world.inverted() @ target.matrix_world,
                      dtype=np.float64)
        Ri, Ti = Mi[:3, :3], Mi[:3, 3]
        for v, o3 in zip(bm.verts, outs):
            loc = Ri @ o3 + Ti
            v.co = Vector((float(loc[0]), float(loc[1]), float(loc[2])))
        bm.to_mesh(me)
        bm.free()
        me.update()
        if cuts or snaps:
            self.report({'INFO'}, "%s: 折缝切分 %d 处, 顶点吸附 %d 处"
                        % (obj.name, cuts, snaps))

        # 变形诊断 / 裁剪(索引与 bm 顶点顺序一致)
        faces = [tuple(pf.vertices) for pf in me.polygons]
        bad, worst, tight = distorted_faces(
            faces, flat, outs, scale,
            self.trim_tol if self.trim_distortion else 1e9,
            self.trim_floor if self.trim_distortion else 0.0)
        self.report({'INFO'},
                    "%s: 最大拉伸 %.2f× / 最小压缩 %.2f× / 超差面 %d"
                    % (obj.name, worst, tight, len(bad)))
        if self.trim_distortion and bad and len(bad) < len(faces):
            bm2 = bmesh.new()
            bm2.from_mesh(me)
            bm2.faces.ensure_lookup_table()
            doomed = [bm2.faces[i] for i in bad if i < len(bm2.faces)]
            bmesh.ops.delete(bm2, geom=doomed, context='FACES')
            bm2.to_mesh(me)
            bm2.free()
            me.update()
            self.report({'INFO'},
                        "%s: 已裁掉 %d 个变形面" % (obj.name, len(bad)))
        elif self.trim_distortion and bad and worst > self.trim_tol:
            self.report({'WARNING'},
                        "%s: 整体拉伸 %.2f× 偏大, 未裁剪(会删空); "
                        "试试缩小贴花或把中心移离角点" % (obj.name, worst))
        return True


class SURFDECAL_OT_unmanage(bpy.types.Operator):
    """转为普通网格: 彻底解除 SurfDecal 管理 —— 删除贴花身份、目标关联与
所有管理数据, 此后不再被本插件的任何功能识别。
这是唯一允许清理管理数据的操作; 材质与网格本身保持不变"""
    bl_idname = "surfdecal.unmanage"
    bl_label = "转为普通网格"
    bl_options = {'REGISTER', 'UNDO'}

    keep_nodes: bpy.props.BoolProperty(
        name="保留材质节点", default=True,
        description="保留 Bridge/磨损/边缘/法线节点(外观不变); "
                    "取消则一并清除, 材质回到纯图案")

    @classmethod
    def poll(cls, context):
        return context.mode == 'OBJECT'

    def execute(self, context):
        targets = [o for o in context.selected_objects if is_decal(o)]
        if not targets:
            self.report({'ERROR'}, "请选中贴花")
            return {'CANCELLED'}
        n = 0
        for o in targets:
            for name in [m.name for m in o.modifiers
                         if m.name.startswith((MOD_PREFIX, MOD_TARGET_UV))]:
                o.modifiers.remove(o.modifiers[name])
            clear_rest_state(o)
            for k in (KEY_TARGET, KEY_TARGET_ID, KEY_DECAL_ID, KEY_STATE,
                      KEY_AUTOSUB, "_sd_scale_applied", "_sd_subsurf_base"):
                if k in o:
                    del o[k]
            lay = o.data.uv_layers.get(UV_XFER)   # 传入UV层已无来源
            if lay is not None:
                o.data.uv_layers.remove(lay)
            if not self.keep_nodes:
                for slot in o.material_slots:
                    m = slot.material
                    if m is None:
                        continue
                    clear_slot(m, SLOT_WEAR)
                    clear_slot(m, SLOT_EDGE)
                    remove_relief(m)
                    clear_match(m)
                    remove_bridge(m)
            n += 1
        self.report({'INFO'},
                    "已转为普通网格 %d 个 — 不再被 SurfDecal 管理" % n)
        return {'FINISHED'}


class SURFDECAL_OT_rebind_target(bpy.types.Operator):
    """重新指定目标: 把所选贴花绑定到活动物体(§2.2 目标丢失时的入口)"""
    bl_idname = "surfdecal.rebind_target"
    bl_label = "重新指定目标"
    bl_options = {'REGISTER', 'UNDO'}

    @classmethod
    def poll(cls, context):
        o = context.active_object
        return (context.mode == 'OBJECT' and o is not None
                and o.type == 'MESH' and not is_decal(o))

    def execute(self, context):
        tgt = context.active_object
        decals = [o for o in context.selected_objects
                  if is_decal(o) and o is not tgt]
        if not decals:
            self.report({'ERROR'},
                        "请同时选中贴花, 并把新目标设为活动物体")
            return {'CANCELLED'}
        for d in decals:
            bind_decal_target(d, tgt)
            auto_name_decal(d, tgt)
        self.report({'INFO'}, "已把 %d 张贴花重新绑定到 %s"
                    % (len(decals), tgt.name))
        return {'FINISHED'}


class SURFDECAL_OT_tidy_nodes(bpy.types.Operator):
    """整理节点: 把本插件生成的节点按功能分行、按信号流分列重新摆放。
不改任何连接与参数, 只调整位置; 存量文件也能一键归位"""
    bl_idname = "surfdecal.tidy_nodes"
    bl_label = "整理节点"
    bl_options = {'REGISTER', 'UNDO'}

    @classmethod
    def poll(cls, context):
        return context.mode == 'OBJECT'

    def execute(self, context):
        decals = [o for o in context.selected_objects if is_decal(o)]
        if not decals:
            self.report({'ERROR'}, "请选中贴花")
            return {'CANCELLED'}
        total = 0
        mats = 0
        seen = set()
        for d in decals:
            for slot in d.material_slots:
                m = slot.material
                if m is None or not m.use_nodes or m.as_pointer() in seen:
                    continue
                seen.add(m.as_pointer())
                bridge = get_bridge(m)
                if bridge is None:
                    continue
                moved = layout_managed_graph(m.node_tree, bridge)
                if moved:
                    total += moved
                    mats += 1
        if total == 0:
            self.report({'INFO'}, "没有可整理的节点")
            return {'FINISHED'}
        self.report({'INFO'}, "已整理 %d 个材质的 %d 个节点" % (mats, total))
        return {'FINISHED'}


class SURFDECAL_OT_diagnose(bpy.types.Operator):
    """收集所选贴花与目标的诊断信息并复制到剪贴板(同时打印到控制台)。
包裹结果不对时用它把数据发给作者, 比截图能定位得准"""
    bl_idname = "surfdecal.diagnose"
    bl_label = "输出诊断信息"
    bl_options = {'REGISTER'}

    @classmethod
    def poll(cls, context):
        return context.mode == 'OBJECT'

    def execute(self, context):
        L = []
        L.append("SurfDecal 诊断 v%s / Blender %s"
                 % (".".join(str(x) for x in SD_VERSION),
                    bpy.app.version_string))
        for o in context.selected_objects:
            if not is_decal(o):
                continue
            me = o.data
            L.append("")
            L.append("[贴花] %s" % o.name)
            L.append("  物体缩放 %.4f, %.4f, %.4f  旋转模式 %s"
                     % (o.scale.x, o.scale.y, o.scale.z, o.rotation_mode))
            L.append("  网格 顶点%d 面%d  贴花缩放属性 %.4f"
                     % (len(me.vertices), len(me.polygons),
                        getattr(o, "surfdecal_scale", -1.0)))
            if me.vertices:
                bb = [v.co for v in me.vertices]
                xs = [c.x for c in bb]
                ys = [c.y for c in bb]
                zs = [c.z for c in bb]
                L.append("  局部尺寸 %.4f × %.4f × %.4f"
                         % (max(xs) - min(xs), max(ys) - min(ys),
                            max(zs) - min(zs)))
                L.append("  世界尺寸 %.4f × %.4f × %.4f"
                         % tuple(o.dimensions))
            L.append("  已包裹=%s  备份=%s  父级=%s"
                     % (is_wrapped(o), o.get(KEY_REST, "无"),
                        o.parent.name if o.parent else "无"))
            mods = list(o.modifiers)
            L.append("  修改器: %s"
                     % (", ".join("%s(%s)" % (m.name, m.type)
                                  for m in mods) or "无"))
            extra = [m.name for m in mods
                     if not m.name.startswith(MOD_PREFIX)]
            if extra:
                L.append("  非本插件修改器: %s (阵列/镜像的副本不会各自贴合)"
                         % ", ".join(extra))
            mu = o.modifiers.get(MOD_TARGET_UV)
            if mu is not None:
                dt = sorted(mu.data_types_loops)
                L.append("  UV传递: 源=%s loop=%s 类型=%s 映射=%s%s"
                         % (mu.object.name if mu.object else "无",
                            mu.use_loop_data, dt or "空",
                            mu.loop_mapping,
                            "" if dt == ['UV'] and mu.use_loop_data
                            else "  ← 配置无效, UV不会动态更新!"))
            if KEY_AUTOSUB in o:
                L.append("  自适应细分: %d 级" % int(o[KEY_AUTOSUB]))
            uvs = [lay.name for lay in me.uv_layers]
            L.append("  UV层: %s" % (", ".join(uvs) or "无 ← 贴图无法正确采样!"))
            if uvs:
                uv = me.uv_layers[0].data
                n_uv = len(uv)
                if n_uv:
                    zeros = sum(1 for i in range(n_uv)
                                if abs(uv[i].uv[0]) < 1e-9
                                and abs(uv[i].uv[1]) < 1e-9)
                    us = [uv[i].uv[0] for i in range(n_uv)]
                    vs = [uv[i].uv[1] for i in range(n_uv)]
                    L.append("  UV范围 U[%.3f,%.3f] V[%.3f,%.3f]  "
                             "归零loop %d/%d%s"
                             % (min(us), max(us), min(vs), max(vs),
                                zeros, n_uv,
                                " ← UV被破坏!" if zeros > n_uv * 0.02 else ""))
            _tgt = decal_target_of(context, o) or o.parent
            if _tgt is not None and _tgt.type != 'MESH':
                _tgt = None
            if not o.material_slots:
                L.append("  材质: 无材质槽")
            for si, slot in enumerate(o.material_slots):
                m = slot.material
                if m is None:
                    L.append("  材质槽%d: 空" % si)
                    continue
                L.append("  材质槽%d: %s (节点=%s)"
                         % (si, m.name, m.use_nodes))
                if not m.use_nodes:
                    continue
                imgs = [(nd.name, nd.image.name if nd.image else "无图像!")
                        for nd in m.node_tree.nodes
                        if nd.bl_idname == 'ShaderNodeTexImage']
                L.append("    图像纹理: %s"
                         % ("; ".join("%s→%s" % t for t in imgs) or "无"))
                bs = _find_node(m.node_tree, 'ShaderNodeBsdfPrincipled')
                if bs is not None:
                    for sn in ("Base Color", "Alpha", "Roughness"):
                        sk = bs.inputs.get(sn)
                        if sk is None:
                            continue
                        srcn = (sk.links[0].from_node.name
                                if sk.links else "(未连接)")
                        L.append("    %s ← %s" % (sn, srcn))
                has_wear = (bool(slot_nodes(m, SLOT_WEAR))
                            or any(nd.name.startswith(LEGACY_WEAR_TAG)
                                   for nd in m.node_tree.nodes))
                _mtag = [nd for nd in m.node_tree.nodes
                         if nd.name.startswith(MATCH_TAG)]
                if _mtag:
                    L.append("    匹配链 %d 节点:" % len(_mtag))
                    for nd in _mtag:
                        _d = "      · %s [%s]" % (nd.name, nd.bl_idname)
                        if nd.bl_idname == 'ShaderNodeTexImage':
                            _d += " proj=%s img=%s" % (
                                getattr(nd, "projection", "?"),
                                nd.image.name if nd.image else "无")
                            _vs = nd.inputs.get("Vector")
                            _d += " vec←%s" % (
                                _vs.links[0].from_node.bl_idname
                                if _vs is not None and _vs.links else "隐式活动UV!")
                        elif nd.bl_idname == 'ShaderNodeTexCoord':
                            _d += " object=%s" % (nd.object.name
                                                  if nd.object else "无(=贴花自身!)")
                        elif nd.bl_idname == 'ShaderNodeUVMap':
                            _d += " uv=%s" % nd.uv_map
                        elif nd.bl_idname == 'ShaderNodeMapping':
                            _d += " scale=%s" % (
                                tuple(round(v, 4) for v in
                                      nd.inputs["Scale"].default_value),)
                        elif nd.bl_idname == 'ShaderNodeGroup':
                            _d += " group=%s" % (nd.node_tree.name
                                                 if nd.node_tree else "无")
                            for _s in nd.inputs:
                                if _s.type != 'VALUE' or _s.links:
                                    continue
                                _d += "\n          %s=%.3f" % (
                                    _s.name, _s.default_value)
                        L.append(_d)
                    _bf = (_planar_target_box_face(o, _tgt)
                           if _tgt is not None else None)
                    L.append("    BOX展平面轴: %s%s"
                             % (_bf, "" if _bf else
                                "  ← None: BOX保护未生效, 会按贴花基拉伸!"))
                    _fl = (sample_target_flatness(o, _tgt)
                           if _tgt is not None else None)
                    L.append("    平坦度: %s (>0.5° 就会跳过BOX展平)"
                             % ("%.2f°" % _fl if _fl is not None else "取不到"))
                L.append("    磨损链: %s | 匹配: %s"
                         % ("有" if has_wear else "无",
                            "有" if any(nd.name.startswith(MATCH_TAG)
                                        for nd in m.node_tree.nodes)
                            else "无"))
            L.append("  所在集合: %s"
                     % ", ".join(c.name for c in o.users_collection))
            insts = [e.name for e in context.scene.objects
                     if e.type == 'EMPTY' and e.instance_collection is not None
                     and e.instance_collection.all_objects.get(o.name)]
            L.append("  被集合实例引用: %s" % (", ".join(insts) or "否"))

            t = decal_target_of(context, o)
            if t is None:
                L.append("  [目标] 记录=%s → 未找到"
                         % o.get(KEY_TARGET, "无"))
                continue
            L.append("  [目标] %s  缩放 %.4f, %.4f, %.4f%s"
                     % (t.name, t.scale.x, t.scale.y, t.scale.z,
                        "  ← 非均匀!" if max(abs(t.scale.x - t.scale.y),
                                            abs(t.scale.x - t.scale.z))
                        > 1e-4 else ""))
            L.append("    修改器: %s"
                     % (", ".join("%s(%s)" % (m.name, m.type)
                                  for m in t.modifiers) or "无"))
            good, _r, why = uv_health(t)
            L.append("    UV体检: %s (%s)"
                     % ("可用" if good else "不可用 ← UV模式会出竖条纹", why))
            V, T = target_tri_arrays(context, t)
            _bb = [Vector(c) for c in t.bound_box]
            _sz = (max(v.x for v in _bb) - min(v.x for v in _bb),
                   max(v.y for v in _bb) - min(v.y for v in _bb),
                   max(v.z for v in _bb) - min(v.z for v in _bb))
            L.append("    目标局部包围盒: %.3f × %.3f × %.3f%s"
                     % (_sz[0], _sz[1], _sz[2],
                        "" if max(_sz) / max(1e-9, min(_sz)) < 1.2
                        else "  ← 非立方, 逐轴归一化会让各面比例不同"))
            L.append("    求值三角面: %s"
                     % (len(T) if T is not None else "取不到"))
            M = np.array(t.matrix_world.inverted() @ o.matrix_world,
                         dtype=np.float64)
            R = M[:3, :3]
            cols = np.linalg.norm(R, axis=0)
            L.append("    贴花→目标 尺度 %.5f (列范数 %.4f/%.4f/%.4f)"
                     % (float(np.mean(cols)), cols[0], cols[1], cols[2]))
            if V is not None and T is not None:
                try:
                    from mathutils.bvhtree import BVHTree
                    anchor = M[:3, 3]
                    zc = R @ np.array((0.0, 0.0, 1.0))
                    zc = zc / max(1e-12, float(np.linalg.norm(zc)))
                    bvh = BVHTree.FromPolygons(V.tolist(), T.tolist(),
                                               all_triangles=True)
                    rc = bvh.ray_cast(Vector((anchor + zc * 1.0).tolist()),
                                      Vector((-zc).tolist()), 4.0)
                    nn = bvh.find_nearest(Vector(anchor.tolist()))
                    for tag, h in (("射线锚点", rc), ("最近点锚点", nn)):
                        if h is None or h[0] is None:
                            L.append("    %s: 未命中" % tag)
                            continue
                        nv = np.array((h[1].x, h[1].y, h[1].z))
                        ang = math.degrees(math.acos(
                            max(-1.0, min(1.0, float(np.dot(nv, zc))))))
                        L.append("    %s: 三角%d 距离%.4f 法线与贴花Z夹角%.1f°"
                                 % (tag, int(h[2]), float(h[3]), ang))
                except Exception as e:  # 诊断路径: 任何异常都要如实报出
                    L.append("    锚点探测失败: %s" % e)
        if len(L) == 1:
            self.report({'ERROR'}, "请先选中贴花")
            return {'CANCELLED'}
        text = "\n".join(L)
        print(text)
        context.window_manager.clipboard = text
        self.report({'INFO'}, "诊断信息已复制到剪贴板(控制台也有)")
        return {'FINISHED'}


class SURFDECAL_OT_unwrap(bpy.types.Operator):
    """还原包裹: 换回包裹前的网格并重建吸附修改器。
备份保留, 可反复包裹/还原; 移动贴花后直接再点[硬边包裹贴合]即可"""
    bl_idname = "surfdecal.unwrap"
    bl_label = "还原包裹"
    bl_options = {'REGISTER', 'UNDO'}

    @classmethod
    def poll(cls, context):
        return context.mode == 'OBJECT'

    def execute(self, context):
        count = 0
        for o in context.selected_objects:
            if not is_wrapped(o):
                continue
            if o.data.users > 1:
                o.data = o.data.copy()
            if restore_rest_state(context, o, rebuild=True):
                count += 1
        if count == 0:
            self.report({'ERROR'}, "所选物体中没有已包裹的贴花")
            return {'CANCELLED'}
        self.report({'INFO'}, "已还原 %d 个贴花" % count)
        return {'FINISHED'}


class SURFDECAL_OT_decimate(bpy.types.Operator):
    """减面: 把共面区域融并掉。平面贴花能降到最少面数; 已包裹的贴花保留
折缝(折线已标为硬边), 只合并两侧的平坦区。UV在平面区域为仿射, 融并无损"""
    bl_idname = "surfdecal.decimate"
    bl_label = "减面"
    bl_options = {'REGISTER', 'UNDO'}

    angle: bpy.props.FloatProperty(
        name="共面容差(度)", default=1.0, min=0.05, max=30.0,
        description="面法线夹角小于此值即视为共面并融并; 曲面贴花可放宽到3~8")

    @classmethod
    def poll(cls, context):
        return context.mode == 'OBJECT'

    def execute(self, context):
        decals = [o for o in context.selected_objects if is_decal(o)]
        if not decals:
            self.report({'ERROR'}, "请选中贴花")
            return {'CANCELLED'}
        tot_b = tot_a = 0
        done = 0
        protected_count = 0
        skipped_count = 0
        for d in decals:
            if d.data.users > 1:                # 共享网格: 先独立化
                d.data = d.data.copy()
            protection = edge_decimate_protection(d)
            if protection is None:
                count = len(d.data.polygons)
                tot_b += count
                tot_a += count
                skipped_count += 1
                continue
            if protection:
                protected_count += 1
            nb, na = dissolve_decal(d, self.angle, protection)
            tot_b += nb
            tot_a += na
            if na < nb:
                done += 1
        if done == 0:
            if skipped_count:
                self.report({'WARNING'},
                            "已跳过 %d 个贴花：无法可靠保护边缘磨损拓扑"
                            % skipped_count)
                return {'FINISHED'}
            self.report({'INFO'},
                        "没有可融并的面(%d 面; 曲面贴花请放宽容差)" % tot_b)
            return {'FINISHED'}
        message = "已减面: %d 个贴花 %d → %d 面 (省 %.0f%%)" % (
            done, tot_b, tot_a, (1.0 - tot_a / max(1, tot_b)) * 100.0)
        if protected_count:
            message += "；%d 个已保护边缘磨损区" % protected_count
        if skipped_count:
            message += "；%d 个因无法可靠保护而跳过" % skipped_count
        self.report({'INFO'}, message)
        return {'FINISHED'}


class SURFDECAL_OT_scale(bpy.types.Operator):
    """缩放所选贴花: 作用于底面网格本体, 物体缩放保持1, 曲面贴合自动重算。
会先吸收物体上已有的S缩放; 放大时自动提升细分级别保证贴合质量。
已固化的贴花几何已定型, 直接用S即可"""
    bl_idname = "surfdecal.scale_decal"
    bl_label = "缩放贴花"
    bl_options = {'REGISTER', 'UNDO'}

    factor: bpy.props.FloatProperty(
        name="缩放系数", default=1.0, min=0.01,
        soft_min=0.25, soft_max=4.0,
        options={'SKIP_SAVE'})                  # 不继承上次调用的系数

    @classmethod
    def poll(cls, context):
        return context.mode == 'OBJECT'

    def execute(self, context):
        count = 0
        for o in context.selected_objects:
            if not is_decal(o):
                continue
            me = o.data
            if me.users > 1:                    # 盖章副本共享网格: 先独立
                o.data = me = me.copy()
            s = o.scale                         # 吸收已有的S缩放
            if (abs(s.x - 1.0) > 1e-6 or abs(s.y - 1.0) > 1e-6
                    or abs(s.z - 1.0) > 1e-6):
                me.transform(Matrix.Diagonal((s.x, s.y, s.z, 1.0)))
                if s.x * s.y * s.z < 0.0:       # 负缩放翻面
                    me.flip_normals()
                o.scale = (1.0, 1.0, 1.0)
                me.update()
            if abs(self.factor - 1.0) > 1e-6:   # 委托给逐张记录属性
                o.surfdecal_scale = o.surfdecal_scale * self.factor
            count += 1
        if count == 0:
            self.report({'ERROR'},
                        "所选物体中没有贴花(已固化的直接用S缩放即可)")
            return {'CANCELLED'}
        self.report({'INFO'}, "已缩放 %d 个贴花 ×%.2f" % (count, self.factor))
        return {'FINISHED'}


class SURFDECAL_OT_apply(bpy.types.Operator):
    """固化几何: 应用贴花修改器把形状烘进网格(自定义法线保留)。
贴花身份、目标关联、材质与表面桥接全部保留 —— 之后表面匹配、
磨损、边缘、法线仍可继续编辑(§2.2)。
要彻底脱离本插件管理, 用[转为普通网格]"""
    bl_idname = "surfdecal.apply"
    bl_label = "固化几何"
    bl_options = {'REGISTER', 'UNDO'}

    apply_transform: bpy.props.BoolProperty(
        name="旋转缩放归零", default=True,
        description="把旋转与缩放烘入网格数据(外观与物体原点不变), "
                    "物体变换归为旋转0/缩放1; 仍有父级时跳过")
    dissolve_angle: bpy.props.FloatProperty(
        name="共面容差(度)", default=1.0, min=0.05, max=15.0,
        description="面法线夹角小于此值即视为共面并融并")
    dissolve_flat: bpy.props.BoolProperty(
        name="固化后安全融并", default=True,
        description="固化后用有限融并清理共面区域；硬折线由硬边标记保护，"
                    "只合并折线两侧的平坦区域")
    trim_unfit: bpy.props.BoolProperty(
        name="裁掉未贴合面", default=False,
        description="删除中心点距目标表面过远的面 —— 投射限深下未命中"
                    "而悬空的溢出部分, 硬边旁的贴花固化后更干净")

    @classmethod
    def poll(cls, context):
        return context.mode == 'OBJECT'

    def execute(self, context):
        applied = 0
        flat_optimized = 0
        parents_cleared = 0
        failed = 0
        p = context.scene.surfdecal
        for o in [x for x in context.selected_objects if is_decal(x)]:
            if o.data.users > 1:                # 多用户数据先独立化(盖章副本共享网格)
                o.data = o.data.copy()
            ms = o.modifiers.get(MOD_SHRINK)    # 裁剪阈值所需信息先取好
            off = ms.offset if ms is not None else 0.002
            msol = o.modifiers.get(MOD_SOLID)
            thick = msol.thickness if msol is not None else 0.0
            target = decal_target_of(context, o)
            # 只在最终固化这一刻判定表面。平面不必先把 Simple Subdivision
            # 烘成大量共面网格；曲面、硬折面或采样失败则保守地保留细分。
            optimize_flat_on_finalize = getattr(p, "auto_subdiv", True)
            if optimize_flat_on_finalize:
                angle = (sample_target_flatness(o, target)
                         if target is not None and target.type == 'MESH'
                         else None)
                if angle is not None and angle < FINALIZE_FLAT_ANGLE:
                    subdiv = o.modifiers.get(MOD_SUBSURF)
                    if subdiv is not None:
                        o.modifiers.remove(subdiv)
                        flat_optimized += 1
            names = [m.name for m in o.modifiers
                     if (m.name.startswith(MOD_PREFIX)
                         or m.name == MOD_TARGET_UV)]
            modifier_failed = False
            with context.temp_override(object=o, active_object=o,
                                       selected_objects=[o]):
                for name in names:
                    try:
                        result = bpy.ops.object.modifier_apply(modifier=name)
                        if result != {'FINISHED'}:
                            raise RuntimeError("修改器未成功应用")
                    except RuntimeError as e:
                        modifier_failed = True
                        self.report({'ERROR'},
                                    "%s: 应用 %s 失败 - %s" % (o.name, name, e))
                        break
            if modifier_failed:
                failed += 1
                continue
            if (self.trim_unfit and target is not None
                    and target.type == 'MESH'):
                self._trim_unfit(context, o, target, off, thick)
            # §2.2: 保留贴花身份与目标关联 —— 只冻结几何, 不清管理数据
            bind_decal_target(o, target)
            o[KEY_STATE] = "GEOMETRY_FROZEN"
            clear_rest_state(o)                 # 包裹备份对已冻结几何无意义
            for k in ("_sd_scale_applied", "_sd_subsurf_base"):
                if k in o:                      # 清理逐张缩放记录
                    del o[k]
            o.surfdecal_scale = 1.0             # 栈已应用, 回调会自动跳过
            if clear_parent_keep_transform(o):
                parents_cleared += 1
            if self.apply_transform and o.parent is None:
                mw = o.matrix_world.copy()      # 旋转/缩放(线性部分)烘入网格
                o.data.transform(mw.to_3x3().to_4x4())
                o.data.update()
                o.matrix_world = Matrix.Translation(mw.to_translation())
            ensure_smooth_shading(o)            # 4.0.x 保持自动平滑以保住自定义法线
            if self.dissolve_flat:
                protection = edge_decimate_protection(o)
                if protection is None:
                    self.report({'WARNING'},
                                "%s: 为保护边缘磨损，已跳过平面精简" % o.name)
                else:
                    nb, na = dissolve_decal(
                        o, self.dissolve_angle, protection)
                    if nb != na:
                        self.report({'INFO'}, "%s: 平面精简 %d → %d 面"
                                    % (o.name, nb, na))
            applied += 1
        if applied == 0:
            if failed:
                self.report({'ERROR'}, "固化失败 %d 个贴花；对象仍保持可编辑状态"
                            % failed)
            else:
                self.report({'ERROR'}, "所选物体中没有贴花")
            return {'CANCELLED'}
        details = []
        if flat_optimized:
            details.append("平面跳过细分 %d 个" % flat_optimized)
        if parents_cleared:
            details.append("解除父级 %d 个" % parents_cleared)
        if failed:
            details.append("失败 %d 个" % failed)
        suffix = ("，其中" + "，".join(details)) if details else ""
        self.report({'INFO'},
                    "已固化几何 %d 个%s — 贴花身份与材质保留, 仍可编辑表面"
                    % (applied, suffix))
        return {'FINISHED'}

    def _trim_unfit(self, context, obj, target, offset, thickness):
        """删除中心点离目标表面过远的面(投射限深下未命中的悬空溢出)。"""
        from mathutils.bvhtree import BVHTree   # 惰性导入
        depsgraph = context.evaluated_depsgraph_get()
        try:
            bvh = BVHTree.FromObject(target, depsgraph)
        except (RuntimeError, ValueError, TypeError):
            return
        inv_t = target.matrix_world.inverted()
        sc = target.matrix_world.to_scale()
        s_avg = max(1e-9, (abs(sc.x) + abs(sc.y) + abs(sc.z)) / 3.0)
        thresh = (max(offset * 6.0, 0.002) + thickness) / s_avg
        mw = obj.matrix_world
        bm = bmesh.new()
        bm.from_mesh(obj.data)
        doomed = []
        for f in bm.faces:
            c_local = inv_t @ (mw @ f.calc_center_median())
            hit = bvh.find_nearest(c_local)
            if hit[0] is None or hit[3] > thresh:
                doomed.append(f)
        n = len(doomed)
        if doomed and n < len(bm.faces):        # 全部超阈说明阈值失真, 放弃
            bmesh.ops.delete(bm, geom=doomed, context='FACES')
            bm.to_mesh(obj.data)
            obj.data.update()
            self.report({'INFO'}, "%s: 已裁掉 %d 个悬空面" % (obj.name, n))
        bm.free()


# ============================================================
#  操作符: 导入 SVG / 位图
# ============================================================

class SURFDECAL_OT_import_svg(bpy.types.Operator, ImportHelper):
    """导入 SVG 为实体贴花网格:
调用 Blender 自带 SVG 导入器(未启用时自动启用),
转网格、合并、按宽度归一化, 可自动吸附到目标"""
    bl_idname = "surfdecal.import_svg"
    bl_label = "导入SVG为贴花"
    bl_options = {'REGISTER', 'UNDO'}

    filename_ext = ".svg"
    filter_glob: bpy.props.StringProperty(default="*.svg", options={'HIDDEN'})

    width: bpy.props.FloatProperty(
        name="目标宽度", default=0.5, min=0.001, subtype='DISTANCE',
        description="导入后图形的物理宽度(高度按比例)")
    after: bpy.props.EnumProperty(
        name="导入后",
        items=[
            ('CONFORM', "吸附到选中物体", "吸附到导入前选中的网格或组实例(默认)"),
            ('PLACE', "进入交互投放", "导入完成直接进入投放模式, 在表面滑动摆放"),
            ('NONE', "仅导入到游标", "只创建物体, 之后手动处理"),
        ],
        default='CONFORM')

    @classmethod
    def poll(cls, context):
        return context.mode == 'OBJECT'

    def _svg_import(self, filepath):
        try:
            return bpy.ops.import_curve.svg(filepath=filepath)
        except AttributeError:
            pass
        import addon_utils                      # 导入器未启用: 依次尝试
        for mod in ("io_curve_svg",             # 4.x legacy 模块名
                    "bl_ext.blender_org.io_curve_svg"):  # 扩展命名空间
            try:
                addon_utils.enable(mod, default_set=True)
            except Exception:          # 边界: 第三方插件启用可能抛任意异常
                continue
            try:
                return bpy.ops.import_curve.svg(filepath=filepath)
            except AttributeError:
                continue
        raise RuntimeError(
            "SVG导入器不可用: 请在 偏好设置→获取扩展 安装 'Import Curves SVG'")

    def execute(self, context):
        p = context.scene.surfdecal
        target = resolve_import_target(context)     # 导入前选中的物体即目标

        before_objs = set(bpy.data.objects)
        before_cols = set(bpy.data.collections)
        try:
            self._svg_import(self.filepath)
        except Exception as e:         # 边界IO: 交由自带SVG导入器, 异常不可穷举
            self.report({'ERROR'},
                        "SVG导入失败(需要自带的 Scalable Vector Graphics 导入插件): %s" % e)
            return {'CANCELLED'}

        new_objs = [o for o in bpy.data.objects if o not in before_objs]
        new_cols = [c for c in bpy.data.collections if c not in before_cols]

        # 转网格+合并全走数据API(new_from_object/bmesh), 文件浏览器上下文也安全
        depsgraph = context.evaluated_depsgraph_get()
        mesh_datas = []
        for o in new_objs:
            if o.type in {'CURVE', 'MESH'}:
                me = new_mesh_from_object(o, depsgraph)
                if me is not None:
                    me.transform(o.matrix_world)    # 各自变换先烘入
                    mesh_datas.append(me)
        for o in new_objs:                          # 清理导入器创建的物体与数据
            data, otype = o.data, o.type
            bpy.data.objects.remove(o, do_unlink=True)
            if data is not None and data.users == 0:
                if otype == 'CURVE':
                    bpy.data.curves.remove(data)
                elif otype == 'MESH':
                    bpy.data.meshes.remove(data)
        for c in new_cols:
            if not c.objects and not c.children:
                bpy.data.collections.remove(c)

        if not mesh_datas:
            self.report({'ERROR'}, "SVG中没有可填充的图形")
            return {'CANCELLED'}

        name = os.path.splitext(os.path.basename(self.filepath))[0]
        if len(mesh_datas) == 1:
            me = mesh_datas[0]
        else:
            me = join_mesh_datas(mesh_datas, name)
            for m in mesh_datas:
                bpy.data.meshes.remove(m)
        obj = bpy.data.objects.new(name, me)
        context.collection.objects.link(obj)

        merge_close_verts(obj.data)
        normalize_flat_object(context, obj, self.width)
        finish_imported_decal(self, context, obj, p, self.after, target)
        return {'FINISHED'}


class SURFDECAL_OT_import_image(bpy.types.Operator, ImportHelper):
    """导入 PNG/JPG 为贴花:
[贴图面片] 按图像比例生成细分面片并建立 alpha 透明材质(标准贴花)
[矢量化轮廓] 按 alpha/明度阈值提取轮廓生成镂空实体网格"""
    bl_idname = "surfdecal.import_image"
    bl_label = "导入图像为贴花"
    bl_options = {'REGISTER', 'UNDO'}

    filename_ext = ".png"
    filter_glob: bpy.props.StringProperty(
        default="*.png;*.jpg;*.jpeg;*.webp;*.bmp;*.tga;*.tif;*.tiff",
        options={'HIDDEN'})

    mode: bpy.props.EnumProperty(
        name="导入方式",
        items=[
            ('PLANE', "贴图面片(alpha材质)",
             "按图像比例生成细分面片, 图像接BaseColor与Alpha —— 标准贴花"),
            ('VECTOR', "矢量化轮廓(纯几何)",
             "按alpha/明度提取轮廓生成镂空网格, 不需要材质"),
        ],
        default='PLANE')

    width: bpy.props.FloatProperty(
        name="目标宽度", default=0.5, min=0.001, subtype='DISTANCE',
        description="导入后图形的物理宽度(高度按比例)")
    # --- 贴图面片参数 ---
    blend: bpy.props.EnumProperty(
        name="透明混合",
        items=[
            ('HASHED', "抖动", "噪点式半透明, 无排序问题, 采样后收敛(推荐)"),
            ('CLIP', "剪切", "按0.5阈值硬裁切, 最快, 边缘无过渡"),
            ('BLEND', "混合", "平滑半透明, 多层贴花叠加可能排序出错"),
        ],
        default='HASHED')
    luma_alpha: bpy.props.BoolProperty(
        name="无alpha时用明度", default=False,
        description="JPG等无透明通道的图: 用明度当alpha(黑=透明, 适合白图案黑底)")
    # --- 矢量化参数 ---
    channel: bpy.props.EnumProperty(
        name="取形通道",
        items=[
            ('AUTO', "自动", "有透明通道用alpha, 否则用明度"),
            ('ALPHA', "Alpha", "不透明区域为实体"),
            ('LUMA', "明度", "亮部为实体(白图案黑底)"),
            ('LUMA_INV', "明度反相", "暗部为实体(黑图案白底, 如标识/模板喷绘图)"),
        ],
        default='AUTO')
    threshold: bpy.props.FloatProperty(
        name="阈值", default=0.5, min=0.01, max=0.99,
        description="高于此值的像素视为实体")
    max_res: bpy.props.IntProperty(
        name="采样分辨率", default=384, min=64, max=1024,
        description="长边超过此值先均值池化降采样(越高轮廓越细, 越慢)")
    simplify: bpy.props.FloatProperty(
        name="简化容差(像素)", default=1.0, min=0.0, max=5.0,
        description="RDP折线简化强度, 0为不简化")
    min_area: bpy.props.FloatProperty(
        name="最小孤岛(像素²)", default=4.0, min=0.0,
        description="过滤小于此面积的噪点轮廓")
    after: bpy.props.EnumProperty(
        name="导入后",
        items=[
            ('CONFORM', "吸附到选中物体", "吸附到导入前选中的网格或组实例(默认)"),
            ('PLACE', "进入交互投放", "导入完成直接进入投放模式, 在表面滑动摆放"),
            ('NONE', "仅导入到游标", "只创建物体, 之后手动处理"),
        ],
        default='CONFORM')

    @classmethod
    def poll(cls, context):
        return context.mode == 'OBJECT'

    def draw(self, context):
        layout = self.layout
        layout.use_property_split = True
        layout.use_property_decorate = False
        layout.prop(self, "mode", text="")
        layout.prop(self, "width")
        layout.prop(self, "after")
        layout.separator()
        if self.mode == 'PLANE':
            layout.prop(self, "luma_alpha")     # 混合模式为EEVEE专属, Cycles不读
        else:
            layout.prop(self, "channel")
            layout.prop(self, "threshold")
            layout.prop(self, "max_res")
            layout.prop(self, "simplify")
            layout.prop(self, "min_area")

    def execute(self, context):
        p = context.scene.surfdecal
        target = resolve_import_target(context)     # 导入前选中的物体即目标
        if self.mode == 'PLANE':
            return self._plane(context, p, target)
        return self._vector(context, p, target)

    def _plane(self, context, p, target):
        """贴图面片: 面片实体 + 图像alpha材质(标准贴花)。"""
        try:
            img = bpy.data.images.load(self.filepath, check_existing=True)
        except Exception as e:         # 边界IO: 用户选的文件可能非法
            self.report({'ERROR'}, "图像加载失败: %s" % e)
            return {'CANCELLED'}
        w, h = img.size
        if w == 0 or h == 0:
            if img.users == 0:
                bpy.data.images.remove(img)
            self.report({'ERROR'}, "图像尺寸无效")
            return {'CANCELLED'}

        obj = create_image_decal_object(context, img, self.width,
                                        self.blend, self.luma_alpha, p.grid)
        if obj is None:
            self.report({'ERROR'}, "图像尺寸无效")
            return {'CANCELLED'}
        obj.location = context.scene.cursor.location
        register_library_asset(img, self.filepath, context)   # §9.3 导入时登记
        finish_imported_decal(self, context, obj, p, self.after, target)
        return {'FINISHED'}

    def _vector(self, context, p, target):
        """矢量化轮廓: 阈值→Marching Squares→RDP→曲线填充→网格。"""
        try:
            img = bpy.data.images.load(self.filepath, check_existing=False)
        except Exception as e:         # 边界IO: 用户选的文件可能非法
            self.report({'ERROR'}, "图像加载失败: %s" % e)
            return {'CANCELLED'}
        w, h = img.size
        c = img.channels
        if w == 0 or h == 0:
            bpy.data.images.remove(img)
            self.report({'ERROR'}, "图像尺寸无效")
            return {'CANCELLED'}
        px = np.empty(w * h * c, dtype=np.float32)
        img.pixels.foreach_get(px)
        bpy.data.images.remove(img)             # 用完即删, 不留数据块
        arr = px.reshape(h, w, c)               # Blender像素首行在底部, y向上 ✓

        field = field_from_pixels(arr, self.channel)
        field, k = pool_field(field, self.max_res)

        loops = extract_contours(field, self.threshold)
        # 面积过滤(换算回原始像素单位) + 简化
        kept = []
        for lp in loops:
            if abs(polygon_area(lp)) * k * k < self.min_area:
                continue
            kept.append(simplify_loop(lp, self.simplify))
        if not kept:
            self.report({'ERROR'},
                        "未提取到轮廓, 试试调整阈值或切换取形通道(黑白图案常用明度反相)")
            return {'CANCELLED'}

        # 像素坐标 → 米: 去除1px填充偏移, 乘池化系数, 以图像中心为原点
        sx = self.width / float(w)
        name = os.path.splitext(os.path.basename(self.filepath))[0]
        cu = bpy.data.curves.new(name, 'CURVE')
        cu.dimensions = '2D'
        cu.fill_mode = 'BOTH'                   # 偶奇填充, 嵌套轮廓自动成孔洞
        for lp in kept:
            sp = cu.splines.new('POLY')
            sp.points.add(len(lp) - 1)
            for pt, (x, y) in zip(sp.points, lp):
                pt.co = (((x - 1.0) * k - w * 0.5) * sx,
                         ((y - 1.0) * k - h * 0.5) * sx, 0.0, 1.0)
            sp.use_cyclic_u = True

        # 曲线填充→网格: 走 new_from_object, 文件浏览器上下文也安全
        cu_obj = bpy.data.objects.new(name, cu)
        context.collection.objects.link(cu_obj)
        depsgraph = context.evaluated_depsgraph_get()
        me = new_mesh_from_object(cu_obj, depsgraph)
        bpy.data.objects.remove(cu_obj, do_unlink=True)
        if cu.users == 0:
            bpy.data.curves.remove(cu)
        if me is None:
            self.report({'ERROR'}, "轮廓填充失败, 试试提高采样分辨率或加大简化容差")
            return {'CANCELLED'}
        obj = bpy.data.objects.new(name, me)
        context.collection.objects.link(obj)

        merge_close_verts(obj.data)
        obj.location = context.scene.cursor.location
        finish_imported_decal(self, context, obj, p, self.after, target)
        return {'FINISHED'}


# ============================================================
#  共用工具: 节点查找 / 作用范围解析 / 目标UV传递
# ============================================================

MOD_TARGET_UV  = "SDG_目标UV"   # 非SD_前缀: 不被 clear_stack 清掉
UV_XFER        = "SD_UVTransfer" # 专用传入层(仿DECALmachine, 不碰自身UV)
MATCH_TAG      = "SDR_"         # 粗糙度/法线匹配复制来的节点前缀
MATCH_BOX_GROUP_KEY = "sd_match_box_projection_group"


def _find_node(nt, idname):
    for n in nt.nodes:
        if n.bl_idname == idname:
            return n
    return None


def mix_rgba_sockets(node):
    """按类型取 ShaderNodeMix 的 (Factor, A, B, 输出) 的 RGBA 版本。
    该节点为每种数据类型都提供同名 socket, 按索引取会拿错类型。"""
    fac = next(s for s in node.inputs
               if s.type == 'VALUE' and s.name == 'Factor')
    cols = [s for s in node.inputs if s.type == 'RGBA']
    out = next(s for s in node.outputs if s.type == 'RGBA')
    return fac, cols[0], cols[1], out


def mix_float_sockets(node):
    """同上, 取 FLOAT 版的 (Factor, A, B, 输出)。"""
    vals = [s for s in node.inputs if s.type == 'VALUE']
    fac = next(s for s in vals if s.name == 'Factor')
    ab = [s for s in vals if s.name in {'A', 'B'}]
    out = next(s for s in node.outputs if s.type == 'VALUE')
    return fac, ab[0], ab[1], out


def mix_vector_sockets(node):
    """取 ShaderNodeMix 的向量版 (Factor, A, B, 输出)。"""
    fac = next(s for s in node.inputs
               if s.type == 'VALUE' and s.name == 'Factor')
    vecs = [s for s in node.inputs if s.type == 'VECTOR'
            and s.name in {'A', 'B'}]
    out = next(s for s in node.outputs if s.type == 'VECTOR')
    return fac, vecs[0], vecs[1], out


def decals_of_target(target):
    """场景中以该物体为目标的全部贴花(含实例集合内的, 故走 bpy.data)。"""
    out = []
    for o in bpy.data.objects:
        if o.type == 'MESH' and is_decal(o) \
                and o.get(KEY_TARGET, "") == target.name:
            out.append(o)
    return out


def gather_scope(context, p):
    """按作用范围解析出 (贴花列表, 目标列表), 均已去重。"""
    sel = list(context.selected_objects)
    dmap, tmap = {}, {}
    if p.scope == 'ALL':
        for o in bpy.data.objects:
            if o.type == 'MESH' and is_decal(o):
                dmap[o.name] = o
                t = decal_target_of(context, o)
                if t is not None:
                    tmap[t.name] = t
    elif p.scope == 'TARGET':
        for o in sel:                       # 选贴花→取其目标; 选网格→即目标
            if is_decal(o):
                t = decal_target_of(context, o)
                if t is not None:
                    tmap[t.name] = t
            elif o.type == 'MESH':
                tmap[o.name] = o
        for t in tmap.values():
            for d in decals_of_target(t):
                dmap[d.name] = d
    else:                                   # SELECTED
        for o in sel:
            if is_decal(o):
                dmap[o.name] = o
                t = decal_target_of(context, o)
                if t is not None:
                    tmap[t.name] = t
    return list(dmap.values()), list(tmap.values())


def target_uv_name(target):
    """目标的活动UV层名; 无UV返回 None。"""
    if target is None or target.data is None:
        return None
    uvs = getattr(target.data, "uv_layers", None)
    if not uvs:
        return None
    act = uvs.active
    return act.name if act is not None else uvs[0].name


def uv_health(target, sample=300):
    """目标UV是否可用。统计UV面积退化的面(塌成线/零面积)占比 ——
    布尔与阵列生成的面常如此, 用它采样会把纹理沿一条线拉满整面。
    返回 (可用, 退化占比, 说明)。"""
    if target is None or target.data is None:
        return False, 1.0, "无网格"
    me = target.data
    uvs = getattr(me, "uv_layers", None)
    if not uvs or len(uvs) == 0:
        return False, 1.0, "无UV层"
    data = (uvs.active or uvs[0]).data
    n = len(me.polygons)
    if n == 0:
        return False, 1.0, "无面"
    step = max(1, n // max(1, sample))
    degen = tot = 0
    for i in range(0, n, step):
        poly = me.polygons[i]
        idx = list(poly.loop_indices)
        if len(idx) < 3:
            continue
        pts = [data[li].uv for li in idx]
        a = 0.0
        for k in range(len(pts)):
            x0, y0 = pts[k][0], pts[k][1]
            x1, y1 = pts[(k + 1) % len(pts)][0], pts[(k + 1) % len(pts)][1]
            a += x0 * y1 - x1 * y0
        a = abs(a) * 0.5
        tot += 1
        if a < 1e-10 or (poly.area > 1e-12 and a / poly.area < 1e-7):
            degen += 1
    ratio = (degen / tot) if tot else 1.0
    return ratio < 0.05, ratio, "退化面 %d/%d (%.0f%%)" % (degen, tot,
                                                        ratio * 100.0)


def ensure_target_uv(decal, target, context=None):
    """把目标的活动UV层传到贴花的专用层。仿 DECALmachine 的 setup_uv_transfer:
    · 用专用层 SD_UVTransfer, 不去改贴花自己的UV(原先用同名层会撞车)
    · 赋值 layers_uv_select_dst 前必须先把贴花设为活动物体 —— 该枚举按活动
      物体解析UV层, 否则静默失败
    · 专用层保持在最后一位(DECALmachine 的 ensure_uv_transfer_is_last)
    返回传入层名或 None。"""
    if target is None or decal is None:
        return None
    src_name = target_uv_name(target)
    if src_name is None:
        return None
    uvs = decal.data.uv_layers
    lay = uvs.get(UV_XFER)
    if lay is not None and len(uvs) > 1 and uvs[-1].name != UV_XFER:
        uvs.remove(lay)                     # 不在末位: 删掉重建
        lay = None
    if lay is None:
        lay = uvs.new(name=UV_XFER)
    m = decal.modifiers.get(MOD_TARGET_UV)
    if m is None:
        m = decal.modifiers.new(MOD_TARGET_UV, 'DATA_TRANSFER')
    # 顺序要紧: 先关掉不需要的类别开关, 再设 data_types_loops。
    # 写 use_poly_data=False 会把已设好的 data_types_loops 清空(实测),
    # 于是修改器"存在、启用、源与层名都对", 却因集合为空而不传任何数据 ——
    # 表现为贴花移动时UV不再更新。故不碰 use_poly_data, 且写完后校验一次。
    for flag in ("use_vert_data", "use_edge_data"):
        if hasattr(m, flag):
            setattr(m, flag, False)
    m.object = target
    m.use_loop_data = True
    m.data_types_loops = {'UV'}
    m.loop_mapping = 'POLYINTERP_NEAREST'
    if set(m.data_types_loops) != {'UV'}:   # 保险: 被任何写入清空则回写
        m.use_loop_data = True
        m.data_types_loops = {'UV'}
    ctx = context or bpy.context
    prev = None
    try:
        vl = ctx.view_layer
        prev = vl.objects.active
        vl.objects.active = decal           # dst枚举按活动物体解析
    except (AttributeError, RuntimeError):
        vl = None
    try:
        if hasattr(m, "layers_uv_select_src"):
            m.layers_uv_select_src = src_name
            m.layers_uv_select_dst = UV_XFER
    except (TypeError, ValueError):
        if hasattr(m, "layers_uv_select_src"):
            m.layers_uv_select_src = 'ALL'
            m.layers_uv_select_dst = 'NAME'
    finally:
        if vl is not None and prev is not None:
            try:
                vl.objects.active = prev
            except (AttributeError, RuntimeError):
                pass
    if is_frozen(decal):
        # 冻结贴花不能留下指向目标的活 Data Transfer；ZML V085 会扫描全场景
        # 修改器的正向/反向对象引用，并据此把贴花重新拉进目标 Group。
        try:
            with ctx.temp_override(
                    object=decal, active_object=decal,
                    selected_objects=[decal], selected_editable_objects=[decal]):
                result = bpy.ops.object.modifier_apply(modifier=m.name)
            if result != {'FINISHED'}:
                raise RuntimeError("目标UV传递修改器未成功应用")
        except (RuntimeError, TypeError, ValueError):
            residual = decal.modifiers.get(MOD_TARGET_UV)
            if residual is not None:
                decal.modifiers.remove(residual)
            return None
    return UV_XFER

# ============================================================
#  粗糙度匹配: 把目标材质的粗糙度链原样复制到贴花
# ============================================================

def _copy_node(dst_nt, node):
    """复制单个着色节点(含属性与输入默认值)。"""
    new = dst_nt.nodes.new(node.bl_idname)
    skip = {"rna_type", "name", "label", "location", "parent", "internal_links",
            "select", "dimensions", "width", "height", "inputs", "outputs",
            "type", "bl_idname", "color", "use_custom_color", "mute", "hide"}
    for prop in node.bl_rna.properties:
        pid = prop.identifier
        if pid in skip or prop.is_readonly:
            continue
        try:
            setattr(new, pid, getattr(node, pid))
        except (AttributeError, TypeError, ValueError):
            pass
    for i, s in enumerate(node.inputs):
        if i >= len(new.inputs):
            break
        try:
            new.inputs[i].default_value = s.default_value
        except (AttributeError, TypeError, ValueError):
            pass
    new.name = MATCH_TAG + node.name
    new.label = node.label or node.name
    new.location = (node.location.x, node.location.y - 900.0)
    return new


def _tree_contains_box_image(node_tree, visited=None):
    """Whether a node tree (including nested groups) uses BOX image projection."""
    if node_tree is None:
        return False
    visited = visited or set()
    pointer = node_tree.as_pointer()
    if pointer in visited:
        return False
    visited.add(pointer)
    for node in node_tree.nodes:
        if (node.bl_idname == 'ShaderNodeTexImage'
                and getattr(node, "projection", 'FLAT') == 'BOX'):
            return True
        if (node.bl_idname == 'ShaderNodeGroup' and node.node_tree is not None
                and _tree_contains_box_image(node.node_tree, visited)):
            return True
    return False


def _one_minus_socket(node_tree, socket, location, name):
    subtract = node_tree.nodes.new('ShaderNodeMath')
    subtract.operation = 'SUBTRACT'
    subtract.name = name
    subtract.inputs[0].default_value = 1.0
    subtract.location = location
    node_tree.links.new(socket, subtract.inputs[1])
    return subtract.outputs[0]


def _flatten_box_image(node_tree, image_node, face, serial):
    """Replace BOX with the exact flat projection for one target-local face.

    Blender's BOX node chooses axes from the *shaded object's* object-space
    normal. A decal has a different object basis from its target, so copying
    the node stretches side-face textures. For a planar target patch the BOX
    source reduces to one deterministic 2D projection; make that projection
    explicit while leaving the target material untouched.
    """
    vector_input = image_node.inputs.get("Vector")
    if vector_input is None or not vector_input.links:
        return False
    source = vector_input.links[0].from_socket
    node_tree.links.remove(vector_input.links[0])

    base_x = image_node.location.x - 420.0
    base_y = image_node.location.y - 120.0
    separate = node_tree.nodes.new('ShaderNodeSeparateXYZ')
    separate.name = "%sBOX_分量_%d" % (MATCH_TAG, serial)
    separate.location = (base_x, base_y)
    node_tree.links.new(source, separate.inputs["Vector"])

    axis, sign = face
    if axis == 'X':
        u = separate.outputs['Y']
        if sign < 0:
            u = _one_minus_socket(
                node_tree, u, (base_x + 170.0, base_y - 120.0),
                "%sBOX_反向U_%d" % (MATCH_TAG, serial))
        v = separate.outputs['Z']
    elif axis == 'Y':
        u = separate.outputs['X']
        if sign > 0:
            u = _one_minus_socket(
                node_tree, u, (base_x + 170.0, base_y - 120.0),
                "%sBOX_反向U_%d" % (MATCH_TAG, serial))
        v = separate.outputs['Z']
    else:
        u = separate.outputs['Y']
        if sign > 0:
            u = _one_minus_socket(
                node_tree, u, (base_x + 170.0, base_y - 120.0),
                "%sBOX_反向U_%d" % (MATCH_TAG, serial))
        v = separate.outputs['X']

    combine = node_tree.nodes.new('ShaderNodeCombineXYZ')
    combine.name = "%sBOX_目标面_%d" % (MATCH_TAG, serial)
    combine.label = "固定为目标物体的 %s%s 面投影" % (
        "+" if sign > 0 else "-", axis)
    combine.location = (base_x + 230.0, base_y)
    node_tree.links.new(u, combine.inputs['X'])
    node_tree.links.new(v, combine.inputs['Y'])
    node_tree.links.new(combine.outputs['Vector'], vector_input)
    image_node.projection = 'FLAT'
    if hasattr(image_node, "projection_blend"):   # 仅 BOX 投影下存在
        image_node.projection_blend = 0.0
    return True


def _correct_box_tree(node_tree, face, serial=0):
    corrected = 0
    for node in tuple(node_tree.nodes):
        if (node.bl_idname == 'ShaderNodeTexImage'
                and getattr(node, "projection", 'FLAT') == 'BOX'):
            corrected += int(_flatten_box_image(
                node_tree, node, face, serial + corrected))
        elif (node.bl_idname == 'ShaderNodeGroup'
              and node.node_tree is not None
              and _tree_contains_box_image(node.node_tree)):
            isolated = node.node_tree.copy()
            isolated.name = MATCH_TAG + "BOX_" + node.node_tree.name
            isolated[MATCH_BOX_GROUP_KEY] = True
            node.node_tree = isolated
            corrected += _correct_box_tree(
                isolated, face, serial + corrected)
    return corrected


def _correct_copied_box_nodes(dst_nt, copied_nodes, face, notes):
    # Previous clear operations may have left isolated group datablocks. They
    # are safe to remove now, outside the node-removal call stack that owned
    # them (deleting immediately there can crash Blender 4.x/5.x RNA).
    _remove_unused_match_box_groups()
    corrected = 0
    for node in tuple(copied_nodes):
        if (node.bl_idname == 'ShaderNodeTexImage'
                and getattr(node, "projection", 'FLAT') == 'BOX'):
            corrected += int(_flatten_box_image(
                dst_nt, node, face, corrected))
        elif (node.bl_idname == 'ShaderNodeGroup'
              and node.node_tree is not None
              and _tree_contains_box_image(node.node_tree)):
            isolated = node.node_tree.copy()
            isolated.name = MATCH_TAG + "BOX_" + node.node_tree.name
            isolated[MATCH_BOX_GROUP_KEY] = True
            node.node_tree = isolated
            corrected += _correct_box_tree(isolated, face, corrected)
    if corrected:
        notes.append("BOX贴图已固定到目标局部面，避免贴花坐标系拉伸")
    return corrected


def _planar_target_box_face(decal, target):
    """Return dominant target-local face axis for a planar decal patch."""
    if decal is None or target is None or target.type != 'MESH':
        return None
    # 只看贴花中心正下方那个面。原先要求整片足迹平坦(>0.5° 即放弃), 但贴花
    # 一旦悬到棱边外, 越棱的采样点最近面就变成侧面, 平坦度直接跳到90°,
    # BOX展平保护被整体跳过 —— 而中心面其实是明确的(锚点法线夹角0°)。
    # 中心面就足以确定 BOX 的那一个确定性 2D 投影。
    try:
        local_point = target.matrix_world.inverted() @ decal.matrix_world.translation
        found, _location, normal, _index = target.closest_point_on_mesh(
            local_point, distance=1.0e20)
    except (AttributeError, RuntimeError, ValueError):
        return None
    if not found or normal.length_squared < 1.0e-12:
        return None
    components = (normal.x, normal.y, normal.z)
    index = max(range(3), key=lambda item: abs(components[item]))
    return "XYZ"[index], 1 if components[index] >= 0.0 else -1


def copy_upstream(dst_nt, socket, target, uv_name, notes, box_face=None):
    """把 socket 的上游子树复制到 dst_nt, 并按坐标类型重定向到 target。
    返回复制后对应的输出socket(无链接则 None)。"""
    if not socket.links:
        return None
    made = {}

    def clone(node):
        if node.name in made:
            return made[node.name]
        new = _copy_node(dst_nt, node)
        made[node.name] = new
        for i, s in enumerate(node.inputs):
            if not s.links or i >= len(new.inputs):
                continue
            ln = s.links[0]
            un = clone(ln.from_node)
            try:
                oi = list(ln.from_node.outputs).index(ln.from_socket)
            except ValueError:
                continue
            if oi < len(un.outputs):
                dst_nt.links.new(un.outputs[oi], new.inputs[i])
        return new

    ln0 = socket.links[0]
    root = clone(ln0.from_node)

    # 坐标重定向: 贴花与目标是不同物体, 同名坐标源含义不同
    for src_node, new in made.items():
        if new.bl_idname == 'ShaderNodeTexCoord':
            new.object = target
            for lk in list(dst_nt.links):
                # RNA 包装对象每次访问可能是不同的 Python 实例, 用 is 会
                # 误判并删掉刚建好的连接(UV / Generated 分支就这么坏的)
                if lk.from_node.as_pointer() != new.as_pointer():
                    continue
                nm = lk.from_socket.name
                if nm == 'Object':
                    continue                    # 已指向目标, 正确
                if nm == 'Generated':
                    # 生成坐标 = 目标包围盒归一化 → 用Object+Mapping等价替换
                    mp = dst_nt.nodes.new('ShaderNodeMapping')
                    mp.name = MATCH_TAG + "生成坐标等价"
                    mp.label = "Generated→目标包围盒"
                    mp.location = (new.location.x + 200.0, new.location.y)
                    _set_bbox_mapping_generated(mp, target)
                    dst_nt.links.new(new.outputs['Object'], mp.inputs['Vector'])
                    dst_nt.links.new(mp.outputs['Vector'], lk.to_socket)
                    notes.append("Generated坐标已换算为目标包围盒空间")
                elif nm == 'UV':
                    if uv_name:
                        uvn = dst_nt.nodes.new('ShaderNodeUVMap')
                        uvn.name = MATCH_TAG + "目标UV"
                        uvn.uv_map = uv_name
                        uvn.location = (new.location.x, new.location.y - 200.0)
                        dst_nt.links.new(uvn.outputs['UV'], lk.to_socket)
                        notes.append("UV坐标已改用传递来的目标UV层")
                    else:
                        notes.append("! 目标用UV采样但UV不可用, 结果可能不符")
        elif new.bl_idname == 'ShaderNodeUVMap' and uv_name:
            new.uv_map = uv_name
    # 目标材质里未显式指定UV的贴图, 会隐式用"活动UV层" —— 复制到贴花后
    # 活动层是贴花自己的UV, 坐标就错了; 故一律显式绑定传入层
    if uv_name:
        for new in made.values():
            if new.bl_idname != 'ShaderNodeTexImage':
                continue
            if new.inputs["Vector"].links:
                continue
            uvn = dst_nt.nodes.new('ShaderNodeUVMap')
            uvn.name = MATCH_TAG + "绑定UV_" + new.name[-12:]
            uvn.uv_map = uv_name
            uvn.location = (new.location.x - 220.0, new.location.y - 160.0)
            dst_nt.links.new(uvn.outputs["UV"], new.inputs["Vector"])
            notes.append("已为复制的贴图显式绑定传入UV(否则会用贴花自身UV)")
    if box_face is not None:
        _correct_copied_box_nodes(dst_nt, made.values(), box_face, notes)
    try:
        oi = list(ln0.from_node.outputs).index(ln0.from_socket)
    except ValueError:
        oi = 0
    return root.outputs[oi] if oi < len(root.outputs) else None


def _set_bbox_mapping_generated(node, target):
    """Generated 坐标 = 局部坐标按包围盒逐轴归一化到0~1(不置换轴)。"""
    if target is None or target.data is None:
        return
    bb = [Vector(c) for c in target.bound_box]
    if not bb:
        return
    mn = Vector((min(v.x for v in bb), min(v.y for v in bb),
                 min(v.z for v in bb)))
    mx = Vector((max(v.x for v in bb), max(v.y for v in bb),
                 max(v.z for v in bb)))
    sz = mx - mn
    inv = Vector((1.0 / sz.x if abs(sz.x) > 1e-9 else 1.0,
                  1.0 / sz.y if abs(sz.y) > 1e-9 else 1.0,
                  1.0 / sz.z if abs(sz.z) > 1e-9 else 1.0))
    node.inputs["Scale"].default_value = inv[:]
    node.inputs["Rotation"].default_value = (0.0, 0.0, 0.0)
    node.inputs["Location"].default_value = (-mn.x * inv.x, -mn.y * inv.y,
                                             -mn.z * inv.z)


def _remove_unused_match_box_groups():
    """Remove isolated BOX-correction groups after their match nodes go away."""
    removed = 0
    while True:
        unused = [group for group in bpy.data.node_groups
                  if group.get(MATCH_BOX_GROUP_KEY) and group.users == 0]
        if not unused:
            return removed
        for group in unused:
            bpy.data.node_groups.remove(group)
            removed += 1


def clear_match(mat):
    """清掉表面匹配资源，并保持 Bridge → Principled 的主链不变。"""
    if mat is None or not mat.use_nodes:
        return False
    nt = mat.node_tree
    hit = [n for n in nt.nodes if n.name.startswith(MATCH_TAG)]
    bridge = get_bridge(mat)
    reset = False
    if bridge is not None:
        defaults = {
            "Target Color": (0.5, 0.5, 0.5, 1.0),
            "Target Roughness": 0.5,
            "Target Normal": (0.0, 0.0, 1.0),
            "Target Normal Weight": 0.0,
        }
        for name, value in defaults.items():
            socket = bridge_in(bridge, name)
            if socket is None:
                continue
            for link in list(socket.links):
                if link.from_node.name.startswith(MATCH_TAG):
                    nt.links.remove(link)
                    reset = True
            if not socket.links:
                try:
                    socket.default_value = value
                except (TypeError, ValueError):
                    pass
        wear = bridge_in(bridge, "Wear Field")
        if wear is not None:
            for link in list(wear.links):
                if link.from_node.name.startswith(MATCH_TAG):
                    nt.links.remove(link)
                    reset = True
    for n in hit:
        nt.nodes.remove(n)
    return bool(hit or reset)


def _decal_image_node(nt):
    """贴花自己的图案贴图节点(排除匹配/污迹复制来的)。"""
    for n in nt.nodes:
        if (n.bl_idname == 'ShaderNodeTexImage'
                and not n.name.startswith(MATCH_TAG)
                and not n.name.startswith(LEGACY_WEAR_TAG)
                and not n.name.startswith(RELIEF_TAG)
                and not n.name.startswith((SLOT_WEAR, SLOT_SHARED, SLOT_EDGE))):
            return n
    return None


def _match_wear_field(nt, source_sock, p, bx, by):
    """墙面污渍 → 灰度 → 阈值 → Bridge 损伤场；白=保留，黑=磨掉。"""
    bw = nt.nodes.new('ShaderNodeRGBToBW')
    bw.name = MATCH_TAG + "磨损灰度"
    bw.location = (bx - 900.0, by - 1000.0)
    nt.links.new(source_sock, bw.inputs["Color"])
    ramp = nt.nodes.new('ShaderNodeValToRGB')
    ramp.name = MATCH_TAG + "磨损阈值"
    ramp.location = (bx - 740.0, by - 1000.0)
    t = p.match_wear_threshold
    w = max(0.01, p.match_wear_softness) * 0.5
    e0, e1 = ramp.color_ramp.elements[0], ramp.color_ramp.elements[1]
    e0.position = max(0.0, t - w)
    e1.position = min(1.0, t + w)
    dark = (0.0, 0.0, 0.0, 1.0)
    light = (1.0, 1.0, 1.0, 1.0)
    e0.color = light if p.match_wear_invert else dark
    e1.color = dark if p.match_wear_invert else light
    nt.links.new(bw.outputs["Val"], ramp.inputs["Fac"])
    inv = nt.nodes.new('ShaderNodeMath')
    inv.operation = 'SUBTRACT'
    inv.name = MATCH_TAG + "磨损损伤"
    inv.location = (bx - 560.0, by - 1000.0)
    inv.inputs[0].default_value = 1.0
    nt.links.new(ramp.outputs["Color"], inv.inputs[1])
    return inv.outputs[0]


def match_target_material(decal_mat, target_mat, target, uv_name, p,
                          decal=None):
    """把目标材质的通道匹配到贴花: 粗糙度(可加偏移) / 微表面法线 / 磨损侵蚀。
    所有结果进入表面桥接；Principled 不再由匹配功能直接改线。
    Target Color 只作为印刷/信息模式的表面底色，不会覆盖 Artwork。
    返回 (成功, 说明列表)。"""
    if decal_mat is None or not decal_mat.use_nodes:
        return False, ["贴花无节点材质"]
    if target_mat is None or not target_mat.use_nodes:
        return False, ["目标无节点材质"]
    dnt = decal_mat.node_tree
    db = _find_node(dnt, 'ShaderNodeBsdfPrincipled')
    tb = _find_node(target_mat.node_tree, 'ShaderNodeBsdfPrincipled')
    if db is None or tb is None:
        return False, ["缺少 Principled BSDF"]
    bridge = ensure_bridge(decal_mat)
    if bridge is None:
        return False, ["无法准备表面处理节点"]
    clear_match(decal_mat)
    notes = []
    # 目标材质若还挂着早期污迹系统的链, 它的 Mapping 会按"竖向拉伸"把纹理
    # 沿Z拉长(伪造流挂条痕)。匹配是忠实复制, 所以那份拉伸会一起进来 ——
    # 这不是复制错误, 但必须让用户知道来源在目标材质。
    _legacy = [nd.name for nd in target_mat.node_tree.nodes
               if nd.name.startswith("SD_G_")
               or (nd.bl_idname == 'ShaderNodeGroup'
                   and nd.node_tree is not None
                   and nd.node_tree.name == "SD_污迹")]
    if _legacy:
        notes.append("注意: 目标材质仍在用早期污迹链(%s), 其"
                     "竖向拉伸会被一并复制 —— 拉伸源在目标材质, 不在贴花"
                     % _legacy[0])
    bx, by = db.location.x, db.location.y
    rough_out = None
    box_face = _planar_target_box_face(decal, target)

    # ---- 目标底色：供印刷/信息模式使用，不改 Artwork ----
    tbc = tb.inputs.get("Base Color")
    target_color = bridge_in(bridge, "Target Color")
    if tbc is not None and target_color is not None:
        if tbc.links:
            out = copy_upstream(
                dnt, tbc, target, uv_name, notes, box_face)
            if out is not None:
                dnt.links.new(out, target_color)
                notes.append("目标底色: 已送入表面桥接")
        else:
            target_color.default_value = tbc.default_value
            notes.append("目标底色: 常量已送入表面桥接")

    # ---- 粗糙度 ----
    if p.match_rough:
        tro = tb.inputs.get("Roughness")
        target_rough = bridge_in(bridge, "Target Roughness")
        artwork_rough = bridge_in(bridge, "Artwork Roughness")
        if tro is not None and target_rough is not None and artwork_rough is not None:
            if not tro.links:
                target_rough.default_value = tro.default_value
                artwork_rough.default_value = min(1.0, max(
                    0.0, tro.default_value + p.match_rough_offset
                ))
                notes.append("粗糙度: 目标为常量 %.3f (+偏移 %.2f)"
                             % (tro.default_value, p.match_rough_offset))
            else:
                out = copy_upstream(
                    dnt, tro, target, uv_name, notes, box_face)
                rough_out = out
                if out is not None:
                    dnt.links.new(out, target_rough)
                    artwork_out = out
                    if abs(p.match_rough_offset) > 1e-6:
                        add = dnt.nodes.new('ShaderNodeMath')
                        add.operation = 'ADD'
                        add.use_clamp = True
                        add.name = MATCH_TAG + "粗糙度偏移"
                        add.location = (bx - 300.0, by - 260.0)
                        add.inputs[1].default_value = p.match_rough_offset
                        dnt.links.new(out, add.inputs[0])
                        artwork_out = add.outputs[0]
                        notes.append("粗糙度: 已复制目标链 +%.2f 偏移"
                                     % p.match_rough_offset)
                    else:
                        notes.append("粗糙度: 已复制目标链")
                    dnt.links.new(artwork_out, artwork_rough)

    # ---- 微表面法线 ----
    if p.match_normal:
        tn = tb.inputs.get("Normal")
        target_normal = bridge_in(bridge, "Target Normal")
        if tn is not None and target_normal is not None and tn.links:
            srcn = tn.links[0].from_node
            img_sock = None
            if srcn.bl_idname == 'ShaderNodeNormalMap':
                ci = srcn.inputs.get("Color")
                if ci is not None and ci.links:
                    img_sock = copy_upstream(
                        dnt, ci, target, uv_name, notes, box_face)
            else:
                img_sock = copy_upstream(
                    dnt, tn, target, uv_name, notes, box_face)
            if img_sock is not None:
                nm = dnt.nodes.new('ShaderNodeNormalMap')
                nm.name = MATCH_TAG + "法线贴图"
                nm.location = (bx - 300.0, by - 520.0)
                if uv_name:
                    nm.uv_map = uv_name        # 必须显式绑定传入UV(见方案§7.3)
                if srcn.bl_idname == 'ShaderNodeNormalMap':
                    try:
                        nm.space = srcn.space
                    except (AttributeError, TypeError):
                        pass
                nm.inputs["Strength"].default_value = p.match_normal_strength
                dnt.links.new(img_sock, nm.inputs["Color"])
                dnt.links.new(nm.outputs["Normal"], target_normal)
                bridge_in(bridge, "Target Normal Weight").default_value = 1.0
                notes.append("微表面法线: 已接入(强度 %.2f); 若方向不对请关闭"
                             % p.match_normal_strength)
        else:
            notes.append("微表面法线: 目标没接法线贴图, 跳过")

    # ---- 磨损侵蚀(侵蚀贴花Alpha, 相当于INFO的Masks) ----
    if p.match_wear and p.match_wear_amount > 0.0:
        wsrc = None
        if p.match_wear_source == 'ROUGH' and rough_out is not None:
            wsrc = rough_out
        elif p.match_wear_source == 'BASE':
            tbc = tb.inputs.get("Base Color")
            if tbc is not None and tbc.links:
                wsrc = copy_upstream(
                    dnt, tbc, target, uv_name, notes, box_face)
        elif p.match_wear_source == 'IMAGE' and p.match_wear_image is not None:
            tex = dnt.nodes.new('ShaderNodeTexImage')
            tex.name = MATCH_TAG + "磨损贴图"
            tex.image = p.match_wear_image
            tex.location = (bx - 1120.0, by - 1000.0)
            if uv_name:
                uvn = dnt.nodes.new('ShaderNodeUVMap')
                uvn.name = MATCH_TAG + "磨损UV"
                uvn.uv_map = uv_name
                uvn.location = (bx - 1320.0, by - 1000.0)
                dnt.links.new(uvn.outputs["UV"], tex.inputs["Vector"])
            wsrc = tex.outputs["Color"]
        if wsrc is None:
            notes.append("磨损: 取不到来源, 跳过(粗糙度来源需先开启粗糙度匹配)")
        else:
            out = _match_wear_field(dnt, wsrc, p, bx, by)
            dnt.links.new(out, bridge_in(bridge, "Wear Field"))
            bridge_in(bridge, "Wear Weight").default_value = p.match_wear_amount
            notes.append("磨损: 已送入表面桥接(强度 %.2f, 阈值 %.2f%s)"
                         % (p.match_wear_amount, p.match_wear_threshold,
                            ", 反相" if p.match_wear_invert else ""))
    _connect_bridge_outputs(dnt, bridge, db)
    layout_slot_nodes(dnt, bridge, MATCH_TAG, 'MATCH')
    return True, notes


def match_roughness(decal_mat, target_mat, target, uv_name):
    """兼容旧调用: 只匹配粗糙度、无偏移。"""
    ns = SimpleNamespace(match_rough=True, match_rough_offset=0.0,
                         match_normal=False, match_wear=False,
                         match_wear_amount=0.0)
    okk, notes = match_target_material(decal_mat, target_mat, target,
                                       uv_name, ns)
    return okk, "; ".join(notes) if notes else "已匹配"



class SURFDECAL_OT_match_roughness(bpy.types.Operator):
    """把目标材质的粗糙度设置原样复制到所选贴花 —— 目标是常量就抄数值,
是贴图就整条上游链复制过来, 并把坐标源重定向到目标物体。
不生成任何新图案, 只做匹配"""
    bl_idname = "surfdecal.match_roughness"
    bl_label = "匹配目标材质"
    bl_options = {'REGISTER', 'UNDO'}

    @classmethod
    def poll(cls, context):
        return context.mode == 'OBJECT'

    def execute(self, context):
        p = context.scene.surfdecal
        decals, _t = gather_scope(context, p)
        if not decals:
            self.report({'ERROR'}, "请选中贴花(或其目标墙面)")
            return {'CANCELLED'}
        split = split_shared_materials(decals, context)  # 写时复制
        for d in decals:                         # 分家后顺带规范命名
            auto_name_decal(d, decal_target_of(context, d) or d.parent)
        done = 0
        seen = set()
        msgs = []
        for d in decals:
            tgt = decal_target_of(context, d) or d.parent
            if tgt is None or not tgt.material_slots:
                continue
            tmat = tgt.material_slots[0].material
            uv_name = None
            good, _r, _w = uv_health(tgt)
            if good:
                uv_name = ensure_target_uv(d, tgt, context)
            for slot in d.material_slots:
                m = slot.material
                if m is None or m.name in seen:
                    continue
                seen.add(m.name)
                okk, notes = match_target_material(
                    m, tmat, tgt, uv_name, p, decal=d)
                if okk:
                    done += 1
                    for nt_ in notes:
                        if nt_ not in msgs:
                            msgs.append(nt_)
                else:
                    self.report({'WARNING'}, "%s: %s"
                                % (m.name, "; ".join(notes)))
        if done == 0:
            self.report({'ERROR'}, "没有可匹配的贴花材质")
            return {'CANCELLED'}
        msg = "已匹配 %d 个贴花材质 — %s" % (done, "; ".join(msgs))
        if split:
            msg += " (已为 %d 个贴花独立化材质)" % split
        self.report({'INFO'}, msg)
        return {'FINISHED'}


class SURFDECAL_OT_match_clear(bpy.types.Operator):
    """清除粗糙度匹配复制来的节点"""
    bl_idname = "surfdecal.match_clear"
    bl_label = "清除匹配"
    bl_options = {'REGISTER', 'UNDO'}

    @classmethod
    def poll(cls, context):
        return context.mode == 'OBJECT'

    def execute(self, context):
        p = context.scene.surfdecal
        decals, _t = gather_scope(context, p)
        n = 0
        seen = set()
        for d in decals:
            for slot in d.material_slots:
                m = slot.material
                if m and m.name not in seen:
                    seen.add(m.name)
                    if clear_match(m):
                        n += 1
        if n == 0:
            self.report({'ERROR'}, "没有匹配节点可清除")
            return {'CANCELLED'}
        self.report({'INFO'}, "已清除 %d 个材质的匹配节点" % n)
        return {'FINISHED'}


# ============================================================
#  阶段B/C: 独立资源槽 + 表面桥接统一出口
# ============================================================

# ---- 阶段B 代码块: 独立资源槽(Wear / Edge / Normal) ----
# 语义统一: 黑=无损伤, 白=损伤最强(方案 §4.1 / §4.2)
CH_ITEMS = [
    ('LUM', "亮度", "RGB转灰度"),
    ('R', "R", ""), ('G', "G", ""), ('B', "B", ""), ('A', "Alpha", ""),
]
UVSPACE_ITEMS = [
    ('DECAL', "贴花UV", "属于这张贴花, 移动/复制时图案随之移动"),
    ('TARGET', "目标传递UV", "属于目标表面, 同一目标上多张贴花共享连续场"),
]
def _shared_group_owner_scene(group, context=None):
    """Resolve the Scene that owns a shared-wear PropertyGroup instance."""
    preferred = getattr(context, "scene", None)
    scenes = ([preferred] if preferred is not None else [])
    scenes.extend(scene for scene in bpy.data.scenes if scene != preferred)
    pointer = group.as_pointer()
    for scene in scenes:
        groups = getattr(scene, "surfdecal_shared_wear_groups", ())
        if any(item.as_pointer() == pointer for item in groups):
            return scene
    return preferred


def _shared_group_structural_update(self, context):
    """贴图/通道改变会改变节点拓扑，只在离散选择时重建一次。"""
    try:
        rebuild_shared_wear_group(
            self.uid, _shared_group_owner_scene(self, context))
    except (AttributeError, RuntimeError, ReferenceError):
        pass


def _shared_group_value_update(self, context):
    """拖动参数时只推进现有节点数值，避免整组材质反复重建。"""
    try:
        sync_shared_wear_group(
            self.uid, _shared_group_owner_scene(self, context))
    except (AttributeError, RuntimeError, ReferenceError):
        pass


class SD_SharedWearGroup(bpy.types.PropertyGroup):
    """保存在 Scene 内的共享磨损资源；随 .blend 保存，不依赖当前选择。"""
    uid: bpy.props.StringProperty(name="ID", default="")
    label: bpy.props.StringProperty(name="名称", default="共享贴花 1")
    image: bpy.props.PointerProperty(name="共享磨损贴图", type=bpy.types.Image,
                                    update=_shared_group_structural_update)
    channel: bpy.props.EnumProperty(name="通道", items=CH_ITEMS, default='LUM',
                                    update=_shared_group_structural_update)
    invert: bpy.props.BoolProperty(name="反相", default=False,
                                  update=_shared_group_value_update)
    threshold: bpy.props.FloatProperty(name="阈值", default=0.5,
                                       min=0.0, max=1.0,
                                       update=_shared_group_value_update)
    softness: bpy.props.FloatProperty(name="过渡宽度", default=0.25,
                                      min=0.005, max=1.0,
                                      update=_shared_group_value_update)
    location: bpy.props.FloatVectorProperty(name="位置", size=2,
                                            default=(0.0, 0.0), subtype='XYZ',
                                            update=_shared_group_value_update)
    rotation: bpy.props.FloatProperty(name="旋转", subtype='ANGLE', default=0.0,
                                      update=_shared_group_value_update)
    scale: bpy.props.FloatVectorProperty(name="图案大小", size=2,
                                         default=(1.0, 1.0), min=0.001,
                                         soft_max=20.0,
                                         update=_shared_group_value_update)
    space: bpy.props.EnumProperty(
        name="投影空间",
        items=[('UV', "目标UV", "沿目标的UV展开; 磨损跟着UV走"),
               ('OBJECT', "目标物体(三平面)",
                "沿目标的局部坐标盒状投影; 不依赖UV质量, "
                "阵列/镜像出来的复制体各自落在磨损场的不同位置")],
        default='UV', update=_shared_group_structural_update)


def _node_width(nd):
    """节点宽度估算; width 可用时优先。"""
    w = getattr(nd, "width", 0.0) or 0.0
    if w > 1.0:
        return w
    return {'ShaderNodeTexImage': 240.0, 'ShaderNodeValToRGB': 240.0,
            'ShaderNodeGroup': 200.0, 'ShaderNodeMapping': 160.0}.get(
                nd.bl_idname, 150.0)


def _node_height(nd):
    """节点高度估算。dimensions 只在节点编辑器绘制过后有效, 建链时通常为0,
    所以要有一个够准的回退: 按可见 socket 行数 + 控件高度。"""
    dim = getattr(nd, "dimensions", None)
    if dim is not None and getattr(dim, "y", 0.0) > 1.0:
        return float(dim.y)
    rows = 0
    for s in list(nd.inputs) + list(nd.outputs):
        if getattr(s, "hide", False) or not getattr(s, "enabled", True):
            continue
        # 未连接的矢量/颜色输入会展开成多行
        if s.type in {'VECTOR', 'RGBA'} and not s.links:
            rows += 3
        else:
            rows += 1
    extra = {'ShaderNodeTexImage': 170.0, 'ShaderNodeValToRGB': 150.0,
             'ShaderNodeMapRange': 60.0, 'ShaderNodeMix': 70.0,
             'ShaderNodeAttribute': 50.0, 'ShaderNodeUVMap': 50.0,
             'ShaderNodeTexCoord': 20.0, 'ShaderNodeMath': 45.0,
             'ShaderNodeVectorMath': 45.0}.get(nd.bl_idname, 25.0)
    return 40.0 + rows * 24.0 + extra


# 槽的排序权重: 同一列里按功能聚在一起, 顺序稳定
SD_SLOT_ORDER = ('MATCH', 'WEAR', 'SHARED', 'EDGE', 'RELIEF', 'ARTWORK')


def _slot_of_node(nd):
    """节点属于哪个功能组; 用于列内分组排序。

    前缀常量分散在文件各处(有几个定义在本函数之后), 所以用 globals() 延后
    取值, 取不到的直接跳过 —— 布局不依赖常量的定义顺序, 也不会因为某个
    历史常量被删掉(例如 v8 移除的 WEAR_TAG)而在运行时抛 NameError。
    """
    name = nd.name
    table = globals()
    for key, slot in (("MATCH_TAG", 'MATCH'), ("SLOT_WEAR", 'WEAR'),
                      ("SLOT_SHARED", 'SHARED'), ("SLOT_EDGE", 'EDGE'),
                      ("RELIEF_TAG", 'RELIEF'), ("WEAR_TAG", 'WEAR')):
        tag = table.get(key)
        if tag and name.startswith(tag):
            return slot
    return 'ARTWORK'



def layout_managed_graph(nt, bridge, col_gap=60.0, row_gap=40.0,
                         group_gap=70.0):
    """以 Bridge 为锚, 把它上游的全部节点排成从左到右的流水线。

    做法是按拓扑深度分列(深度=到 Bridge 的最长路径), 而不是按功能给固定
    行带 —— 固定行带会把各槽推到很远, 连线反而更长更乱。
    列内按功能分组紧凑堆叠, 行距由节点实际高度算出, 因此不会重叠也不留大洞。
    Bridge / BSDF / 材质输出保持原位, 不打扰用户自己的摆放。
    返回移动的节点数。
    """
    if bridge is None:
        return 0
    depth = {}
    frontier = [(bridge, 0)]
    guard = 0
    while frontier and guard < 4000:
        node, d = frontier.pop()
        guard += 1
        for sock in node.inputs:
            for link in sock.links:
                up = link.from_node
                key = up.as_pointer()
                if depth.get(key, (-1,))[0] >= d + 1:
                    continue                # 已在更左的列, 不必回拉
                depth[key] = (d + 1, up)
                frontier.append((up, d + 1))
    if not depth:
        return 0

    columns = {}
    for d, node in depth.values():
        columns.setdefault(d, []).append(node)

    moved = 0
    x_cursor = bridge.location.x
    top = bridge.location.y + 180.0
    for d in sorted(columns):
        col = columns[d]
        col.sort(key=lambda n: (SD_SLOT_ORDER.index(_slot_of_node(n))
                                if _slot_of_node(n) in SD_SLOT_ORDER else 99,
                                n.name))
        width = max(_node_width(n) for n in col)
        x_cursor -= width + col_gap
        y = top
        prev_slot = None
        for node in col:
            slot = _slot_of_node(node)
            if prev_slot is not None and slot != prev_slot:
                y -= group_gap             # 不同功能之间留一点呼吸
            prev_slot = slot
            node.location = (x_cursor, y)
            y -= _node_height(node) + row_gap
            moved += 1
    return moved


def layout_slot_nodes(nt, bridge, tag, lane):
    """兼容旧调用: 现在一律整体重排, 保证任何一次建链后全图都是齐的。"""
    return layout_managed_graph(nt, bridge)



def _mask_channel_socket(nt, tex, channel, tag, loc):
    """按通道取出标量: 亮度走 RGBToBW, RGBA 走 SeparateColor / Alpha。"""
    if channel == 'A':
        return tex.outputs["Alpha"]
    if channel == 'LUM':
        bw = nt.nodes.new('ShaderNodeRGBToBW')
        bw.name = tag + "灰度"
        bw.location = loc
        nt.links.new(tex.outputs["Color"], bw.inputs["Color"])
        return bw.outputs["Val"]
    sep = nt.nodes.new('ShaderNodeSeparateColor')
    sep.name = tag + "分离"
    sep.location = loc
    nt.links.new(tex.outputs["Color"], sep.inputs["Color"])
    idx = {'R': 0, 'G': 1, 'B': 2}[channel]
    return sep.outputs[idx]


def build_mask_chain(nt, tag, src_sock, threshold, softness, invert, loc):
    """通用遮罩整形: 阈值 + 过渡宽度 + 可选反相 → 0..1 损伤强度。
    用 MapRange 而非 ColorRamp —— 阈值和宽度可由属性直接驱动, 便于即时同步。"""
    rng = nt.nodes.new('ShaderNodeMapRange')
    rng.name = tag + "阈值"
    rng.clamp = True
    rng.location = loc
    w = max(0.005, softness) * 0.5
    lo = max(0.0, min(0.995, threshold - w))
    hi = max(lo + 0.005, min(1.0, threshold + w))
    if invert:
        lo, hi = hi, lo
    rng.inputs["From Min"].default_value = lo
    rng.inputs["From Max"].default_value = hi
    nt.links.new(src_sock, rng.inputs[0])
    return rng.outputs[0]


def sync_mask_chain(nt, tag, threshold, softness, invert):
    """把阈值/宽度/反相推进已建的 MapRange —— 拖动即时生效。"""
    rng = nt.nodes.get(tag + "阈值")
    if rng is None:
        return False
    w = max(0.005, softness) * 0.5
    lo = max(0.0, min(0.995, threshold - w))
    hi = max(lo + 0.005, min(1.0, threshold + w))
    if invert:
        lo, hi = hi, lo
    rng.inputs["From Min"].default_value = lo
    rng.inputs["From Max"].default_value = hi
    return True


def uv_name_for_space(decal, space):
    """按 UV 空间选层名: 贴花自身UV 或 传递来的目标UV。"""
    if decal is None or not decal.data.uv_layers:
        return ""
    if space == 'TARGET':
        lay = decal.data.uv_layers.get(UV_XFER)
        if lay is not None:
            return UV_XFER
    for lay in decal.data.uv_layers:
        if lay.name != UV_XFER:
            return lay.name
    return decal.data.uv_layers[0].name


def _mapping_values(mat, slot):
    prefix = "sd_%s_map_" % slot.lower()
    location = getattr(mat, prefix + "location", (0.0, 0.0))
    rotation = getattr(mat, prefix + "rotation", 0.0)
    size = getattr(mat, prefix + "scale", (1.0, 1.0))
    return location, rotation, size


def _set_mapping_node(node, location, rotation, size):
    if node is None:
        return False
    sx = max(0.001, float(size[0]))
    sy = max(0.001, float(size[1]))
    node.inputs["Location"].default_value = (location[0], location[1], 0.0)
    node.inputs["Rotation"].default_value = (0.0, 0.0, rotation)
    # 面板参数表示图案尺寸；节点 Scale 方向相反，因此取倒数。
    node.inputs["Scale"].default_value = (1.0 / sx, 1.0 / sy, 1.0)
    return True


def sync_mapping(mat, tag, slot):
    if mat is None or not mat.use_nodes:
        return False
    return _set_mapping_node(mat.node_tree.nodes.get(tag + "映射"),
                             *_mapping_values(mat, slot))


def make_uv_tex(nt, tag, image, uvname, loc, non_color=False,
                mapping=((0.0, 0.0), 0.0, (1.0, 1.0))):
    """建 UVMap → Mapping → ImageTexture，返回纹理节点。"""
    tex = nt.nodes.new('ShaderNodeTexImage')
    tex.name = tag + "贴图"
    tex.image = image
    tex.location = loc
    if non_color and image is not None:
        try:
            image.colorspace_settings.name = 'Non-Color'
        except (AttributeError, TypeError):
            pass
    if uvname:
        uvn = nt.nodes.new('ShaderNodeUVMap')
        uvn.name = tag + "UV"
        uvn.uv_map = uvname
        uvn.location = (loc[0] - 400.0, loc[1] - 120.0)
        mapn = nt.nodes.new('ShaderNodeMapping')
        mapn.name = tag + "映射"
        mapn.label = "位置 · 旋转 · 大小"
        mapn.location = (loc[0] - 200.0, loc[1] - 120.0)
        _set_mapping_node(mapn, *mapping)
        nt.links.new(uvn.outputs["UV"], mapn.inputs["Vector"])
        nt.links.new(mapn.outputs["Vector"], tex.inputs["Vector"])
    return tex


def make_object_tex(nt, tag, image, target, loc, non_color=False,
                    mapping=((0.0, 0.0), 0.0, (1.0, 1.0)), blend=0.25):
    """建 TexCoord(目标物体) → Mapping → 盒状投影贴图。

    与 UV 路线的关键区别: 坐标取自目标物体的局部空间, 与贴花自身携带的
    那层传递UV无关。阵列/镜像出来的复制体会原样继承UV层, 走UV路线时
    每个复制体都采到磨损场的同一处, 表现为一模一样的磨损纹路; 走物体
    坐标则各自落在不同位置。同时也不再依赖目标UV的质量。
    """
    tex = nt.nodes.new('ShaderNodeTexImage')
    tex.name = tag + "贴图"
    tex.image = image
    tex.location = loc
    tex.projection = 'BOX'
    tex.projection_blend = max(0.0, min(1.0, blend))
    tex.extension = 'REPEAT'
    if non_color and image is not None:
        try:
            image.colorspace_settings.name = 'Non-Color'
        except (AttributeError, TypeError):
            pass
    co = nt.nodes.new('ShaderNodeTexCoord')
    co.name = tag + "坐标"
    co.label = "目标物体坐标"
    co.object = target
    co.location = (loc[0] - 400.0, loc[1] - 120.0)
    mapn = nt.nodes.new('ShaderNodeMapping')
    mapn.name = tag + "映射"
    mapn.label = "位置 · 旋转 · 大小"
    mapn.location = (loc[0] - 200.0, loc[1] - 120.0)
    (lx, ly), rot, (sx, sy) = mapping
    mapn.inputs["Location"].default_value = (lx, ly, 0.0)
    mapn.inputs["Rotation"].default_value = (0.0, 0.0, rot)
    # Z 轴取 XY 均值: 盒状投影的三个面才有一致的图案密度
    mapn.inputs["Scale"].default_value = (sx, sy, (sx + sy) * 0.5)
    nt.links.new(co.outputs["Object"], mapn.inputs["Vector"])
    nt.links.new(mapn.outputs["Vector"], tex.inputs["Vector"])
    return tex


# 目标几何边缘场：由 Geometry Nodes 在吸附后的贴花几何上动态生成。
EDGE_FIELD_ATTR = "sd_edge_field"
EDGE_DISTANCE_ATTR = "sd_edge_distance"
EDGE_PRESENT_ATTR = "sd_edge_present"   # 恒1: 供着色器判断场是否真的存在
EDGE_FIELD_FACE_BUDGET = 20000          # 采样细分的输出面数上限
EDGE_FIELD_SCHEMA = 3


def _geometry_group_socket(group, name, in_out):
    if hasattr(group, "interface"):
        return group.interface.new_socket(
            name=name, in_out=in_out, socket_type='NodeSocketGeometry')
    collection = group.inputs if in_out == 'INPUT' else group.outputs
    return collection.new('NodeSocketGeometry', name)


def _compat_node_socket(sockets, *names):
    """Return the first socket name exposed by the running Blender version."""
    for name in names:
        socket = sockets.get(name)
        if socket is not None:
            return socket
    raise KeyError("missing compatible node socket: %s" % ", ".join(names))


def _edge_field_sampling_levels(decal, width):
    """Return bounded refinement levels for a possibly sparse decal.

    A POINT attribute is interpolated by the shader.  On a baked/decimated
    decal, a large polygon can have every corner on a target hard edge, which
    turns the whole polygon into an edge mask.  Three extra levels are enough
    to create interior samples while keeping the modifier bounded to at most
    64 output faces per incoming face.  Existing managed subdivision is
    accounted for because it runs before the edge-field modifier.
    """
    if decal is None or decal.type != 'MESH' or not decal.data.edges:
        return 0
    basis = decal.matrix_world.to_3x3()
    vertices = decal.data.vertices
    longest = max(
        (basis @ (vertices[edge.vertices[1]].co
                  - vertices[edge.vertices[0]].co)).length
        for edge in decal.data.edges
    )
    for modifier in decal.modifiers:
        if modifier.name == MOD_EDGE_FIELD:
            break
        if (modifier.type == 'SUBSURF' and modifier.show_viewport
                and modifier.levels > 0):
            longest /= 2 ** int(modifier.levels)
    safe_width = max(0.00001, float(width))
    ratio = longest / safe_width
    levels = max(1, min(3, int(math.ceil(math.log2(max(1.0, ratio))))))
    # 面数预算: 每级细分把面数×4, 3级即64倍。已减面或已固化的贴花再被
    # 放大64倍会抵消减面收益并拖慢求值, 故按输出面数上限回退级别。
    faces = max(1, len(decal.data.polygons))
    while levels > 1 and faces * (4 ** levels) > EDGE_FIELD_FACE_BUDGET:
        levels -= 1
    return levels


def ensure_geometry_edge_field(decal, target, min_angle, width):
    """在贴花上建立动态目标边缘场。

    目标网格的 Edge Angle 大于阈值时才进入候选边集合；贴花在完成细分和
    吸附后计算到这些边的真实空间距离，并把 0..width 映射为 1..0。
    因而平面内部拓扑边为0，硬折线为1，离开折线后迅速归零。
    """
    if (decal is None or decal.type != 'MESH'
            or target is None or target.type != 'MESH'):
        return None
    if not decal.get(KEY_DECAL_ID):
        decal[KEY_DECAL_ID] = _new_uid()
    group_name = "SD_边缘场_%s" % decal[KEY_DECAL_ID]
    group = bpy.data.node_groups.get(group_name)
    if group is None:
        group = bpy.data.node_groups.new(group_name, 'GeometryNodeTree')
    else:
        group.nodes.clear()
        try:
            group.interface.clear()
        except (AttributeError, RuntimeError):
            pass
    try:
        group.is_modifier = True
    except AttributeError:
        pass
    _geometry_group_socket(group, "Geometry", 'INPUT')
    _geometry_group_socket(group, "Geometry", 'OUTPUT')
    nodes = group.nodes
    links = group.links.new
    group_in = nodes.new('NodeGroupInput')
    group_in.location = (-900.0, 240.0)
    group_out = nodes.new('NodeGroupOutput')
    group_out.location = (680.0, 240.0)

    obj_info = nodes.new('GeometryNodeObjectInfo')
    obj_info.name = "目标表面"
    obj_info.label = "目标表面"
    obj_info.location = (-900.0, -160.0)
    obj_info.transform_space = 'RELATIVE'
    obj_info.inputs["Object"].default_value = target

    angle = nodes.new('GeometryNodeInputMeshEdgeAngle')
    angle.name = "边角角度"
    angle.location = (-700.0, -420.0)
    compare = nodes.new('ShaderNodeMath')
    compare.operation = 'GREATER_THAN'
    compare.name = "硬边曲率阈值"
    compare.location = (-500.0, -420.0)
    compare.inputs[1].default_value = max(0.0, float(min_angle))
    links(angle.outputs["Unsigned Angle"], compare.inputs[0])

    separate = nodes.new('GeometryNodeSeparateGeometry')
    separate.domain = 'EDGE'
    separate.name = "筛选硬边与曲率边"
    separate.location = (-300.0, -160.0)
    links(obj_info.outputs["Geometry"], separate.inputs["Geometry"])
    links(compare.outputs[0], separate.inputs["Selection"])

    domain_size = nodes.new('GeometryNodeAttributeDomainSize')
    domain_size.component = 'MESH'
    domain_size.name = "候选边数量"
    domain_size.location = (-80.0, -360.0)
    links(separate.outputs["Selection"], domain_size.inputs["Geometry"])
    has_edges = nodes.new('ShaderNodeMath')
    has_edges.operation = 'GREATER_THAN'
    has_edges.name = "存在候选边"
    has_edges.location = (140.0, -360.0)
    has_edges.inputs[1].default_value = 0.0
    links(domain_size.outputs["Edge Count"], has_edges.inputs[0])

    position = nodes.new('GeometryNodeInputPosition')
    position.location = (-300.0, -520.0)
    proximity = nodes.new('GeometryNodeProximity')
    proximity.target_element = 'EDGES'
    proximity.name = "到目标边缘的距离"
    proximity.location = (-80.0, -160.0)
    # Geometry Proximity renamed both inputs after Blender 4.0.x:
    #   4.0.x: Target / Source Position
    #   5.x:   Geometry / Sample Position
    # Geometry Proximity works in the modifier object's local coordinates.
    # Convert both branches to scaled decal space so the DISTANCE property is
    # measured in world metres even when a decal keeps non-applied scale.
    world_scale = tuple(max(1.0e-8, abs(value))
                        for value in decal.matrix_world.to_scale())
    target_metric = nodes.new('GeometryNodeTransform')
    target_metric.name = "目标边缘米制空间"
    target_metric.location = (-80.0, 40.0)
    target_metric.inputs["Scale"].default_value = world_scale
    links(separate.outputs["Selection"], target_metric.inputs["Geometry"])
    source_metric = nodes.new('ShaderNodeVectorMath')
    source_metric.operation = 'MULTIPLY'
    source_metric.name = "采样位置米制空间"
    source_metric.location = (-280.0, -600.0)
    source_metric.inputs[1].default_value = world_scale
    links(position.outputs["Position"], source_metric.inputs[0])
    links(target_metric.outputs["Geometry"], _compat_node_socket(
        proximity.inputs, "Geometry", "Target"))
    links(source_metric.outputs["Vector"], _compat_node_socket(
        proximity.inputs, "Sample Position", "Source Position"))

    falloff = nodes.new('ShaderNodeMapRange')
    falloff.name = "边缘宽度衰减"
    falloff.location = (140.0, -160.0)
    falloff.clamp = True
    try:
        falloff.interpolation_type = 'SMOOTHSTEP'
    except (AttributeError, TypeError):
        pass
    falloff.inputs["From Min"].default_value = 0.0
    falloff.inputs["From Max"].default_value = max(0.00001, float(width))
    falloff.inputs["To Min"].default_value = 1.0
    falloff.inputs["To Max"].default_value = 0.0
    links(proximity.outputs["Distance"], falloff.inputs["Value"])

    valid = nodes.new('ShaderNodeMath')
    valid.operation = 'MULTIPLY'
    valid.name = "有效边缘"
    valid.location = (340.0, -160.0)
    links(falloff.outputs["Result"], valid.inputs[0])
    # 4.0.x 没有 Proximity.Is Valid；以候选边数量作跨版本有效性门控。
    # 空集合时恒为0，避免平面内部再次被误判成“整片边缘”。
    links(has_edges.outputs[0], valid.inputs[1])

    # The field must have interior samples before it reaches the material.
    # Blender 4.0.2+ Subdivide Mesh has no Selection socket, so use one bounded
    # refinement and store raw distance as well as the falloff.  The shader
    # remaps interpolated distance, preventing sparse corner values from
    # spreading a binary mask across a whole polygon.
    sample_geometry = group_in.outputs["Geometry"]
    levels = _edge_field_sampling_levels(decal, width)
    if levels > 0:
        subdivide = nodes.new('GeometryNodeSubdivideMesh')
        subdivide.name = "边缘场采样细分"
        subdivide.location = (-80.0, 520.0)
        subdivide.inputs["Level"].default_value = levels
        links(sample_geometry, subdivide.inputs["Mesh"])
        sample_geometry = subdivide.outputs["Mesh"]

    no_edges = nodes.new('ShaderNodeMath')
    no_edges.operation = 'SUBTRACT'
    no_edges.name = "无候选边"
    no_edges.location = (140.0, -500.0)
    no_edges.inputs[0].default_value = 1.0
    links(has_edges.outputs[0], no_edges.inputs[1])
    invalid_offset = nodes.new('ShaderNodeMath')
    invalid_offset.operation = 'MULTIPLY'
    invalid_offset.name = "无边距离门控"
    invalid_offset.location = (300.0, -500.0)
    invalid_offset.inputs[1].default_value = 1000000.0
    links(no_edges.outputs[0], invalid_offset.inputs[0])
    safe_distance = nodes.new('ShaderNodeMath')
    safe_distance.operation = 'ADD'
    safe_distance.name = "有效边缘距离"
    safe_distance.location = (460.0, -420.0)
    links(proximity.outputs["Distance"], safe_distance.inputs[0])
    links(invalid_offset.outputs[0], safe_distance.inputs[1])

    store_distance = nodes.new('GeometryNodeStoreNamedAttribute')
    store_distance.data_type = 'FLOAT'
    store_distance.domain = 'POINT'
    store_distance.name = "写入边缘距离"
    store_distance.location = (300.0, 360.0)
    store_distance.inputs["Name"].default_value = EDGE_DISTANCE_ATTR
    links(sample_geometry, store_distance.inputs["Geometry"])
    links(safe_distance.outputs[0], store_distance.inputs["Value"])

    store_present = nodes.new('GeometryNodeStoreNamedAttribute')
    store_present.data_type = 'FLOAT'
    store_present.domain = 'POINT'
    store_present.name = "写入场存在标记"
    store_present.location = (300.0, 520.0)
    store_present.inputs["Name"].default_value = EDGE_PRESENT_ATTR
    store_present.inputs["Value"].default_value = 1.0
    links(store_distance.outputs["Geometry"], store_present.inputs["Geometry"])

    store_attr = nodes.new('GeometryNodeStoreNamedAttribute')
    store_attr.data_type = 'FLOAT'
    store_attr.domain = 'POINT'
    store_attr.name = "写入边缘场"
    store_attr.location = (480.0, 240.0)
    store_attr.inputs["Name"].default_value = EDGE_FIELD_ATTR
    links(store_present.outputs["Geometry"], store_attr.inputs["Geometry"])
    links(valid.outputs[0], store_attr.inputs["Value"])
    links(store_attr.outputs["Geometry"], group_out.inputs["Geometry"])

    modifier = decal.modifiers.get(MOD_EDGE_FIELD)
    if modifier is None:
        modifier = decal.modifiers.new(MOD_EDGE_FIELD, 'NODES')
    modifier.node_group = group
    # 属性必须在细分/吸附后生成，但应先于实体化，保证正反面读到同一场。
    current = list(decal.modifiers).index(modifier)
    shrink = decal.modifiers.get(MOD_SHRINK)
    desired = (list(decal.modifiers).index(shrink) + 1
               if shrink is not None else current)
    solid = decal.modifiers.get(MOD_SOLID)
    if solid is not None:
        desired = min(desired, list(decal.modifiers).index(solid))
    if current != desired:
        decal.modifiers.move(current, desired)
    group[KEY_ROLE] = "geometry_edge_field"
    group[KEY_SCHEMA] = EDGE_FIELD_SCHEMA
    return modifier


def remove_geometry_edge_field(decal):
    if decal is None:
        return False
    modifier = decal.modifiers.get(MOD_EDGE_FIELD)
    if modifier is None:
        return False
    group = modifier.node_group
    decal.modifiers.remove(modifier)
    if group is not None and group.users == 0:
        bpy.data.node_groups.remove(group)
    return True


def geometry_edge_socket(nt, tag, loc, width):
    """读取几何边缘场。

    失效方向必须是"缺失即无磨损": Attribute 节点在属性不存在时返回 0, 而
    距离0本应表示"正好在硬边上"(磨损最强)。若直接用距离, 属性一旦缺失
    (烘焙包裹后、减面后、修改器尚未求值、几何节点在旧版静默失败)整片贴花
    就会被判为满值磨损。因此再读一个恒为1的存在标记做闸门。
    """
    attr = nt.nodes.new('ShaderNodeAttribute')
    attr.name = tag + "几何距离"
    attr.label = "到目标硬边/曲率边的距离"
    attr.attribute_name = EDGE_DISTANCE_ATTR
    attr.location = loc
    falloff = nt.nodes.new('ShaderNodeMapRange')
    falloff.name = tag + "宽度"
    falloff.label = "米制边缘宽度"
    falloff.location = (loc[0] + 200.0, loc[1])
    falloff.clamp = True
    try:
        falloff.interpolation_type = 'SMOOTHSTEP'
    except (AttributeError, TypeError):
        pass
    falloff.inputs["From Min"].default_value = max(0.0001, float(width))
    falloff.inputs["From Max"].default_value = 0.0
    falloff.inputs["To Min"].default_value = 0.0
    falloff.inputs["To Max"].default_value = 1.0
    nt.links.new(attr.outputs["Fac"], falloff.inputs["Value"])

    present = nt.nodes.new('ShaderNodeAttribute')
    present.name = tag + "场存在"
    present.label = "边缘场是否已生成"
    present.attribute_name = EDGE_PRESENT_ATTR
    present.location = (loc[0], loc[1] - 180.0)
    gate = nt.nodes.new('ShaderNodeMath')
    gate.operation = 'MULTIPLY'
    gate.name = tag + "场闸门"
    gate.label = "缺失即无磨损"
    gate.location = (loc[0] + 380.0, loc[1])
    nt.links.new(falloff.outputs["Result"], gate.inputs[0])
    nt.links.new(present.outputs["Fac"], gate.inputs[1])
    return gate.outputs[0]


# ---- 阶段C: 表面桥接 —— 唯一连接 Principled 的节点 ----
BRIDGE_GROUP = "SD_表面桥接_v6"
BRIDGE_VER = 10
KEY_ROLE = "sd_role"
KEY_SCHEMA = "sd_schema_version"
BRIDGE_NODE = "SD_表面桥接"
KEY_BRIDGE_VER = "sd_bridge_version"
SURFACE_MODE_ITEMS = [
    ('STICKER', "贴纸", "贴花材质占主导, 目标通道仅用于匹配"),
    ('PRINTED', "印刷/信息", "目标材质作底层, 贴花当作油墨/喷漆层"),
]


def _bi_new(g, name, in_out, stype):
    if hasattr(g, "interface"):
        return g.interface.new_socket(name=name, in_out=in_out,
                                     socket_type=stype)
    coll = g.inputs if in_out == 'INPUT' else g.outputs
    return coll.new(stype, name)


BRIDGE_INPUTS = (
    # 目标表面
    ("Target Color", 'NodeSocketColor', (0.5, 0.5, 0.5, 1.0)),
    ("Target Roughness", 'NodeSocketFloat', 0.5),
    ("Target Normal", 'NodeSocketVector', (0.0, 0.0, 1.0)),
    ("Target Normal Weight", 'NodeSocketFloat', 0.0),
    # 贴花图案
    ("Artwork Color", 'NodeSocketColor', (0.8, 0.8, 0.8, 1.0)),
    ("Artwork Alpha", 'NodeSocketFloat', 1.0),
    ("Artwork Roughness", 'NodeSocketFloat', 0.5),
    ("Artwork Normal", 'NodeSocketVector', (0.0, 0.0, 1.0)),
    ("Artwork Normal Weight", 'NodeSocketFloat', 0.0),
    # 损伤场: 普通磨损 / 边缘磨损 各自独立(方案§1.2)
    ("Wear Field", 'NodeSocketFloat', 0.0),
    ("Wear Weight", 'NodeSocketFloat', 1.0),
    ("Shared Wear Field", 'NodeSocketFloat', 0.0),
    ("Shared Wear Weight", 'NodeSocketFloat', 0.0),
    ("Edge Field", 'NodeSocketFloat', 0.0),
    ("Edge Weight", 'NodeSocketFloat', 0.0),
    # Cutout: 侵蚀范围控制"多少面积被完全移除", 不再是透明度乘数(§10.5)
    ("Cutout Range", 'NodeSocketFloat', 0.0),
    ("Cutout Hardness", 'NodeSocketFloat', 0.7),
    ("Cutout Feather", 'NodeSocketFloat', 0.08),
    # 残留污渍: 只作用于仍存在的碎片(§10.4), 默认关
    ("Residue Amount", 'NodeSocketFloat', 0.0),
    ("Residue Color", 'NodeSocketColor', (0.18, 0.16, 0.13, 1.0)),
    ("Residue Roughness", 'NodeSocketFloat', 0.0),
    # 高级: 半透明淡化, 默认关(§10.5)
    ("Fade Amount", 'NodeSocketFloat', 0.0),
    # 表面模式
    ("Ink Strength", 'NodeSocketFloat', 1.0),
    ("Surface Mode", 'NodeSocketFloat', 0.0),
    # 分槽预览: 0最终 / 1局部磨损 / 2共享磨损 / 3边缘 / 4法线
    ("Preview Mode", 'NodeSocketFloat', 0.0),
)
BRIDGE_OUTPUTS = (
    ("Base Color", 'NodeSocketColor'),
    ("Roughness", 'NodeSocketFloat'),
    ("Alpha", 'NodeSocketFloat'),
    ("Normal", 'NodeSocketVector'),
    ("Remaining", 'NodeSocketFloat'),       # 1-Cutout: 供法线/高度门控
    ("Damage Field", 'NodeSocketFloat'),    # 预览: 软损伤场
    ("Cutout Mask", 'NodeSocketFloat'),     # 预览: 完全移除的区域
)

# 节点组对用户只显示中文；英文键仅作为源码内部稳定标识和旧版迁移入口。
BRIDGE_SOCKET_CN = {
    "Target Color": "目标颜色",
    "Target Roughness": "目标粗糙度",
    "Target Normal": "目标法线",
    "Target Normal Weight": "目标法线强度",
    "Artwork Color": "贴花颜色",
    "Artwork Alpha": "贴花透明度",
    "Artwork Roughness": "贴花粗糙度",
    "Artwork Normal": "贴花法线",
    "Artwork Normal Weight": "贴花法线强度",
    "Wear Field": "磨损场",
    "Wear Weight": "磨损强度",
    "Shared Wear Field": "共享磨损场",
    "Shared Wear Weight": "共享磨损强度",
    "Edge Field": "边缘磨损场",
    "Edge Weight": "边缘磨损强度",
    "Residue Amount": "残留强度",
    "Residue Color": "残留颜色",
    "Residue Roughness": "残留粗糙度",
    "Cutout Range": "侵蚀范围",
    "Cutout Hardness": "缺口硬度",
    "Cutout Feather": "缺口过渡",
    "Fade Amount": "淡化强度",
    "Ink Strength": "油墨强度",
    "Surface Mode": "表面模式",
    "Preview Mode": "预览模式",
    "Base Color": "基础颜色",
    "Roughness": "粗糙度",
    "Alpha": "透明度",
    "Normal": "法线",
    "Remaining": "剩余遮罩",
    "Damage Field": "总损伤场",
    "Cutout Mask": "镂空遮罩",
}


def bridge_in(node, stable_name):
    """按稳定英文键访问已中文化的 Bridge 输入，并兼容旧组。"""
    if node is None:
        return None
    socket = node.inputs.get(BRIDGE_SOCKET_CN.get(stable_name, stable_name))
    return socket if socket is not None else node.inputs.get(stable_name)


def bridge_out(node, stable_name):
    """按稳定英文键访问已中文化的 Bridge 输出，并兼容旧组。"""
    if node is None:
        return None
    socket = node.outputs.get(BRIDGE_SOCKET_CN.get(stable_name, stable_name))
    return socket if socket is not None else node.outputs.get(stable_name)


def ensure_bridge_group():
    """建/复用整合节点组。核心是把"材料缺失"与"残留污渍"分开:

      Damage Field = 1 - (1-W*Ww) * (1-E*Ew)        软损伤场(两路并集, 不过曝)
      t            = 1 - Cutout Range               阈值随范围下移
      f            = Feather*0.5*(1-Hardness)+eps   硬度收窄过渡带
      Cutout       = smoothstep(t, t+2f, Damage)    完全移除的区域
      Remaining    = 1 - Cutout
      Alpha        = Artwork Alpha * Remaining * (1 - Fade*Damage)
      Residue      = Damage * Remaining             只作用于仍存在的碎片

    Cutout=1 处 Alpha 归零, Residue 也归零 → 颜色/粗糙度/法线贡献全部为0,
    直接显示目标表面。侵蚀强度因此控制的是"面积", 而不是把整片贴花变半透明
    (旧版 Alpha = Artwork * (1 - Mask*0.35) 最强处仍留 65%, 就是黑点的来源)。
    """
    g = bpy.data.node_groups.get(BRIDGE_GROUP)
    if g is not None and int(g.get(KEY_SCHEMA, 0)) >= BRIDGE_VER:
        return g
    if g is not None:
        # 不能原地清空旧组：那会瞬间破坏所有使用旧组的材质实例。
        # 先保留并改名，ensure_bridge() 再逐材质迁移输入与连线。
        old_schema = int(g.get(KEY_SCHEMA, g.get("sd_ver", 0)))
        g.name = "%s_legacy_schema%d" % (BRIDGE_GROUP, old_schema)
    g = bpy.data.node_groups.new(BRIDGE_GROUP, 'ShaderNodeTree')
    for nm, st, dv in BRIDGE_INPUTS:
        s = _bi_new(g, nm, 'INPUT', st)
        try:
            s.default_value = dv
        except (AttributeError, TypeError, ValueError):
            pass
    for nm, st in BRIDGE_OUTPUTS:
        _bi_new(g, nm, 'OUTPUT', st)

    nt = g.nodes
    lk = g.links.new
    gi = nt.new('NodeGroupInput')
    gi.name = "输入"
    gi.location = (-1500.0, 0.0)
    go = nt.new('NodeGroupOutput')
    go.name = "输出"
    go.location = (1100.0, 0.0)

    def math(op, x, y, a=None, b=None, name="", clamp=False):
        n = nt.new('ShaderNodeMath')
        n.operation = op
        n.location = (x, y)
        n.use_clamp = clamp
        if name:
            n.name = name
        if a is not None:
            n.inputs[0].default_value = a
        if b is not None:
            n.inputs[1].default_value = b
        return n

    # ---- 软损伤场: 局部磨损 + 共享磨损 + 几何边缘，三路加权并集 ----
    wf = math('MULTIPLY', -1240.0, 260.0, name="局部磨损加权")
    lk(gi.outputs["Wear Field"], wf.inputs[0])
    lk(gi.outputs["Wear Weight"], wf.inputs[1])
    wk = math('SUBTRACT', -1080.0, 260.0, a=1.0, name="局部磨损保留")
    lk(wf.outputs[0], wk.inputs[1])
    swf = math('MULTIPLY', -1240.0, 400.0, name="共享磨损加权")
    lk(gi.outputs["Shared Wear Field"], swf.inputs[0])
    lk(gi.outputs["Shared Wear Weight"], swf.inputs[1])
    swk = math('SUBTRACT', -1080.0, 400.0, a=1.0, name="共享磨损保留")
    lk(swf.outputs[0], swk.inputs[1])
    wear_keep = math('MULTIPLY', -920.0, 330.0, name="磨损合并保留")
    lk(wk.outputs[0], wear_keep.inputs[0])
    lk(swk.outputs[0], wear_keep.inputs[1])
    wear_damage = math('SUBTRACT', -760.0, 330.0, a=1.0,
                       name="磨损合并损伤")
    lk(wear_keep.outputs[0], wear_damage.inputs[1])
    ef = math('MULTIPLY', -1240.0, 100.0, name="边缘磨损加权")
    lk(gi.outputs["Edge Field"], ef.inputs[0])
    lk(gi.outputs["Edge Weight"], ef.inputs[1])
    ek = math('SUBTRACT', -1080.0, 120.0, a=1.0, name="边缘磨损保留")
    lk(ef.outputs[0], ek.inputs[1])
    keep = math('MULTIPLY', -760.0, 190.0, name="总损伤保留")
    lk(wear_keep.outputs[0], keep.inputs[0])
    lk(ek.outputs[0], keep.inputs[1])
    dmg = math('SUBTRACT', -600.0, 190.0, a=1.0, name="总损伤场")
    lk(keep.outputs[0], dmg.inputs[1])

    # ---- Cutout: 范围移阈值, 硬度收窄过渡带 ----
    thr = math('SUBTRACT', -760.0, 20.0, a=1.0, name="侵蚀阈值")
    lk(gi.outputs["Cutout Range"], thr.inputs[1])
    inv_h = math('SUBTRACT', -1080.0, -140.0, a=1.0, name="硬度反相")
    lk(gi.outputs["Cutout Hardness"], inv_h.inputs[1])
    half = math('MULTIPLY', -920.0, -140.0, b=0.5, name="半过渡")
    lk(gi.outputs["Cutout Feather"], half.inputs[0])
    fw = math('MULTIPLY', -760.0, -140.0, name="过渡宽度")
    lk(half.outputs[0], fw.inputs[0])
    lk(inv_h.outputs[0], fw.inputs[1])
    fw2 = math('ADD', -600.0, -140.0, b=0.002, name="最小过渡")
    lk(fw.outputs[0], fw2.inputs[0])
    # 单侧过渡保证公开端点严格成立：Range=0 时即使 Damage=1 也不切除；
    # Range=1 且 Damage=0 仍完整保留。旧版以阈值为中心，两个端点都会得到0.5。
    lo = thr
    double_f = math('MULTIPLY', -440.0, -200.0, b=2.0,
                    name="双倍过渡")
    lk(fw2.outputs[0], double_f.inputs[0])
    hi = math('ADD', -280.0, -200.0, name="侵蚀上限")
    lk(thr.outputs[0], hi.inputs[0])
    lk(double_f.outputs[0], hi.inputs[1])
    cut = nt.new('ShaderNodeMapRange')
    cut.name = "镂空遮罩"
    cut.location = (-100.0, 60.0)
    cut.clamp = True
    try:
        cut.interpolation_type = 'SMOOTHSTEP'
    except (AttributeError, TypeError):
        pass
    lk(dmg.outputs[0], cut.inputs[0])
    lk(lo.outputs[0], cut.inputs["From Min"])
    lk(hi.outputs[0], cut.inputs["From Max"])
    rem = math('SUBTRACT', 80.0, 60.0, a=1.0, name="剩余遮罩")
    lk(cut.outputs[0], rem.inputs[1])

    # ---- Alpha: 完全移除处必须为0; 淡化是可选项且默认关 ----
    fade = math('MULTIPLY', -260.0, -320.0, name="淡化量")
    lk(gi.outputs["Fade Amount"], fade.inputs[0])
    lk(dmg.outputs[0], fade.inputs[1])
    fk = math('SUBTRACT', -80.0, -320.0, a=1.0, name="淡化保留")
    lk(fade.outputs[0], fk.inputs[1])
    a1 = math('MULTIPLY', 100.0, -120.0, name="透明度保留")
    lk(gi.outputs["Artwork Alpha"], a1.inputs[0])
    lk(rem.outputs[0], a1.inputs[1])
    alpha = math('MULTIPLY', 260.0, -120.0, name="透明度输出", clamp=True)
    lk(a1.outputs[0], alpha.inputs[0])
    lk(fk.outputs[0], alpha.inputs[1])

    # ---- 残留响应: 仅作用于仍存在的碎片 ----
    res = math('MULTIPLY', 100.0, 220.0, name="残留场")
    lk(dmg.outputs[0], res.inputs[0])
    lk(rem.outputs[0], res.inputs[1])
    res_f = math('MULTIPLY', 260.0, 220.0, name="残留强度", clamp=True)
    lk(res.outputs[0], res_f.inputs[0])
    lk(gi.outputs["Residue Amount"], res_f.inputs[1])

    # ---- 颜色 ----
    ink = math('MULTIPLY', 100.0, 460.0, name="油墨覆盖")
    lk(alpha.outputs[0], ink.inputs[0])
    lk(gi.outputs["Ink Strength"], ink.inputs[1])
    printed = nt.new('ShaderNodeMix')
    printed.data_type = 'RGBA'
    printed.name = "印刷颜色"
    printed.location = (280.0, 460.0)
    pf, pa, pb, pout = mix_rgba_sockets(printed)
    lk(ink.outputs[0], pf)
    lk(gi.outputs["Target Color"], pa)
    lk(gi.outputs["Artwork Color"], pb)
    basec = nt.new('ShaderNodeMix')
    basec.data_type = 'RGBA'
    basec.name = "表面模式颜色"
    basec.location = (460.0, 460.0)
    bf, ba, bb, bout = mix_rgba_sockets(basec)
    lk(gi.outputs["Surface Mode"], bf)
    lk(gi.outputs["Artwork Color"], ba)
    lk(pout, bb)
    resmix = nt.new('ShaderNodeMix')
    resmix.data_type = 'RGBA'
    resmix.name = "残留颜色混合"
    resmix.location = (640.0, 400.0)
    rf, ra, rb, rout = mix_rgba_sockets(resmix)
    lk(res_f.outputs[0], rf)
    lk(bout, ra)
    lk(gi.outputs["Residue Color"], rb)

    # ---- 粗糙度 ----
    rbase = nt.new('ShaderNodeMix')
    rbase.data_type = 'FLOAT'
    rbase.name = "表面模式粗糙度"
    rbase.location = (460.0, -420.0)
    mf, ma, mb, mout = mix_float_sockets(rbase)
    lk(gi.outputs["Surface Mode"], mf)
    lk(gi.outputs["Artwork Roughness"], ma)
    lk(gi.outputs["Target Roughness"], mb)
    rr = math('MULTIPLY', 460.0, -560.0, name="残留粗糙度")
    lk(res_f.outputs[0], rr.inputs[0])
    lk(gi.outputs["Residue Roughness"], rr.inputs[1])
    radd = math('ADD', 640.0, -480.0, name="粗糙度输出", clamp=True)
    lk(mout, radd.inputs[0])
    lk(rr.outputs[0], radd.inputs[1])

    # ---- 法线：目标表面为底，贴花法线仅在仍存在的区域叠加 ----
    geom = nt.new('ShaderNodeNewGeometry')
    geom.name = "几何法线"
    geom.location = (100.0, -760.0)
    target_n = nt.new('ShaderNodeMix')
    target_n.data_type = 'VECTOR'
    target_n.name = "目标法线混合"
    target_n.location = (300.0, -760.0)
    tnf, tna, tnb, tnout = mix_vector_sockets(target_n)
    lk(gi.outputs["Target Normal Weight"], tnf)
    lk(geom.outputs["Normal"], tna)
    lk(gi.outputs["Target Normal"], tnb)
    art_nf = math('MULTIPLY', 300.0, -920.0, name="贴花法线强度")
    lk(gi.outputs["Artwork Normal Weight"], art_nf.inputs[0])
    lk(rem.outputs[0], art_nf.inputs[1])
    artwork_n = nt.new('ShaderNodeMix')
    artwork_n.data_type = 'VECTOR'
    artwork_n.name = "贴花法线混合"
    artwork_n.location = (500.0, -760.0)
    anf, ana, anb, anout = mix_vector_sockets(artwork_n)
    lk(art_nf.outputs[0], anf)
    lk(tnout, ana)
    lk(gi.outputs["Artwork Normal"], anb)
    normal_out = nt.new('ShaderNodeVectorMath')
    normal_out.operation = 'NORMALIZE'
    normal_out.name = "法线输出"
    normal_out.location = (700.0, -760.0)
    lk(anout, normal_out.inputs[0])

    # ---- 分槽预览：按钮分散在各槽，计算留在组内且不插临时输出节点 ----
    def compare_mode(value, x, y, name):
        n = math('COMPARE', x, y, name=name)
        n.inputs[1].default_value = value
        n.inputs[2].default_value = 0.1
        lk(gi.outputs["Preview Mode"], n.inputs[0])
        return n

    wear_preview = nt.new('ShaderNodeMix')
    wear_preview.data_type = 'RGBA'
    wear_preview.name = "预览局部磨损"
    wear_preview.location = (800.0, 360.0)
    wpf, wpa, wpb, wpout = mix_rgba_sockets(wear_preview)
    lk(compare_mode(1.0, 600.0, 160.0, "局部磨损预览模式").outputs[0], wpf)
    lk(rout, wpa)
    lk(wf.outputs[0], wpb)
    shared_preview = nt.new('ShaderNodeMix')
    shared_preview.data_type = 'RGBA'
    shared_preview.name = "预览共享磨损"
    shared_preview.location = (980.0, 360.0)
    spf, spa, spb, spout = mix_rgba_sockets(shared_preview)
    lk(compare_mode(2.0, 780.0, 160.0, "共享磨损预览模式").outputs[0], spf)
    lk(wpout, spa)
    lk(swf.outputs[0], spb)
    edge_preview = nt.new('ShaderNodeMix')
    edge_preview.data_type = 'RGBA'
    edge_preview.name = "预览边缘磨损"
    edge_preview.location = (1160.0, 360.0)
    epf, epa, epb, epout = mix_rgba_sockets(edge_preview)
    lk(compare_mode(3.0, 960.0, 160.0, "边缘磨损预览模式").outputs[0], epf)
    lk(spout, epa)
    edge_color = nt.new('ShaderNodeMix')
    edge_color.data_type = 'RGBA'
    edge_color.name = "边缘预览着色"
    edge_color.location = (980.0, 520.0)
    ecf, eca, ecb, ecout = mix_rgba_sockets(edge_color)
    lk(ef.outputs[0], ecf)
    eca.default_value = (0.005, 0.005, 0.005, 1.0)
    ecb.default_value = (1.0, 0.08, 0.005, 1.0)
    lk(ecout, epb)
    nscale = nt.new('ShaderNodeVectorMath')
    nscale.operation = 'SCALE'
    nscale.name = "法线预览缩放"
    nscale.location = (740.0, -700.0)
    lk(normal_out.outputs[0], nscale.inputs[0])
    nscale.inputs["Scale"].default_value = 0.5
    nadd = nt.new('ShaderNodeVectorMath')
    nadd.operation = 'ADD'
    nadd.name = "法线预览偏置"
    nadd.location = (900.0, -700.0)
    lk(nscale.outputs[0], nadd.inputs[0])
    nadd.inputs[1].default_value = (0.5, 0.5, 0.5)
    normal_preview = nt.new('ShaderNodeMix')
    normal_preview.data_type = 'RGBA'
    normal_preview.name = "预览法线"
    normal_preview.location = (1340.0, 360.0)
    npf, npa, npb, npout = mix_rgba_sockets(normal_preview)
    lk(compare_mode(4.0, 1140.0, 160.0, "法线预览模式").outputs[0], npf)
    lk(epout, npa)
    lk(nadd.outputs[0], npb)
    preview_on = math('GREATER_THAN', 800.0, -160.0, b=0.5,
                      name="预览已启用")
    lk(gi.outputs["Preview Mode"], preview_on.inputs[0])
    alpha_preview = nt.new('ShaderNodeMix')
    alpha_preview.data_type = 'FLOAT'
    alpha_preview.name = "预览透明度"
    alpha_preview.location = (980.0, -80.0)
    paf, paa, pab, paout = mix_float_sockets(alpha_preview)
    lk(preview_on.outputs[0], paf)
    lk(alpha.outputs[0], paa)
    pab.default_value = 1.0

    lk(npout, go.inputs["Base Color"])
    lk(radd.outputs[0], go.inputs["Roughness"])
    lk(paout, go.inputs["Alpha"])
    lk(normal_out.outputs[0], go.inputs["Normal"])
    lk(rem.outputs[0], go.inputs["Remaining"])
    lk(dmg.outputs[0], go.inputs["Damage Field"])
    lk(cut.outputs[0], go.inputs["Cutout Mask"])
    # 所有外露接口最后统一改为中文。组内连线已按稳定键建立，不受重命名影响。
    for item in g.interface.items_tree:
        if item.item_type == 'SOCKET':
            item.name = BRIDGE_SOCKET_CN.get(item.name, item.name)
    g[KEY_SCHEMA] = BRIDGE_VER
    g[KEY_ROLE] = "surface_bridge"
    g["sd_ver"] = BRIDGE_VER
    return g



def _bridge_schema(node):
    if node is None or node.bl_idname != 'ShaderNodeGroup' or node.node_tree is None:
        return 0
    return int(node.get(KEY_SCHEMA,
                        node.node_tree.get(KEY_SCHEMA,
                                           node.node_tree.get("sd_ver", 0))))


def _is_current_bridge(node):
    if node is None or node.bl_idname != 'ShaderNodeGroup' or node.node_tree is None:
        return False
    role = node.get(KEY_ROLE, node.node_tree.get(KEY_ROLE, ""))
    return role == "surface_bridge" and _bridge_schema(node) >= BRIDGE_VER


def _is_legacy_bridge(node):
    if node is None or node.bl_idname != 'ShaderNodeGroup' or node.node_tree is None:
        return False
    if _is_current_bridge(node):
        return False
    tree_name = node.node_tree.name
    role = node.get(KEY_ROLE, node.node_tree.get(KEY_ROLE, ""))
    return (role == "surface_bridge"
            or tree_name.startswith("SD_SurfaceBridge")
            or tree_name.startswith("SD_表面桥接")
            or node.name in {"SD_Bridge", BRIDGE_NODE})


def _copy_socket_value_or_link(nt, source, destination):
    if source is None or destination is None:
        return False
    if source.links:
        nt.links.new(source.links[0].from_socket, destination)
    else:
        try:
            destination.default_value = source.default_value
        except (AttributeError, TypeError, ValueError):
            return False
    return True


def _connect_bridge_outputs(nt, node, principled):
    for out, sock in (("Base Color", "Base Color"),
                      ("Roughness", "Roughness"),
                      ("Alpha", "Alpha"),
                      ("Normal", "Normal")):
        source = bridge_out(node, out)
        destination = principled.inputs.get(sock)
        if source is not None and destination is not None:
            nt.links.new(source, destination)


def get_bridge(mat):
    """返回当前 schema 的表面桥接；旧组由 ensure_bridge 迁移。"""
    if mat is None or not mat.use_nodes:
        return None
    return next((n for n in mat.node_tree.nodes if _is_current_bridge(n)), None)


def ensure_bridge(mat):
    """建立/迁移表面桥接，并独占 Principled 的四个受管通道。

    旧 v1/v2 节点的输入被逐项迁入新组，旧节点随后删除；绝不把旧 Bridge
    的输出当成 Artwork 再包一层，因此 4.2/4.6 文件可继续编辑而不会双重计算。
    """
    if mat is None or not mat.use_nodes:
        return None
    nt = mat.node_tree
    b = _find_node(nt, 'ShaderNodeBsdfPrincipled')
    if b is None:
        return None
    node = get_bridge(mat)
    if node is not None:
        _connect_bridge_outputs(nt, node, b)
        return node

    # 先升级组定义，旧 v2 组会被安全改名，但所有实例仍保持完整。
    g = ensure_bridge_group()
    legacy = [n for n in nt.nodes if _is_legacy_bridge(n)]
    # 优先迁移真正接到 Principled 的那个旧实例。
    legacy.sort(key=lambda n: sum(
        1 for out in n.outputs for link in out.links if link.to_node == b
    ), reverse=True)

    node = nt.nodes.new('ShaderNodeGroup')
    node.node_tree = g
    node.name = BRIDGE_NODE
    node.label = "表面匹配 · 磨损 · 边缘 · 法线"
    node[KEY_ROLE] = "surface_bridge"
    node[KEY_SCHEMA] = BRIDGE_VER
    node.location = (b.location.x - 360.0, b.location.y + 120.0)

    if legacy:
        old = legacy[0]
        mapping = {
            "Target Color": "Target Color",
            "Target Roughness": "Target Roughness",
            "Target Normal": "Target Normal",
            "Target Normal Weight": "Target Normal Weight",
            "Artwork Color": "Artwork Color",
            "Artwork Alpha": "Artwork Alpha",
            "Artwork Roughness": "Artwork Roughness",
            "Artwork Normal": "Artwork Normal",
            "Artwork Normal Weight": "Artwork Normal Weight",
            "Wear Field": "Wear Field",
            "Wear Mask": "Wear Field",
            "Wear Weight": "Wear Weight",
            "Wear Amount": "Wear Weight",
            "Shared Wear Field": "Shared Wear Field",
            "Shared Wear Weight": "Shared Wear Weight",
            "Edge Field": "Edge Field",
            "Edge Mask": "Edge Field",
            "Edge Weight": "Edge Weight",
            "Edge Amount": "Edge Weight",
            "Residue Color": "Residue Color",
            "Wear Color": "Residue Color",
            "Residue Amount": "Residue Amount",
            "Wear Color Amount": "Residue Amount",
            "Residue Roughness": "Residue Roughness",
            "Wear Roughness Delta": "Residue Roughness",
            "Cutout Range": "Cutout Range",
            "Cutout Hardness": "Cutout Hardness",
            "Cutout Feather": "Cutout Feather",
            "Fade Amount": "Fade Amount",
            "Ink Strength": "Ink Strength",
            "Surface Mode": "Surface Mode",
            "Preview Mode": "Preview Mode",
        }
        copied_destinations = set()
        for old_name, new_name in mapping.items():
            if new_name in copied_destinations:
                continue
            old_socket = old.inputs.get(old_name)
            if old_socket is None:
                old_socket = old.inputs.get(BRIDGE_SOCKET_CN.get(
                    old_name, old_name))
            if _copy_socket_value_or_link(nt, old_socket,
                                          bridge_in(node, new_name)):
                copied_destinations.add(new_name)
    else:
        for sock, inp in (("Base Color", "Artwork Color"),
                          ("Roughness", "Artwork Roughness"),
                          ("Alpha", "Artwork Alpha"),
                          ("Normal", "Artwork Normal")):
            source = b.inputs.get(sock)
            if _copy_socket_value_or_link(nt, source, bridge_in(node, inp)) \
                    and sock == "Normal" and source.links:
                bridge_in(node, "Artwork Normal Weight").default_value = 1.0

    _connect_bridge_outputs(nt, node, b)
    legacy_groups = {
        old.node_tree for old in legacy
        if old.node_tree is not None and old.node_tree is not g
    }
    for old in legacy:
        nt.nodes.remove(old)
    # 迁移完最后一个实例时清掉旧组，避免 .blend 中持续累积 v1/v2/_legacy_schema。
    # 外部链接库数据不可删除；仍有其他材质用户的组留到那些材质迁移时再清理。
    for old_group in legacy_groups:
        if (old_group.library is None and old_group.users == 0
                and (old_group.name.startswith("SD_SurfaceBridge")
                     or old_group.name.startswith("SD_表面桥接")
                     or "_legacy_schema" in old_group.name)):
            bpy.data.node_groups.remove(old_group)
    mat[KEY_BRIDGE_VER] = BRIDGE_VER
    return node


def _edge_slot_graph_current(mat):
    if mat is None or not mat.use_nodes:
        return False
    nodes = mat.node_tree.nodes
    distance = nodes.get(SLOT_EDGE + "几何距离")
    width = nodes.get(SLOT_EDGE + "宽度")
    return bool(
        distance is not None and distance.bl_idname == 'ShaderNodeAttribute'
        and distance.attribute_name == EDGE_DISTANCE_ATTR
        and width is not None and width.bl_idname == 'ShaderNodeMapRange'
    )


def _edge_field_dependency_current(decal):
    modifier = decal.modifiers.get(MOD_EDGE_FIELD)
    return bool(
        modifier is not None and modifier.node_group is not None
        and int(modifier.node_group.get(KEY_SCHEMA, 0)) >= EDGE_FIELD_SCHEMA
    )


@persistent
def _upgrade_loaded_bridges(_unused):
    """启用插件和打开文件时，静默把所有受管旧 Bridge 升级为全中文版本。"""
    # Blender 在扩展注册阶段会暂时用 _RestrictData 替换 bpy.data。
    # 这个阶段读取 materials 会直接令插件启用失败；load_post 之外的调用
    # 也必须防守，避免第三方脚本在受限上下文中触发迁移。
    materials = getattr(bpy.data, "materials", None)
    if materials is None:
        return 0
    migrated = 0
    upgraded_materials = set()
    for mat in tuple(materials):
        if mat is None or not mat.use_nodes:
            continue
        if any(_is_legacy_bridge(node) for node in mat.node_tree.nodes):
            if ensure_bridge(mat) is not None:
                migrated += 1
                upgraded_materials.add(mat)
    # v8/v9 temporarily replaced the target-edge field with a full-surface
    # texture / decal-outline mask.  The first geometry-field implementation
    # also stored a binary POINT value, which fills sparse baked polygons by
    # interpolation.  A Bridge can already be current while this edge chain is
    # stale, so inspect every active edge material and every object dependency.
    edge_upgrades = {
        mat for mat in upgraded_materials if edge_enabled(mat)
    }
    for mat in tuple(materials):
        if mat is None or not edge_enabled(mat):
            continue
        users = [
            obj for obj in bpy.data.objects
            if obj.type == 'MESH' and is_decal(obj)
            and any(slot.material == mat for slot in obj.material_slots)
        ]
        if (not _edge_slot_graph_current(mat)
                or any(not _edge_field_dependency_current(obj)
                       for obj in users)):
            edge_upgrades.add(mat)
    for mat in edge_upgrades:
        _autobuild_slot(mat, 'EDGE')
    # 共享磨损组: 修正空名与旧的非ASCII ID(下拉框曾把ID当显示名而出现乱码)
    try:
        migrated += repair_shared_wear_labels()
    except (AttributeError, RuntimeError):
        pass
    return migrated


def _deferred_upgrade_loaded_bridges():
    """等 Blender 退出受限注册阶段后再迁移当前文件中的 Bridge。"""
    if getattr(bpy.data, "materials", None) is None:
        return 0.1
    _upgrade_loaded_bridges(None)
    return None


def remove_bridge(mat):
    """撤掉 Bridge, 把 Artwork 来源直接接回 BSDF。"""
    node = get_bridge(mat)
    if node is None:
        return False
    nt = mat.node_tree
    b = _find_node(nt, 'ShaderNodeBsdfPrincipled')
    if b is not None:
        for inp, sock in (("Artwork Color", "Base Color"),
                          ("Artwork Roughness", "Roughness"),
                          ("Artwork Alpha", "Alpha"),
                          ("Artwork Normal", "Normal")):
            s = b.inputs.get(sock)
            src = bridge_in(node, inp)
            if s is None:
                continue
            if src.links:
                nt.links.new(src.links[0].from_socket, s)
            else:
                try:
                    s.default_value = src.default_value
                except (TypeError, ValueError):
                    pass
    nt.nodes.remove(node)
    if KEY_BRIDGE_VER in mat:
        del mat[KEY_BRIDGE_VER]
    return True


# ---- 三槽 → Bridge 的接线与同步 ----
SLOT_WEAR = "SDS_W_"
SLOT_SHARED = "SDS_SHARED_"
SLOT_EDGE = "SDS_E_"


def repair_shared_wear_labels(scene=None):
    """修正旧文件里的共享组: 空 label 补名, 非ASCII uid 迁移到可读ID。
    材质侧的绑定同步改写, 不会掉链。返回修正数量。"""
    scenes = (scene,) if scene is not None else tuple(bpy.data.scenes)
    fixed = 0
    for sc in scenes:
        groups = getattr(sc, "surfdecal_shared_wear_groups", None)
        if not groups:
            continue
        for i, group in enumerate(groups, 1):
            want = "共享贴花 %d" % i
            # 旧文件里 label 可能为空, 或是把内部ID当成了名字
            if (not group.label.strip()
                    or group.label.strip() == group.uid
                    or not group.label.isascii() and group.uid
                    and group.label.strip() == group.uid.strip()):
                group.label = want
                fixed += 1
            old = group.uid
            if old and not old.isascii():
                new = "SWG%02d_%s" % (i, _new_uid()[:6])
                for mat in bpy.data.materials:
                    if getattr(mat, "sd_shared_wear_group", 'NONE') == old:
                        mat.sd_shared_wear_group = new
                group.uid = new
                fixed += 1
    return fixed


def find_shared_wear_group(uid, scene=None):
    if not uid or uid == 'NONE':
        return None
    scenes = (scene,) if scene is not None else bpy.data.scenes
    for candidate in scenes:
        groups = getattr(candidate, "surfdecal_shared_wear_groups", ())
        for group in groups:
            if group.uid == uid:
                return group
    return None


def _shared_group_items(self, context):
    items = [('NONE', "未选择", "不绑定共享磨损")]
    seen = set()
    active_scene = getattr(context, "scene", None)
    scenes = (active_scene,) if active_scene is not None else bpy.data.scenes
    for scene in scenes:
        for group in getattr(scene, "surfdecal_shared_wear_groups", ()):
            if group.uid and group.uid not in seen:
                seen.add(group.uid)
                # 显示名只用 label; label 为空时给一个可读回退, 绝不把
                # uid 当显示名(那正是"Ozmü"这类乱码的来源)。
                name = group.label.strip() or "共享贴花 %d" % (len(items))
                items.append((group.uid, name,
                              "同一组贴花共用一张磨损贴图"))
    return items


def clear_shared_wear_slot(mat):
    changed = clear_slot(mat, SLOT_SHARED)
    bridge = get_bridge(mat)
    if bridge is not None:
        field = bridge_in(bridge, "Shared Wear Field")
        if field is not None and not field.links:
            field.default_value = 0.0
        weight = bridge_in(bridge, "Shared Wear Weight")
        if weight is not None:
            weight.default_value = 0.0
    return changed


def build_shared_wear_slot(decal, mat, group):
    """把 Scene 级共享资源实例化进材质；图像数据仍是同一个 datablock。"""
    bridge = ensure_bridge(mat)
    if bridge is None:
        return False, "无法建立 Bridge"
    clear_slot(mat, SLOT_SHARED)
    if group is None or group.image is None:
        clear_shared_wear_slot(mat)
        return False, "共享磨损组没有贴图"
    target = decal_target_of(bpy.context, decal) or decal.parent
    if target is not None and target.type == 'MESH' and uv_health(target)[0]:
        try:
            ensure_target_uv(decal, target, bpy.context)
        except (RuntimeError, AttributeError, ReferenceError):
            pass
    uvname = uv_name_for_space(decal, 'TARGET')
    nt = mat.node_tree
    bx = bridge.location.x - 880.0
    by = bridge.location.y - 700.0
    use_object = (getattr(group, "space", 'UV') == 'OBJECT'
                  and target is not None)
    if use_object:
        tex = make_object_tex(
            nt, SLOT_SHARED, group.image, target, (bx, by), non_color=True,
            mapping=(group.location, group.rotation, group.scale),
        )
    else:
        tex = make_uv_tex(
            nt, SLOT_SHARED, group.image, uvname, (bx, by), non_color=True,
            mapping=(group.location, group.rotation, group.scale),
        )
    source = _mask_channel_socket(nt, tex, group.channel, SLOT_SHARED,
                                  (bx + 240.0, by))
    field = build_mask_chain(nt, SLOT_SHARED, source, group.threshold,
                             group.softness, group.invert,
                             (bx + 420.0, by))
    nt.links.new(field, bridge_in(bridge, "Shared Wear Field"))
    bridge_in(bridge, "Shared Wear Weight").default_value = (
        mat.sd_shared_wear_weight if mat.sd_shared_wear_enabled else 0.0
    )
    layout_slot_nodes(mat.node_tree, get_bridge(mat), SLOT_SHARED, 'SHARED')
    return True, "共享磨损: %s (%s)" % (
        group.label.strip() or "共享贴花",
        "目标物体坐标" if use_object else "目标UV")


def _scene_materials(scene):
    """Unique materials used by objects in one Scene."""
    seen = set()
    for obj in scene.objects:
        for slot in obj.material_slots:
            mat = slot.material
            if mat is None or mat.as_pointer() in seen:
                continue
            seen.add(mat.as_pointer())
            yield mat


def _localize_shared_wear_materials(scene, uid):
    """Copy-on-write materials used by the same shared group outside Scene."""
    if scene is None:
        return 0
    decals = []
    for obj in scene.objects:
        if not is_decal(obj):
            continue
        if any(slot.material is not None
               and getattr(slot.material, "sd_shared_wear_group", 'NONE') == uid
               for slot in obj.material_slots):
            decals.append(obj)
    return split_shared_materials(decals, bpy.context) if decals else 0


def rebuild_shared_wear_group(uid, scene=None):
    group = find_shared_wear_group(uid, scene)
    if scene is not None:
        _localize_shared_wear_materials(scene, uid)
    rebuilt = 0
    seen = set()
    objects = scene.objects if scene is not None else bpy.data.objects
    for obj in objects:
        if not is_decal(obj):
            continue
        for slot in obj.material_slots:
            mat = slot.material
            if mat is None:
                continue
            if (getattr(mat, "sd_shared_wear_enabled", False)
                    and getattr(mat, "sd_shared_wear_group", 'NONE') == uid):
                _ensure_slot_object_dependency(obj, mat, 'SHARED')
                key = mat.as_pointer()
                if key in seen:
                    continue
                seen.add(key)
                if group is not None and group.image is not None:
                    rebuilt += int(build_shared_wear_slot(obj, mat, group)[0])
                else:
                    clear_shared_wear_slot(mat)
    return rebuilt


def sync_shared_wear_group(uid, scene=None):
    """增量同步共享组的连续参数，不删除、不新建节点。"""
    group = find_shared_wear_group(uid, scene)
    if group is None:
        return 0
    if scene is not None:
        _localize_shared_wear_materials(scene, uid)
    synced = 0
    materials = (_scene_materials(scene) if scene is not None
                 else tuple(bpy.data.materials))
    for mat in materials:
        if (mat is None or not mat.use_nodes
                or not getattr(mat, "sd_shared_wear_enabled", False)
                or getattr(mat, "sd_shared_wear_group", 'NONE') != uid):
            continue
        nt = mat.node_tree
        mapping = nt.nodes.get(SLOT_SHARED + "映射")
        mask = nt.nodes.get(SLOT_SHARED + "阈值")
        if mapping is None or mask is None:
            continue
        _set_mapping_node(mapping, group.location, group.rotation, group.scale)
        sync_mask_chain(nt, SLOT_SHARED, group.threshold,
                        group.softness, group.invert)
        synced += 1
    return synced


def _shared_material_update(self, context):
    try:
        uid = getattr(self, "sd_shared_wear_group", 'NONE')
        if not self.sd_shared_wear_enabled or uid == 'NONE':
            clear_shared_wear_slot(self)
            return
        scene = getattr(context, "scene", None)
        group = find_shared_wear_group(uid, scene)
        if group is None:
            clear_shared_wear_slot(self)
            return
        rebuild_shared_wear_group(uid, scene)
        sync_bridge(self)
    except (AttributeError, RuntimeError, ReferenceError):
        pass


def slot_nodes(mat, tag):
    if mat is None or not mat.use_nodes:
        return {}
    return {n.name: n for n in mat.node_tree.nodes if n.name.startswith(tag)}


def clear_slot(mat, tag):
    """删除某个槽的全部节点(其余槽与 Bridge 不受影响 —— 方案 §11 阶段B验收)。"""
    if mat is None or not mat.use_nodes:
        return False
    nt = mat.node_tree
    hit = [n for n in nt.nodes if n.name.startswith(tag)]
    if not hit:
        return False
    for n in hit:
        nt.nodes.remove(n)
    return True


def build_wear_slot(decal, mat):
    """磨损槽: 贴图/程序 → 通道 → 阈值 → Bridge.Wear Mask。"""
    node = ensure_bridge(mat)
    if node is None:
        return False, "无法建立 Bridge"
    clear_slot(mat, SLOT_WEAR)
    nt = mat.node_tree
    bx = node.location.x - 700.0
    by = node.location.y - 500.0
    img = mat.sd_wear_image
    if img is None:
        bridge_in(node, "Wear Weight").default_value = 0.0
        return False, "未指定磨损贴图"
    uvname = uv_name_for_space(decal, mat.sd_wear_uv_space)
    tex = make_uv_tex(nt, SLOT_WEAR, img, uvname, (bx, by),
                      non_color=True,
                      mapping=_mapping_values(mat, 'WEAR'))
    sock = _mask_channel_socket(nt, tex, mat.sd_wear_channel, SLOT_WEAR,
                                (bx + 240.0, by))
    out = build_mask_chain(nt, SLOT_WEAR, sock, mat.sd_wear_threshold,
                           mat.sd_wear_softness, mat.sd_wear_invert,
                           (bx + 420.0, by))
    nt.links.new(out, bridge_in(node, "Wear Field"))
    layout_slot_nodes(nt, node, SLOT_WEAR, 'WEAR')
    sync_bridge(mat)
    return True, "磨损槽已接入(%s)" % ("目标UV" if uvname == UV_XFER
                                     else "贴花UV")


def build_edge_slot(decal, mat):
    """边缘槽：用户贴图调制目标几何场。"""
    node = ensure_bridge(mat)
    if node is None:
        return False, "无法建立 Bridge"
    clear_slot(mat, SLOT_EDGE)
    nt = mat.node_tree
    bx = node.location.x - 700.0
    by = node.location.y - 900.0
    own = uv_name_for_space(decal, 'DECAL')     # 边缘固定用贴花自身UV
    img = mat.sd_edge_image
    if img is None:
        remove_geometry_edge_field(decal)
        return False, "未指定边缘贴图"
    target = decal_target_of(bpy.context, decal) or decal.parent
    geometry_ready = bool(
        target is not None and target.type == 'MESH'
        and ensure_geometry_edge_field(
            decal, target,
            getattr(mat, "sd_edge_angle", math.radians(8.0)),
            mat.sd_edge_width,
        ) is not None
    )
    geometry = geometry_edge_socket(
        nt, SLOT_EDGE, (bx + 160.0, by - 220.0), mat.sd_edge_width)
    if not geometry_ready:
        clear_slot(mat, SLOT_EDGE)
        return False, "边缘贴图需要绑定 Mesh 目标，已阻止退化为整片遮罩"

    tex = make_uv_tex(nt, SLOT_EDGE, img, own, (bx, by),
                      non_color=True,
                      mapping=_mapping_values(mat, 'EDGE'))
    sock = _mask_channel_socket(nt, tex, mat.sd_edge_channel, SLOT_EDGE,
                                (bx + 240.0, by))
    out = build_mask_chain(nt, SLOT_EDGE, sock, mat.sd_edge_threshold,
                           mat.sd_edge_softness, mat.sd_edge_invert,
                           (bx + 420.0, by))
    modulate = nt.nodes.new('ShaderNodeMath')
    modulate.operation = 'MULTIPLY'
    modulate.name = SLOT_EDGE + "几何调制"
    modulate.label = "只保留硬边/曲率区域"
    modulate.location = (bx + 620.0, by)
    nt.links.new(geometry, modulate.inputs[0])
    nt.links.new(out, modulate.inputs[1])
    out = modulate.outputs[0]
    nt.links.new(out, bridge_in(node, "Edge Field"))
    layout_slot_nodes(nt, node, SLOT_EDGE, 'EDGE')
    sync_bridge(mat)
    return True, "边缘槽: 目标几何 × 用户贴图"


def sync_bridge(mat):
    """把材质属性推进 Bridge 输入 —— 拖动即时生效, 无需重建。"""
    node = get_bridge(mat)
    if node is None:
        return False
    def setv(name, val):
        socket = bridge_in(node, name)
        if socket is not None and not socket.links:
            try:
                socket.default_value = val
            except (TypeError, ValueError):
                pass

    setv("Surface Mode", 1.0 if mat.sd_surface_mode == 'PRINTED' else 0.0)
    setv("Ink Strength", mat.sd_ink_strength)
    setv("Wear Weight", mat.sd_wear_weight)
    setv("Shared Wear Weight",
         mat.sd_shared_wear_weight if mat.sd_shared_wear_enabled else 0.0)
    setv("Edge Weight", mat.sd_edge_weight)
    setv("Cutout Range", mat.sd_cutout_range)
    setv("Cutout Hardness", mat.sd_cutout_hardness)
    setv("Cutout Feather", mat.sd_cutout_feather)
    res = mat.sd_residue_amount if mat.sd_residue_on else 0.0
    setv("Residue Amount", res)
    setv("Residue Color", (mat.sd_residue_color[0], mat.sd_residue_color[1],
                           mat.sd_residue_color[2], 1.0))
    setv("Residue Roughness", mat.sd_residue_rough if mat.sd_residue_on else 0.0)
    setv("Fade Amount", mat.sd_fade_amount if mat.sd_fade_mode else 0.0)
    setv("Preview Mode", {
        'FINAL': 0.0, 'WEAR': 1.0, 'SHARED': 2.0,
        'EDGE': 3.0, 'NORMAL': 4.0,
    }.get(getattr(mat, "sd_bridge_preview", 'FINAL'), 0.0))
    return True


def sync_bridge_preview(mat):
    """只推进一个预览输入，避免切换预览时刷新 Bridge 的全部参数。"""
    node = get_bridge(mat)
    if node is None:
        return False
    socket = bridge_in(node, "Preview Mode")
    if socket is None or socket.links:
        return False
    socket.default_value = {
        'FINAL': 0.0, 'WEAR': 1.0, 'SHARED': 2.0,
        'EDGE': 3.0, 'NORMAL': 4.0,
    }.get(getattr(mat, "sd_bridge_preview", 'FINAL'), 0.0)
    return True


def sync_slots(mat):
    """遮罩整形参数即时同步(阈值/宽度/反相/程序边缘宽度)。"""
    if mat is None or not mat.use_nodes:
        return False
    nt = mat.node_tree
    sync_mask_chain(nt, SLOT_WEAR, mat.sd_wear_threshold,
                    mat.sd_wear_softness, mat.sd_wear_invert)
    sync_mask_chain(nt, SLOT_EDGE, mat.sd_edge_threshold,
                    mat.sd_edge_softness, mat.sd_edge_invert)
    sync_mapping(mat, SLOT_WEAR, 'WEAR')
    sync_mapping(mat, SLOT_EDGE, 'EDGE')
    rng = nt.nodes.get(SLOT_EDGE + "宽度")      # 程序边缘的宽度
    if rng is not None:
        rng.inputs["From Min"].default_value = max(0.0001, mat.sd_edge_width)
        rng.inputs["From Max"].default_value = 0.0
    for tag, img in ((SLOT_WEAR, mat.sd_wear_image),
                     (SLOT_EDGE, mat.sd_edge_image)):
        tex = nt.nodes.get(tag + "贴图")
        if tex is not None and img is not None:
            tex.image = img
    return True


def _bridge_update(self, context):
    try:
        sync_bridge(self)
    except (AttributeError, RuntimeError):
        pass


def _bridge_preview_update(self, context):
    try:
        sync_bridge_preview(self)
    except (AttributeError, RuntimeError):
        pass


def _ensure_slot_object_dependency(decal, mat, which):
    """补齐属于“对象”而非“材质”的依赖，不能被材质去重跳过。"""
    target = decal_target_of(bpy.context, decal) or decal.parent
    if (which in {'WEAR', 'SHARED'} and target is not None
            and target.type == 'MESH' and uv_health(target)[0]
            and (which == 'SHARED'
                 or getattr(mat, "sd_wear_uv_space", 'DECAL') == 'TARGET')):
        try:
            ensure_target_uv(decal, target, bpy.context)
        except (RuntimeError, AttributeError, ReferenceError):
            pass
    if (which == 'EDGE' and edge_enabled(mat)
            and target is not None and target.type == 'MESH'):
        ensure_geometry_edge_field(
            decal, target,
            getattr(mat, "sd_edge_angle", math.radians(8.0)),
            getattr(mat, "sd_edge_width", 0.02),
        )


def _autobuild_slot(mat, which):
    """指定/更换贴图时自动建链 —— Bridge 与槽都由这里按需建立,
    用户不必再手动点[建立]。找不到使用该材质的贴花时静默跳过(无UV可用)。"""
    users = [o for o in bpy.data.objects
             if o.type == 'MESH' and is_decal(o)
             and any(s.material is mat for s in o.material_slots)]
    for obj in users:
        _ensure_slot_object_dependency(obj, mat, which)
    for obj in users:
        try:
            if which == 'WEAR':
                ok = build_wear_slot(obj, mat)[0]
            elif which == 'EDGE':
                ok = build_edge_slot(obj, mat)[0]
            else:
                ok = build_relief(obj, mat)[0]
        except (RuntimeError, ReferenceError, AttributeError):
            ok = False
        if ok:
            return True
    return False


def _slot_update(self, context):
    try:
        sync_slots(self)
        sync_bridge(self)
    except (AttributeError, RuntimeError):
        pass


def _wear_img_update(self, context):
    """磨损贴图/通道/UV空间改动 → 自动重建该槽。"""
    try:
        if self.sd_wear_image is not None:
            _autobuild_slot(self, 'WEAR')
        else:
            clear_slot(self, SLOT_WEAR)
            bridge = get_bridge(self)
            field = bridge_in(bridge, "Wear Field")
            if field is not None and not field.links:
                field.default_value = 0.0
                bridge_in(bridge, "Wear Weight").default_value = 0.0
    except (AttributeError, RuntimeError):
        pass


def edge_enabled(mat):
    """边缘处理只在用户已经指定边缘贴图时启用。"""
    return mat is not None and getattr(mat, "sd_edge_image", None) is not None


def _edge_img_update(self, context):
    try:
        if edge_enabled(self):
            _autobuild_slot(self, 'EDGE')
        else:
            clear_slot(self, SLOT_EDGE)
            for obj in bpy.data.objects:
                if (is_decal(obj)
                        and any(slot.material == self for slot in obj.material_slots)):
                    remove_geometry_edge_field(obj)
            bridge = get_bridge(self)
            field = bridge_in(bridge, "Edge Field")
            if field is not None and not field.links:
                field.default_value = 0.0
                bridge_in(bridge, "Edge Weight").default_value = 0.0
    except (AttributeError, RuntimeError):
        pass


def _edge_weight_update(self, context):
    try:
        if (edge_enabled(self) and self.sd_edge_weight > 0.0
                and not slot_nodes(self, SLOT_EDGE)):
            _autobuild_slot(self, 'EDGE')
        sync_bridge(self)
    except (AttributeError, RuntimeError):
        pass


def _relief_img_update(self, context):
    try:
        has = (self.sd_relief_normal is not None
               or self.sd_relief_height is not None)
        if has:
            _autobuild_slot(self, 'RELIEF')
        else:
            remove_relief(self)
    except (AttributeError, RuntimeError):
        pass


def _remove_legacy_wear_nodes(mat):
    """Remove retired SDW_ nodes while preserving the original artwork alpha."""
    if mat is None or not mat.use_nodes:
        return False
    nt = mat.node_tree
    legacy = [node for node in nt.nodes
              if node.name.startswith(LEGACY_WEAR_TAG)]
    if not legacy:
        return False
    legacy_set = set(legacy)
    alpha_node = nt.nodes.get(LEGACY_WEAR_TAG + "Alpha")
    keep_socket = None
    keep_value = 1.0
    if alpha_node is not None and alpha_node.inputs:
        original = alpha_node.inputs[0]
        keep_value = original.default_value
        if original.links:
            candidate = original.links[0].from_socket
            if candidate.node not in legacy_set:
                keep_socket = candidate
    if keep_socket is None:
        image_node = _decal_image_node(nt)
        if image_node is not None:
            keep_socket = image_node.outputs.get("Alpha")

    destinations = []
    bridge = get_bridge(mat)
    if bridge is not None:
        destinations.append(bridge_in(bridge, "Artwork Alpha"))
    principled = _find_node(nt, 'ShaderNodeBsdfPrincipled')
    if principled is not None:
        destinations.append(principled.inputs.get("Alpha"))
    for destination in (socket for socket in destinations if socket is not None):
        legacy_links = [link for link in destination.links
                        if link.from_node in legacy_set]
        if not legacy_links:
            continue
        for link in legacy_links:
            nt.links.remove(link)
        if keep_socket is not None:
            nt.links.new(keep_socket, destination)
        elif not destination.links:
            destination.default_value = keep_value
    for node in legacy:
        nt.nodes.remove(node)
    return True


class SURFDECAL_OT_migrate(bpy.types.Operator):
    """把旧版属性迁移到新的三槽结构(方案 §10)。非破坏: 只在新属性为空时
迁入, 迁移完成前不删除任何旧节点; 失败则原材质保持不变"""
    bl_idname = "surfdecal.migrate"
    bl_label = "迁移旧版设置"
    bl_options = {'REGISTER', 'UNDO'}

    @classmethod
    def poll(cls, context):
        return context.mode == 'OBJECT'

    def execute(self, context):
        p = context.scene.surfdecal
        decals, _t = gather_scope(context, p)
        if not decals:
            decals = all_decals()
        moved = 0
        notes = []
        seen = set()
        for d in decals:
            tgt = decal_target_of(context, d) or d.parent
            for slot in d.material_slots:
                m = slot.material
                if m is None or m.name in seen:
                    continue
                seen.add(m.name)
                touched = False
                # 旧: 主物体磨损贴图 → 新: 材质级磨损槽
                if m.sd_wear_image is None and tgt is not None:
                    old_map = getattr(tgt, "surfdecal_wear_map", None)
                    if old_map is not None:
                        m.sd_wear_image = old_map
                        m.sd_wear_uv_space = 'TARGET'
                        ready = bool(slot_nodes(m, SLOT_WEAR))
                        if not ready:
                            ready = build_wear_slot(d, m)[0]
                        if ready:
                            _remove_legacy_wear_nodes(m)
                        touched = True
                        if "主物体磨损贴图" not in notes:
                            notes.append("主物体磨损贴图")
                # 旧: 浮雕法线/高度 已在 relief 系统, 保持不动(仍受支持)
                if touched:
                    moved += 1
        if moved == 0:
            self.report({'INFO'}, "没有需要迁移的旧设置")
            return {'FINISHED'}
        self.report({'INFO'},
                    "已迁移 %d 个材质 (%s) — 已同步到当前磨损槽"
                    % (moved, ", ".join(notes)))
        return {'FINISHED'}


class SURFDECAL_OT_slot_build(bpy.types.Operator):
    """建立/重建资源槽并接入表面桥接。
参数改动即时生效, 这个按钮只在首次创建或架构损坏时才需要"""
    bl_idname = "surfdecal.slot_build"
    bl_label = "建立/重建"
    bl_options = {'REGISTER', 'UNDO'}

    slot: bpy.props.EnumProperty(
        name="槽", items=[('WEAR', "磨损", ""), ('EDGE', "边缘", ""),
                          ('RELIEF', "法线与高度", ""), ('ALL', "全部", "")],
        default='ALL', options={'SKIP_SAVE'})

    @classmethod
    def poll(cls, context):
        return context.mode == 'OBJECT'

    def execute(self, context):
        p = context.scene.surfdecal
        decals, _t = gather_scope(context, p)
        if not decals:
            self.report({'ERROR'}, "请选中贴花")
            return {'CANCELLED'}
        split_shared_materials(decals, context)  # 写时复制
        msgs = []
        n = 0
        seen = set()
        for d in decals:
            auto_name_decal(d, decal_target_of(context, d) or d.parent)
            for slot in d.material_slots:
                m = slot.material
                if m is None:
                    continue
                if self.slot in {'WEAR', 'ALL'}:
                    _ensure_slot_object_dependency(d, m, 'WEAR')
                if self.slot in {'EDGE', 'ALL'}:
                    _ensure_slot_object_dependency(d, m, 'EDGE')
                key = m.as_pointer()
                if key in seen:
                    continue
                seen.add(key)
                if self.slot in {'WEAR', 'ALL'}:
                    okk, why = build_wear_slot(d, m)
                    if okk:
                        n += 1
                    if why not in msgs:
                        msgs.append(why)
                if self.slot in {'EDGE', 'ALL'}:
                    okk, why = build_edge_slot(d, m)
                    if okk:
                        n += 1
                    if why not in msgs:
                        msgs.append(why)
                if self.slot in {'RELIEF', 'ALL'}:
                    if (m.sd_relief_normal is not None
                            or m.sd_relief_height is not None):
                        okk, why = build_relief(d, m)
                        if okk:
                            n += 1
                        if why not in msgs:
                            msgs.append("法线/高度: " + why)
        if n == 0:
            self.report({'WARNING'}, "; ".join(msgs) or "没有可建立的槽")
            return {'CANCELLED'}
        self.report({'INFO'}, "已建立 %d 个槽 — %s" % (n, "; ".join(msgs)))
        return {'FINISHED'}


class SURFDECAL_OT_slot_clear(bpy.types.Operator):
    """清除某个资源槽(其余槽与 Bridge 不受影响)"""
    bl_idname = "surfdecal.slot_clear"
    bl_label = "清除"
    bl_options = {'REGISTER', 'UNDO'}

    slot: bpy.props.EnumProperty(
        name="槽", items=[('WEAR', "磨损", ""), ('EDGE', "边缘", ""),
                          ('RELIEF', "法线与高度", ""),
                          ('BRIDGE', "整个Bridge", "")],
        default='WEAR', options={'SKIP_SAVE'})

    @classmethod
    def poll(cls, context):
        return context.mode == 'OBJECT'

    def execute(self, context):
        p = context.scene.surfdecal
        decals, _t = gather_scope(context, p)
        n = 0
        seen = set()
        for d in decals:
            for slot in d.material_slots:
                m = slot.material
                if m is None or m.name in seen:
                    continue
                seen.add(m.name)
                if self.slot == 'WEAR':
                    if clear_slot(m, SLOT_WEAR):
                        m.sd_wear_weight = 0.0
                        n += 1
                elif self.slot == 'EDGE':
                    if clear_slot(m, SLOT_EDGE):
                        m.sd_edge_weight = 0.0
                        n += 1
                elif self.slot == 'RELIEF':
                    if remove_relief(m):
                        n += 1
                else:
                    clear_slot(m, SLOT_WEAR)
                    clear_slot(m, SLOT_EDGE)
                    remove_relief(m)
                    if remove_bridge(m):
                        n += 1
        if n == 0:
            self.report({'INFO'}, "没有可清除的内容")
            return {'FINISHED'}
        self.report({'INFO'}, "已清除 %d 个材质" % n)
        return {'FINISHED'}


class SURFDECAL_OT_shared_wear_add(bpy.types.Operator):
    """创建一个保存在 .blend 内的共享磨损组，并绑定到所选贴花。"""
    bl_idname = "surfdecal.shared_wear_add"
    bl_label = "新建共享磨损"
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        groups = context.scene.surfdecal_shared_wear_groups
        group = groups.add()
        # uid 会作为 EnumProperty 的 identifier 存进材质, 必须稳定且纯ASCII。
        # 原先是12位随机hex, 在下拉框里被当成显示名时会出现"Ozmü"这类乱码,
        # 且看不出是第几组。改成带序号的可读形式, 仍保证唯一。
        index = len(groups)
        used = {g.uid for g in groups if g.uid}
        while True:
            uid = "SWG%02d_%s" % (index, _new_uid()[:6])
            if uid not in used:
                break
            index += 1
        group.uid = uid
        # 名称给用户看, 只用序号; 内部ID(uid)不出现在任何界面文本里
        group.label = "共享贴花 %d" % len(groups)
        decals, _targets = gather_scope(context, context.scene.surfdecal)
        if not decals and context.object is not None and is_decal(context.object):
            decals = [context.object]
        split_shared_materials(decals, context)
        bound = 0
        seen = set()
        for decal in decals:
            for slot in decal.material_slots:
                mat = slot.material
                if mat is None or mat.as_pointer() in seen:
                    continue
                seen.add(mat.as_pointer())
                mat.sd_shared_wear_group = group.uid
                mat.sd_shared_wear_enabled = True
                bound += 1
        self.report({'INFO'}, "已新建共享磨损组并绑定 %d 个材质" % bound)
        return {'FINISHED'}


class SURFDECAL_OT_shared_wear_remove(bpy.types.Operator):
    """删除活动材质绑定的共享组，并安全解除所有使用者。"""
    bl_idname = "surfdecal.shared_wear_remove"
    bl_label = "删除共享磨损组"
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        mat = context.object.active_material if context.object else None
        uid = getattr(mat, "sd_shared_wear_group", 'NONE') if mat else 'NONE'
        if uid == 'NONE':
            self.report({'INFO'}, "当前材质没有绑定共享磨损组")
            return {'CANCELLED'}
        groups = context.scene.surfdecal_shared_wear_groups
        index = next((i for i, group in enumerate(groups)
                      if group.uid == uid), -1)
        if index < 0:
            self.report({'ERROR'}, "共享磨损组不存在")
            return {'CANCELLED'}
        _localize_shared_wear_materials(context.scene, uid)
        users = 0
        for material in _scene_materials(context.scene):
            if getattr(material, "sd_shared_wear_group", 'NONE') == uid:
                material.sd_shared_wear_enabled = False
                material.sd_shared_wear_group = 'NONE'
                clear_shared_wear_slot(material)
                users += 1
        groups.remove(index)
        self.report({'INFO'}, "已删除共享磨损组并解除 %d 个材质" % users)
        return {'FINISHED'}


def set_slot_preview(mat, mode):
    """只切换 Bridge 内建预览；不改写 Material Output，也不临时插节点。"""
    if mat is None or not mat.use_nodes or mode not in {
            'FINAL', 'WEAR', 'SHARED', 'EDGE', 'NORMAL'}:
        return False
    node = get_bridge(mat)
    socket = bridge_in(node, "Preview Mode") if node is not None else None
    if socket is None or socket.links:
        return False
    mat.sd_bridge_preview = mode
    return True


def shared_preview_materials(uid, scene=None):
    """返回真正用于贴花对象、且绑定同一共享组的全部材质。"""
    materials = []
    seen = set()
    objects = scene.objects if scene is not None else bpy.data.objects
    for obj in objects:
        if not is_decal(obj):
            continue
        for slot in obj.material_slots:
            mat = slot.material
            if (mat is None or mat.as_pointer() in seen
                    or not getattr(mat, "sd_shared_wear_enabled", False)
                    or getattr(mat, "sd_shared_wear_group", 'NONE') != uid):
                continue
            seen.add(mat.as_pointer())
            materials.append(mat)
    return materials


class SURFDECAL_OT_slot_preview(bpy.types.Operator):
    """在当前槽的位置预览遮罩；共享磨损会同时切换该组全部贴花。"""
    bl_idname = "surfdecal.slot_preview"
    bl_label = "预览贴图槽"
    bl_options = {'REGISTER', 'UNDO'}

    mode: bpy.props.EnumProperty(
        name="预览内容",
        items=[
            ('WEAR', "磨损", "预览当前材质的局部磨损"),
            ('SHARED', "共享磨损", "预览共享组影响的全部贴花"),
            ('EDGE', "边缘磨损", "预览当前材质的边缘磨损"),
            ('NORMAL', "法线", "预览当前材质的最终法线"),
        ],
        default='WEAR', options={'SKIP_SAVE'})

    @classmethod
    def poll(cls, context):
        obj = context.object
        return (context.mode == 'OBJECT' and obj is not None
                and is_decal(obj) and obj.active_material is not None)

    def execute(self, context):
        mat = context.object.active_material
        if self.mode == 'SHARED':
            uid = getattr(mat, "sd_shared_wear_group", 'NONE')
            group = find_shared_wear_group(uid, context.scene)
            if (not mat.sd_shared_wear_enabled or uid == 'NONE'
                    or group is None or group.image is None):
                self.report({'ERROR'}, "请先启用共享磨损并指定贴图")
                return {'CANCELLED'}
            mats = shared_preview_materials(uid, context.scene)
            if not mats:
                self.report({'ERROR'}, "共享组没有可预览的贴花")
                return {'CANCELLED'}
            turn_on = not all(m.sd_bridge_preview == 'SHARED' for m in mats)
            mode = 'SHARED' if turn_on else 'FINAL'
            changed = sum(int(set_slot_preview(m, mode)) for m in mats)
            self.report({'INFO'}, "%s共享磨损预览：%d 个材质 / 全部组内贴花"
                        % ("开启" if turn_on else "关闭", changed))
            return {'FINISHED'} if changed else {'CANCELLED'}

        ready = {
            'WEAR': bool(slot_nodes(mat, SLOT_WEAR)),
            'EDGE': bool(slot_nodes(mat, SLOT_EDGE)),
            'NORMAL': bool(relief_nodes(mat)),
        }[self.mode]
        if not ready:
            self.report({'ERROR'}, "请先为当前槽指定贴图")
            return {'CANCELLED'}
        mode = 'FINAL' if mat.sd_bridge_preview == self.mode else self.mode
        if not set_slot_preview(mat, mode):
            self.report({'ERROR'}, "请先完成表面匹配或指定贴图")
            return {'CANCELLED'}
        return {'FINISHED'}


class SURFDECAL_OT_apply_target_transform(bpy.types.Operator):
    """对目标物体应用旋转与缩放, 并自动还原子级世界变换(贴花不会跑位)。
非均匀缩放会破坏包裹的弧长计算, 包裹前建议先执行一次"""
    bl_idname = "surfdecal.apply_target_transform"
    bl_label = "应用目标旋转缩放"
    bl_options = {'REGISTER', 'UNDO'}

    @classmethod
    def poll(cls, context):
        return context.mode == 'OBJECT'

    def execute(self, context):
        p = context.scene.surfdecal
        _d, targets = gather_scope(context, p)
        if not targets:
            targets = [o for o in context.selected_objects
                       if o.type == 'MESH' and not is_decal(o)]
        if not targets:
            self.report({'ERROR'}, "请选中目标物体(或其上的贴花)")
            return {'CANCELLED'}
        done = shared = 0
        for t in targets:
            if t.data is not None and t.data.users > 1:
                shared += 1                 # 多用户网格: 会连带改到别处
                continue
            kids = [c for c in bpy.data.objects if c.parent is t]
            saved = [(c, c.matrix_world.copy()) for c in kids]
            with context.temp_override(object=t, active_object=t,
                                       selected_objects=[t],
                                       selected_editable_objects=[t]):
                try:
                    bpy.ops.object.transform_apply(
                        location=False, rotation=True, scale=True)
                except RuntimeError as e:
                    self.report({'WARNING'}, "%s: %s" % (t.name, e))
                    continue
            for c, mw in saved:             # 还原子级世界变换
                c.matrix_world = mw
            done += 1
        if done == 0:
            self.report({'ERROR'}, "未处理任何目标%s"
                        % ("(网格被多物体共用, 需先独立化)" if shared else ""))
            return {'CANCELLED'}
        msg = "已对 %d 个目标应用旋转+缩放(子级已保位)" % done
        if shared:
            msg += "; %d 个因多用户跳过" % shared
        self.report({'INFO'}, msg)
        return {'FINISHED'}


class SURFDECAL_OT_wear_apply(bpy.types.Operator):
    """建立/重建磨损侵蚀链。参数存在贴花材质上, 之后拖动即时生效"""
    bl_idname = "surfdecal.wear_apply"
    bl_label = "应用磨损"
    bl_options = {'REGISTER', 'UNDO'}

    @classmethod
    def poll(cls, context):
        return context.mode == 'OBJECT'

    def execute(self, context):
        # 保留旧 operator ID 兼容快捷键/脚本，但实际只走新 Wear 槽。
        return bpy.ops.surfdecal.slot_build('EXEC_DEFAULT', slot='WEAR')


class SURFDECAL_OT_wear_remove(bpy.types.Operator):
    """移除磨损侵蚀链, 恢复原Alpha"""
    bl_idname = "surfdecal.wear_remove"
    bl_label = "移除磨损"
    bl_options = {'REGISTER', 'UNDO'}

    @classmethod
    def poll(cls, context):
        return context.mode == 'OBJECT'

    def execute(self, context):
        return bpy.ops.surfdecal.slot_clear('EXEC_DEFAULT', slot='WEAR')


class SURFDECAL_OT_wear_preview(bpy.types.Operator):
    """旧操作符兼容入口；实际使用当前磨损槽的就地预览。"""
    bl_idname = "surfdecal.wear_preview"
    bl_label = "预览磨损"
    bl_options = {'REGISTER', 'UNDO'}

    @classmethod
    def poll(cls, context):
        return context.mode == 'OBJECT'

    def execute(self, context):
        return bpy.ops.surfdecal.slot_preview('EXEC_DEFAULT', mode='WEAR')


# ============================================================
#  贴花管理 / Cycles 专项
# ============================================================

KEY_DECAL_NO = "sd_decal_no"     # 图像上的贴花类型编号(同一张图始终同号)


def decal_pattern_image(decal):
    """贴花自身的图案贴图(排除匹配/磨损/浮雕引入的贴图)。"""
    for slot in decal.material_slots:
        m = slot.material
        if m is None or not m.use_nodes:
            continue
        nd = _decal_image_node(m.node_tree)
        if nd is not None and nd.image is not None:
            return nd.image
    return None


def decal_type_number(image):
    """给图案图分配稳定的类型编号: 箭头=01, 方块=02 …… 同一张图永远同号。
    编号记在图像上, 跨会话与跨目标都一致。"""
    if image is None:
        return 0
    no = image.get(KEY_DECAL_NO)
    if isinstance(no, int) and no > 0:
        return no
    used = set()
    for img in bpy.data.images:
        v = img.get(KEY_DECAL_NO)
        if isinstance(v, int) and v > 0:
            used.add(v)
    i = 1
    while i in used:
        i += 1
    image[KEY_DECAL_NO] = i
    return i


def auto_name_material(mat, image, target=None):
    """材质统一命名: decal_<类型号>_<图名>[_<目标名>]。
    未定制的共享材质不带目标名; 因匹配/磨损分家出去的带上目标名, 一眼能
    看出它专属于谁。"""
    if mat is None:
        return None
    no = decal_type_number(image)
    base = os.path.splitext(image.name)[0][:16] if image is not None else "贴花"
    name = "decal_%02d_%s" % (no, base)
    if target is not None:
        name += "_" + target.name
    if mat.name == name:
        return name
    other = bpy.data.materials.get(name)
    if other is not None and other is not mat:
        return mat.name                     # 已被占用: 不抢名字
    mat.name = name
    return name


def auto_name_decal(decal, target):
    """按贴花类型、目标和序号自动命名对象，并同时整理其材质名称。"""
    if decal is None:
        return None
    tname = target.name if target is not None else "无目标"
    image = decal_pattern_image(decal)
    no = decal_type_number(image)
    prefix = "decal_%02d_%s_" % (no, tname)
    pat = R.compile("^" + R.escape(prefix) + r"(\d+)$")
    used = set()
    for o in bpy.data.objects:
        if o is decal:
            continue
        mm = pat.match(o.name)
        if mm:
            used.add(int(mm.group(1)))
    i = 1
    while i in used:
        i += 1
    decal.name = "%s%d" % (prefix, i)
    for index, slot in enumerate(decal.material_slots):
        mat = slot.material
        if mat is None:
            continue
        # 同一目标上的盖章材质可以共享，不能被每个对象来回改名。
        if len(material_user_objects(mat)) > 1:
            auto_name_material(mat, image, target)
        else:
            suffix = "_材质" if index == 0 else "_材质_%02d" % (index + 1)
            mat.name = decal.name + suffix
    return decal.name



def all_decals():
    return [o for o in bpy.data.objects if o.type == 'MESH' and is_decal(o)]


KEY_NO_MERGE = "sd_no_merge"     # 已分家的材质不再被自动合并
SPLIT_TAG = "SDC_"               # RGB 通道分离节点前缀
KEY_SPLIT = "sd_rgb_split"       # 'R'/'G'/'B'; 空=未启用
KEY_SPLIT_INV = "sd_rgb_invert"
TINT_TAG = "SDT_"                # 上色链路节点前缀
KEY_TINT = "sd_tint_mode"        # ''/'INVERT'/'SOLID'/'DUOTONE'
KEY_TINT_SRC = "sd_tint_src"     # 上色前喂给基础色的源, 用于撤销


def material_user_objects(mat):
    """场景中真正使用该材质的物体(比 mat.users 更准: 排除假用户/多槽重复)。"""
    out = []
    for o in bpy.data.objects:
        if any(s.material is mat for s in o.material_slots):
            out.append(o)
    return out


def split_shared_materials(decals, context=None):
    """写时复制。两种情形必须分家(方案: 资源边界):
    · 该材质被**不同目标**上的贴花共用 —— 表面匹配复制的是目标专属的链,
      共享会让 A 墙的粗糙度跑到 B 墙的贴花上
    · 本批只覆盖该材质的一部分使用者 —— 只改本批, 不动别人
    本批恰好覆盖同一目标的全部使用者时不分家(整面统一应共享一份)。
    返回被独立化的材质槽数。"""
    ctx = context or bpy.context
    batch = {d.name for d in decals}
    copies = {}
    n = 0
    for d in decals:
        tgt = decal_target_of(ctx, d) or d.parent
        tname = tgt.name if tgt is not None else ""
        for slot in d.material_slots:
            m = slot.material
            if m is None:
                continue
            users = material_user_objects(m)
            if len(users) <= 1:
                continue
            tset = set()
            for u in users:
                ut = decal_target_of(ctx, u) or u.parent
                tset.add(ut.name if ut is not None else "")
            outside = any(u.name not in batch for u in users)
            if len(tset) <= 1 and not outside:
                continue                    # 同一目标 + 本批全覆盖: 继续共享
            key = (m.name, tname)
            if key not in copies:
                new = m.copy()
                new[KEY_NO_MERGE] = True    # 分家后不再被自动合并回去
                auto_name_material(new, decal_pattern_image(d), tgt)
                copies[key] = new
            slot.material = copies[key]
            n += 1
    return n



class SURFDECAL_OT_make_material_unique(bpy.types.Operator):
    """把所选贴花的材质独立化 —— 共享材质下想单独调磨损时用"""
    bl_idname = "surfdecal.make_material_unique"
    bl_label = "独立化材质"
    bl_options = {'REGISTER', 'UNDO'}

    @classmethod
    def poll(cls, context):
        return context.mode == 'OBJECT'

    def execute(self, context):
        n = 0
        for d in [o for o in context.selected_objects if is_decal(o)]:
            for slot in d.material_slots:
                m = slot.material
                if m is not None and len(material_user_objects(m)) > 1:
                    new = m.copy()
                    new[KEY_NO_MERGE] = True
                    slot.material = new
                    n += 1
        if n == 0:
            self.report({'INFO'}, "所选材质已是单用户")
            return {'FINISHED'}
        self.report({'INFO'}, "已独立化 %d 个材质" % n)
        return {'FINISHED'}








def needed_transparent_bounces(context):
    """估算所需透明反弹: 场景中最多有几层贴花叠在一起(按目标计) + 余量。"""
    per = {}
    for d in all_decals():
        t = d.get(KEY_TARGET, "") or (d.parent.name if d.parent else "")
        per[t] = per.get(t, 0) + 1
    return max(8, min(64, max(per.values(), default=0) + 4))


class SURFDECAL_OT_fix_bounces(bpy.types.Operator):
    """把 Cycles 透明反弹提到够用 —— Alpha贴花每层要消耗一次透明反弹,
超过上限的层会渲染成黑块"""
    bl_idname = "surfdecal.fix_bounces"
    bl_label = "修正透明反弹"
    bl_options = {'REGISTER', 'UNDO'}

    @classmethod
    def poll(cls, context):
        return hasattr(context.scene, "cycles")

    def execute(self, context):
        cy = getattr(context.scene, "cycles", None)
        if cy is None:
            self.report({'ERROR'}, "场景没有 Cycles 设置")
            return {'CANCELLED'}
        want = needed_transparent_bounces(context)
        old = getattr(cy, "transparent_max_bounces", 0)
        if old >= want:
            self.report({'INFO'}, "透明反弹已足够(%d ≥ %d)" % (old, want))
            return {'FINISHED'}
        cy.transparent_max_bounces = want
        self.report({'INFO'}, "透明反弹 %d → %d" % (old, want))
        return {'FINISHED'}


# ============================================================
#  导出准备: 非破坏地生成副本 → 应用修改器 → 精简 → 按材质合并
# ============================================================




# ============================================================
#  浅浮雕: 贴花自带 法线/高度 贴图(Cycles 走真实bump)
# ============================================================
RELIEF_TAG = "SDB_"


def relief_nodes(mat):
    if mat is None or not mat.use_nodes:
        return {}
    return {n.name: n for n in mat.node_tree.nodes
            if n.name.startswith(RELIEF_TAG)}


def sync_relief(mat):
    """推送浮雕参数到已建节点 —— 拖动即时可见。"""
    nd = relief_nodes(mat)
    if not nd:
        return False
    sync_mapping(mat, RELIEF_TAG, 'RELIEF')
    nm = nd.get(RELIEF_TAG + "法线")
    if nm is not None:
        nm.inputs["Strength"].default_value = mat.sd_relief_normal_strength
        if mat.sd_relief_normal is not None:
            img = nd.get(RELIEF_TAG + "法线贴图")
            if img is not None:
                img.image = mat.sd_relief_normal
    bp = nd.get(RELIEF_TAG + "凹凸")
    if bp is not None:
        bp.inputs["Distance"].default_value = mat.sd_relief_height_distance
        bp.inputs["Strength"].default_value = mat.sd_relief_height_strength
        img = nd.get(RELIEF_TAG + "高度贴图")
        if img is not None and mat.sd_relief_height is not None:
            img.image = mat.sd_relief_height
    return True


def _relief_update(self, context):
    try:
        sync_relief(self)
    except (AttributeError, RuntimeError):
        pass


def build_relief(decal, mat):
    """建浮雕链: 高度→凹凸, 法线→法线贴图, 串联后送入 Bridge。
    一律用贴花自身UV(图案的UV), 不是传递来的目标UV。返回 (成功, 说明)。"""
    if mat is None or not mat.use_nodes:
        return False, "无节点材质"
    nt = mat.node_tree
    b = _find_node(nt, 'ShaderNodeBsdfPrincipled')
    if b is None:
        return False, "缺少 Principled BSDF"
    bridge = ensure_bridge(mat)         # 与其它槽一致: 先备好统一出口
    if bridge is None:
        return False, "无法准备表面处理节点"
    remove_relief(mat)
    own = (decal.data.uv_layers[0].name
           if decal is not None and decal.data.uv_layers else "")
    bx, by = b.location.x, b.location.y
    uvn = None
    mapn = None
    if own:
        uvn = nt.nodes.new('ShaderNodeUVMap')
        uvn.name = RELIEF_TAG + "UV"
        uvn.uv_map = own
        uvn.location = (bx - 1400.0, by - 1750.0)
        mapn = nt.nodes.new('ShaderNodeMapping')
        mapn.name = RELIEF_TAG + "映射"
        mapn.label = "法线/高度 · 位置 · 旋转 · 大小"
        mapn.location = (bx - 1200.0, by - 1750.0)
        _set_mapping_node(mapn, *_mapping_values(mat, 'RELIEF'))
        nt.links.new(uvn.outputs["UV"], mapn.inputs["Vector"])
    chain = None
    notes = []
    if mat.sd_relief_normal is not None:
        tex = nt.nodes.new('ShaderNodeTexImage')
        tex.name = RELIEF_TAG + "法线贴图"
        tex.image = mat.sd_relief_normal
        try:
            tex.image.colorspace_settings.name = 'Non-Color'
        except (AttributeError, TypeError):
            pass
        tex.location = (bx - 1000.0, by - 1750.0)
        if mapn is not None:
            nt.links.new(mapn.outputs["Vector"], tex.inputs["Vector"])
        nm = nt.nodes.new('ShaderNodeNormalMap')
        nm.name = RELIEF_TAG + "法线"
        nm.uv_map = own
        nm.inputs["Strength"].default_value = mat.sd_relief_normal_strength
        nm.location = (bx - 700.0, by - 1750.0)
        nt.links.new(tex.outputs["Color"], nm.inputs["Color"])
        chain = nm.outputs["Normal"]
        notes.append("法线贴图")
    if mat.sd_relief_height is not None:
        tex2 = nt.nodes.new('ShaderNodeTexImage')
        tex2.name = RELIEF_TAG + "高度贴图"
        tex2.image = mat.sd_relief_height
        try:
            tex2.image.colorspace_settings.name = 'Non-Color'
        except (AttributeError, TypeError):
            pass
        tex2.location = (bx - 1000.0, by - 2050.0)
        if mapn is not None:
            nt.links.new(mapn.outputs["Vector"], tex2.inputs["Vector"])
        bp = nt.nodes.new('ShaderNodeBump')
        bp.name = RELIEF_TAG + "凹凸"
        bp.inputs["Distance"].default_value = mat.sd_relief_height_distance
        bp.inputs["Strength"].default_value = mat.sd_relief_height_strength
        bp.location = (bx - 480.0, by - 1900.0)
        nt.links.new(tex2.outputs["Color"], bp.inputs["Height"])
        if chain is not None:               # 法线先进凹凸, 二者叠加
            nt.links.new(chain, bp.inputs["Normal"])
        chain = bp.outputs["Normal"]
        notes.append("高度凹凸")
    if chain is None:
        return False, "没有指定法线或高度贴图"
    nt.links.new(chain, bridge_in(bridge, "Artwork Normal"))
    bridge_in(bridge, "Artwork Normal Weight").default_value = 1.0
    _connect_bridge_outputs(nt, bridge, b)
    layout_slot_nodes(nt, get_bridge(mat), RELIEF_TAG, 'RELIEF')
    return True, " + ".join(notes)


def remove_relief(mat):
    if mat is None or not mat.use_nodes:
        return False
    nt = mat.node_tree
    hit = [n for n in nt.nodes if n.name.startswith(RELIEF_TAG)]
    bridge = get_bridge(mat)
    reset = False
    for n in hit:
        nt.nodes.remove(n)
    if bridge is not None:
        inp = bridge_in(bridge, "Artwork Normal")
        if inp is not None:
            for link in list(inp.links):
                if link.from_node.name.startswith(RELIEF_TAG):
                    nt.links.remove(link)
                    reset = True
            if not inp.links:
                inp.default_value = (0.0, 0.0, 1.0)
                bridge_in(bridge, "Artwork Normal Weight").default_value = 0.0
                reset = True
    return bool(hit or reset)


class SURFDECAL_OT_relief_apply(bpy.types.Operator):
    """给贴花接入自带的法线/高度贴图 —— 做凸起铭牌、蚀刻编号、冲压字。
Cycles 下高度走真实 Bump, 参数改动即时生效"""
    bl_idname = "surfdecal.relief_apply"
    bl_label = "应用浮雕"
    bl_options = {'REGISTER', 'UNDO'}

    @classmethod
    def poll(cls, context):
        return context.mode == 'OBJECT'

    def execute(self, context):
        p = context.scene.surfdecal
        decals, _t = gather_scope(context, p)
        if not decals:
            self.report({'ERROR'}, "请选中贴花")
            return {'CANCELLED'}
        split = split_shared_materials(decals, context)  # 写时复制
        done = 0
        seen = set()
        msgs = []
        for d in decals:
            for slot in d.material_slots:
                m = slot.material
                if m is None or m.name in seen:
                    continue
                seen.add(m.name)
                okk, why = build_relief(d, m)
                if okk:
                    done += 1
                    if why not in msgs:
                        msgs.append(why)
        if done == 0:
            self.report({'ERROR'}, "没接入任何浮雕(先在面板指定法线或高度贴图)")
            return {'CANCELLED'}
        msg = "浮雕: %d 个材质 — %s" % (done, "; ".join(msgs))
        if split:
            msg += " (已为 %d 个贴花独立化材质)" % split
        self.report({'INFO'}, msg)
        return {'FINISHED'}


class SURFDECAL_OT_relief_remove(bpy.types.Operator):
    """移除浮雕节点"""
    bl_idname = "surfdecal.relief_remove"
    bl_label = "移除浮雕"
    bl_options = {'REGISTER', 'UNDO'}

    @classmethod
    def poll(cls, context):
        return context.mode == 'OBJECT'

    def execute(self, context):
        p = context.scene.surfdecal
        decals, _t = gather_scope(context, p)
        n = 0
        seen = set()
        for d in decals:
            for slot in d.material_slots:
                m = slot.material
                if m is not None and m.name not in seen:
                    seen.add(m.name)
                    if remove_relief(m):
                        n += 1
        if n == 0:
            self.report({'ERROR'}, "没有浮雕节点")
            return {'CANCELLED'}
        self.report({'INFO'}, "已移除 %d 个材质的浮雕" % n)
        return {'FINISHED'}



# ============================================================
#  贴花库
# ============================================================

def image_tracer_path():
    """Return the bundled offline image-to-SVG tool path."""
    return os.path.join(os.path.dirname(os.path.abspath(__file__)),
                        "assets", "image-tracer.html")


def image_tracer_uri():
    """Return a browser-safe file URI, including non-ASCII install paths."""
    return Path(image_tracer_path()).resolve().as_uri()


def _open_local_file(path):
    """在系统默认程序中打开本地文件, 依次尝试多种方式。

    只用 bpy.ops.wm.url_open 不够可靠: 它面向 http(s), 对 Windows 上的
    file:// URI 常常静默失败, 安装路径里带空格(如 "Blender Foundation")
    或中文时尤其容易。所以优先用系统级打开, 再回落到浏览器。
    返回 (成功, 用了哪种方式 或 各方式的失败原因)。
    """
    tried = []
    # 1) Windows: 直接交给资源管理器关联程序
    starter = getattr(os, "startfile", None)
    if starter is not None:
        try:
            starter(path)
            return True, "os.startfile"
        except OSError as exc:
            tried.append("startfile: %s" % exc)
    # 2) macOS / Linux: open / xdg-open
    import subprocess
    for cmd in (["open", path], ["xdg-open", path]):
        if shutil.which(cmd[0]) is None:
            continue
        try:
            subprocess.Popen(cmd, stdout=subprocess.DEVNULL,
                             stderr=subprocess.DEVNULL)
            return True, cmd[0]
        except OSError as exc:
            tried.append("%s: %s" % (cmd[0], exc))
    # 3) Python 标准库的浏览器接口
    try:
        import webbrowser
        if webbrowser.open(Path(path).resolve().as_uri()):
            return True, "webbrowser"
        tried.append("webbrowser: 返回 False")
    except Exception as exc:      # 边界IO: 系统可能没有可用浏览器
        tried.append("webbrowser: %s" % exc)
    # 4) 最后才试 Blender 自己的
    try:
        result = bpy.ops.wm.url_open(url=Path(path).resolve().as_uri())
        if 'FINISHED' in result:
            return True, "wm.url_open"
        tried.append("wm.url_open: %s" % (result,))
    except Exception as exc:      # 边界IO: 无浏览器关联时会抛
        tried.append("wm.url_open: %s" % exc)
    return False, "; ".join(tried)


class SURFDECAL_OT_open_image_tracer(bpy.types.Operator):
    """在系统浏览器中打开随插件安装的离线图像转 SVG 工具"""
    bl_idname = "surfdecal.open_image_tracer"
    bl_label = "贴花生成(浏览器)"
    bl_description = "在系统浏览器中打开内置的离线图像转 SVG 工具"
    bl_options = {'REGISTER'}

    def execute(self, context):
        path = image_tracer_path()
        if not os.path.isfile(path):
            # 路径一并报出来: 多数情况是只拷了 __init__.py 而没装整个 ZIP
            self.report({'ERROR'},
                        "找不到内置 HTML, 请用完整 ZIP 安装。期望位置: %s"
                        % path)
            return {'CANCELLED'}
        okay, how = _open_local_file(path)
        if not okay:
            context.window_manager.clipboard = path
            self.report({'ERROR'},
                        "无法自动打开, 路径已复制到剪贴板, 手动粘进浏览器即可。"
                        "尝试过: %s" % how)
            return {'CANCELLED'}
        self.report({'INFO'}, "已在浏览器中打开 (%s)" % how)
        return {'FINISHED'}




class SURFDECAL_OT_lib_refresh(bpy.types.Operator):
    """刷新贴花库(只读): 只列已登记的资产, 不会修改图片元数据"""
    bl_idname = "surfdecal.lib_refresh"
    bl_label = "刷新"
    bl_options = {'REGISTER'}

    def execute(self, context):
        n = scan_library(context)
        d = library_dir_path(context)
        self.report({'INFO'}, "贴花库: %d 个已登记条目" % n)
        return {'FINISHED'}


class SURFDECAL_OT_lib_collect(bpy.types.Operator, ImportHelper):
    """从磁盘选 PNG/JPG 登记进贴花库(只登记, 不创建贴花)。
若指定了库文件夹, 会把文件复制过去再登记"""
    bl_idname = "surfdecal.lib_collect"
    bl_label = "登记到库"
    bl_options = {'REGISTER', 'UNDO'}

    filename_ext = ".png"
    filter_glob: bpy.props.StringProperty(
        default="*.png;*.jpg;*.jpeg", options={'HIDDEN'})
    files: bpy.props.CollectionProperty(
        type=bpy.types.OperatorFileListElement, options={'HIDDEN'})
    directory: bpy.props.StringProperty(subtype='DIR_PATH', options={'HIDDEN'})

    def execute(self, context):
        p = context.scene.surfdecal
        libdir = library_dir_path(context)
        paths = []
        if self.files:
            for f in self.files:
                if f.name:
                    paths.append(os.path.join(self.directory, f.name))
        elif self.filepath:
            paths.append(self.filepath)
        if not paths:
            self.report({'ERROR'}, "没有选择文件")
            return {'CANCELLED'}
        added = skipped = 0
        for path in paths:
            if os.path.splitext(path)[1].lower() not in LIB_BASE_EXTS:
                skipped += 1
                continue
            use = path
            if libdir:
                dst = os.path.join(libdir, os.path.basename(path))
                if _norm_path(dst) != _norm_path(path):
                    try:
                        if not os.path.exists(dst):
                            shutil.copy2(path, dst)
                        use = dst
                    except (OSError, shutil.Error):
                        use = path
            try:
                img = bpy.data.images.load(use, check_existing=True)
            except Exception as e:      # 边界IO: 用户选的文件可能非法
                self.report({'WARNING'}, "%s: %s" % (os.path.basename(use), e))
                skipped += 1
                continue
            if register_library_asset(img, use, context):
                added += 1
            else:
                skipped += 1
        scan_library(context)
        msg = "已登记 %d 个" % added
        if skipped:
            msg += "; %d 个跳过(仅支持 PNG/JPG)" % skipped
        self.report({'INFO'}, msg)
        return {'FINISHED'}


class SURFDECAL_OT_lib_remove(bpy.types.Operator):
    """从贴花库移除当前选中的条目 —— 只取消登记, 不删原文件,
也不影响已经在用它的贴花材质"""
    bl_idname = "surfdecal.lib_remove"
    bl_label = "从库移除"
    bl_options = {'REGISTER', 'UNDO'}

    @classmethod
    def poll(cls, context):
        return bool(_lib_items)

    def execute(self, context):
        p = context.scene.surfdecal
        key = p.library_item
        if not key or key == 'NONE' or not key.startswith("IMG:"):
            self.report({'ERROR'}, "请先在库中选中一个条目")
            return {'CANCELLED'}
        img = bpy.data.images.get(key[4:])
        if img is None:
            scan_library(context)
            self.report({'WARNING'}, "条目已失效, 已刷新")
            return {'CANCELLED'}
        name = img.name
        unregister_library_asset(img, context)
        scan_library(context)
        self.report({'INFO'}, "已从库移除 %s (原文件与贴花不受影响)" % name)
        return {'FINISHED'}



class SURFDECAL_OT_lib_place(bpy.types.Operator):
    """放置贴花库中选中的贴花(按"导入后"设置吸附到所选物体或进入交互投放)"""
    bl_idname = "surfdecal.lib_place"
    bl_label = "放置所选贴花"
    bl_options = {'REGISTER', 'UNDO'}

    @classmethod
    def poll(cls, context):
        return context.mode == 'OBJECT' and bool(_lib_items)

    def execute(self, context):
        p = context.scene.surfdecal
        key = p.library_item
        if not key or key == 'NONE':
            self.report({'ERROR'}, "贴花库中没有选中条目")
            return {'CANCELLED'}

        if key.startswith("IMG:"):              # 本文件已有图像: 直接复用
            img = bpy.data.images.get(key[4:])
            if img is None:
                self.report({'ERROR'}, "图像已不存在, 请点[刷新]")
                return {'CANCELLED'}
            target = resolve_import_target(context)
            obj = create_image_decal_object(context, img, p.lib_width,
                                            'HASHED', False, p.grid)
            if obj is None:
                self.report({'ERROR'}, "图像尺寸无效")
                return {'CANCELLED'}
            obj.location = context.scene.cursor.location
            finish_imported_decal(self, context, obj, p, p.lib_after, target)
            return {'FINISHED'}

        self.report({'ERROR'}, "条目格式无效, 请点[刷新贴花库]")
        return {'CANCELLED'}


# ============================================================
#  偏好设置
# ============================================================

class SURFDECAL_Prefs(bpy.types.AddonPreferences):
    bl_idname = __name__

    library_dir: bpy.props.StringProperty(
        name="贴花库文件夹",
        description="存放贴花图片/SVG的文件夹, 会显示在N面板的贴花库中",
        subtype='DIR_PATH', default="")

    def draw(self, context):
        col = self.layout.column()
        col.prop(self, "library_dir")
        col.label(text="设置后到 3D视口 N面板 → 贴花 → 贴花库 点[刷新]",
                  icon='INFO')


# ============================================================
#  面板
# ============================================================


class SURFDECAL_PT_main(bpy.types.Panel):
    """父面板: 状态与全局告警。子面板顺序由注册顺序决定。"""
    bl_label = "yo的贴花"
    bl_idname = "SURFDECAL_PT_main"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = "yo的贴花"

    def draw(self, context):
        layout = self.layout
        p = context.scene.surfdecal
        obj = context.object
        col = layout.column(align=True)
        col.label(text="目标 = 所选/活动物体", icon='RESTRICT_SELECT_OFF')
        if obj is not None and is_decal(obj):
            t = decal_target_of(context, obj) or obj.parent
            col.label(text="%s → %s" % (obj.name, t.name if t else "无目标"),
                      icon='CHECKMARK')
        elif obj is not None and obj.type == 'MESH':
            col.label(text="%s (%d 张贴花)"
                      % (obj.name, len(decals_of_target(obj))),
                      icon='OBJECT_DATA')
        col.prop(p, "parent_to_target")
        cy = getattr(context.scene, "cycles", None)
        if cy is not None:
            need = needed_transparent_bounces(context)
            have = getattr(cy, "transparent_max_bounces", 0)
            if have < need:
                box = layout.box()
                box.label(text="透明反弹 %d < 需要 %d (叠层会发黑)"
                          % (have, need), icon='ERROR')
                box.operator("surfdecal.fix_bounces", icon='CHECKMARK')


def artwork_targets(mat):
    """图案应当接到哪两个口: 有 Bridge 走 Bridge, 否则直连 Principled。"""
    if mat is None or not mat.use_nodes:
        return None, None
    b = get_bridge(mat)
    if b is not None:
        return bridge_in(b, "Artwork Color"), bridge_in(b, "Artwork Alpha")
    node = _find_node(mat.node_tree, 'ShaderNodeBsdfPrincipled')
    if node is None:
        return None, None
    return node.inputs.get("Base Color"), node.inputs.get("Alpha")


def _unlink(nt, socket):
    if socket is None:
        return
    for link in list(socket.links):
        nt.links.remove(link)


def _ensure_alpha_blend(mat):
    """分离出来的通道当 alpha 用, 材质必须允许透明。"""
    # Cycles 不需要设混合模式; 只保证镂空处不投影。
    mat.use_transparent_shadow = True


def apply_rgb_split(mat, channel, invert):
    """把图案图的 R/G/B 之一接到 Alpha —— 一张图打包三张贴花时用。

    基础色同时与图像断开: RGB 打包图的颜色是三张图混在一起的结果,
    没有意义, 改用可在面板直接调的纯色。
    """
    if mat is None or not mat.use_nodes:
        return False
    nt = mat.node_tree
    img = _decal_image_node(nt)
    if img is None or img.image is None:
        return False
    col_dst, alpha_dst = artwork_targets(mat)
    if alpha_dst is None:
        return False

    sep = nt.nodes.get(SPLIT_TAG + "通道分离")
    if sep is not None and sep.bl_idname != 'ShaderNodeSeparateColor':
        nt.nodes.remove(sep)
        sep = None
    if sep is None:
        sep = nt.nodes.new('ShaderNodeSeparateColor')
        sep.name = sep.label = SPLIT_TAG + "通道分离"
        sep.location = (img.location.x + 300.0, img.location.y - 140.0)
    if hasattr(sep, "mode"):
        sep.mode = 'RGB'
    _unlink(nt, sep.inputs["Color"])
    nt.links.new(img.outputs["Color"], sep.inputs["Color"])

    inv = nt.nodes.get(SPLIT_TAG + "反相")
    if invert:
        if inv is not None and inv.bl_idname != 'ShaderNodeInvert':
            nt.nodes.remove(inv)
            inv = None
        if inv is None:
            inv = nt.nodes.new('ShaderNodeInvert')
            inv.name = inv.label = SPLIT_TAG + "反相"
            inv.location = (sep.location.x + 200.0, sep.location.y)
    elif inv is not None:
        nt.nodes.remove(inv)
        inv = None

    src = sep.outputs[{'R': "Red", 'G': "Green", 'B': "Blue"}[channel]]
    if inv is not None:
        _unlink(nt, inv.inputs["Color"])
        nt.links.new(src, inv.inputs["Color"])
        src = inv.outputs["Color"]
    _unlink(nt, alpha_dst)
    nt.links.new(src, alpha_dst)

    if col_dst is not None:
        _strip_tint(nt)                 # 打包图上的黑白反转/双色都没有意义
        _unlink(nt, col_dst)
        try:
            v = col_dst.default_value
            if len(v) >= 3 and max(v[0], v[1], v[2]) < 0.02:
                col_dst.default_value = (1.0, 1.0, 1.0, 1.0)
        except Exception:
            pass                        # 边界: 个别 socket 无颜色默认值
        mat[KEY_TINT] = 'SOLID'
    _ensure_alpha_blend(mat)
    mat[KEY_SPLIT] = channel
    mat[KEY_SPLIT_INV] = 1 if invert else 0
    mat[KEY_NO_MERGE] = 1               # 已定制, 不再被新贴花认领
    for t in (nt, mat):
        try:
            t.update_tag()
        except Exception:
            pass
    return True


def clear_rgb_split(mat):
    """撤销分离, 把图像的颜色与 alpha 接回去。"""
    if mat is None or not mat.use_nodes:
        return False
    nt = mat.node_tree
    for name in (SPLIT_TAG + "通道分离", SPLIT_TAG + "反相"):
        n = nt.nodes.get(name)
        if n is not None:
            nt.nodes.remove(n)
    img = _decal_image_node(nt)
    col_dst, alpha_dst = artwork_targets(mat)
    if img is not None:
        if col_dst is not None:
            _unlink(nt, col_dst)
            nt.links.new(img.outputs["Color"], col_dst)
        if alpha_dst is not None:
            _unlink(nt, alpha_dst)
            nt.links.new(img.outputs["Alpha"], alpha_dst)
    for key in (KEY_SPLIT, KEY_SPLIT_INV, KEY_TINT):
        if key in mat:
            del mat[key]
    for t in (nt, mat):
        try:
            t.update_tag()
        except Exception:
            pass
    return True


def split_target_materials(context):
    """所选贴花的活动材质; 没有选中时退回活动物体。"""
    mats, seen = [], set()
    objs = [o for o in context.selected_objects if is_decal(o)]
    if not objs and context.object is not None and is_decal(context.object):
        objs = [context.object]
    for o in objs:
        m = o.active_material
        if m is None and o.material_slots:
            m = o.material_slots[0].material
        if m is not None and m.name not in seen:
            seen.add(m.name)
            mats.append(m)
    return mats


def _strip_tint(nt):
    for n in [x for x in nt.nodes if x.name.startswith(TINT_TAG)]:
        nt.nodes.remove(n)


def tint_source(nt, mat, col_dst):
    """当前喂给基础色的那一路。

    刻意不写死成"图案贴图": 图集取图的贴花是解码组在供色, 直接抓
    上游才能对两种贴花都成立。第一次接管时把源记在材质上, 之后撤销
    才知道该接回哪里。
    """
    rec = mat.get(KEY_TINT_SRC)
    if rec and "|" in rec:
        nname, sname = rec.split("|", 1)
        n = nt.nodes.get(nname)
        if n is not None:
            s = n.outputs.get(sname)
            if s is not None:
                return s
    if col_dst is not None and col_dst.links:
        s = col_dst.links[0].from_socket
        if not s.node.name.startswith(TINT_TAG):
            mat[KEY_TINT_SRC] = "%s|%s" % (s.node.name, s.name)
            return s
    img = _decal_image_node(nt)
    if img is not None:
        mat[KEY_TINT_SRC] = "%s|Color" % img.name
        return img.outputs["Color"]
    return None


def apply_tint(mat, mode):
    """贴花上色。只改基础色一路, alpha 完全不经过这里。

    OFF     原样接回
    INVERT  黑白互换(Invert)
    SOLID   断开图像, 用基础色口的默认色
    DUOTONE 明度→双色渐变, 面板上给一条完整色带
    """
    if mat is None or not mat.use_nodes:
        return False
    nt = mat.node_tree
    col_dst, _alpha = artwork_targets(mat)
    if col_dst is None:
        return False
    src = tint_source(nt, mat, col_dst)
    if mat.get(KEY_SPLIT) and mode in {'OFF', 'INVERT', 'DUOTONE'}:
        mode = 'SOLID'              # 打包图的颜色没有意义, 只能纯色
    _strip_tint(nt)
    _unlink(nt, col_dst)

    if mode == 'SOLID':
        try:
            v = col_dst.default_value
            if len(v) >= 3 and max(v[0], v[1], v[2]) < 0.02:
                col_dst.default_value = (1.0, 1.0, 1.0, 1.0)
        except Exception:
            pass                    # 边界: 个别 socket 无颜色默认值
    elif src is None:
        return False
    elif mode == 'INVERT':
        inv = nt.nodes.new('ShaderNodeInvert')
        inv.name = inv.label = TINT_TAG + "黑白反转"
        inv.location = (col_dst.node.location.x - 320.0,
                        col_dst.node.location.y - 320.0)
        nt.links.new(src, inv.inputs["Color"])
        nt.links.new(inv.outputs["Color"], col_dst)
    elif mode == 'DUOTONE':
        bw = nt.nodes.new('ShaderNodeRGBToBW')
        bw.name = bw.label = TINT_TAG + "明度"
        bw.location = (col_dst.node.location.x - 520.0,
                       col_dst.node.location.y - 320.0)
        ramp = nt.nodes.new('ShaderNodeValToRGB')
        ramp.name = ramp.label = TINT_TAG + "双色"
        ramp.location = (col_dst.node.location.x - 340.0,
                         col_dst.node.location.y - 320.0)
        e = ramp.color_ramp.elements
        e[0].color = (0.0, 0.0, 0.0, 1.0)
        e[1].color = (1.0, 1.0, 1.0, 1.0)
        nt.links.new(src, bw.inputs["Color"])
        nt.links.new(bw.outputs["Val"], ramp.inputs["Fac"])
        nt.links.new(ramp.outputs["Color"], col_dst)
    else:                           # OFF
        nt.links.new(src, col_dst)

    if mode == 'OFF':
        for key in (KEY_TINT, KEY_TINT_SRC):
            if key in mat:
                del mat[key]
    else:
        mat[KEY_TINT] = mode
        mat[KEY_NO_MERGE] = 1
    for t in (nt, mat):
        try:
            t.update_tag()
        except Exception:
            pass
    return True


class SURFDECAL_OT_tint(bpy.types.Operator):
    """贴花上色: 黑白互换 / 纯色 / 双色渐变; 不影响透明"""
    bl_idname = "surfdecal.tint"
    bl_label = "上色"
    bl_options = {'REGISTER', 'UNDO'}

    mode: bpy.props.EnumProperty(
        name="方式",
        items=[('OFF', "原图", "用图像本来的颜色"),
               ('INVERT', "黑白反转", "黑白互换, 透明不变"),
               ('SOLID', "纯色", "整张贴花一个颜色, 形状仍由alpha决定"),
               ('DUOTONE', "双色", "按明度在两个颜色之间映射")],
        default='OFF')

    @classmethod
    def poll(cls, context):
        return context.mode == 'OBJECT'

    def execute(self, context):
        done = [m for m in split_target_materials(context)
                if apply_tint(m, self.mode)]
        if not done:
            self.report({'ERROR'}, "没有可上色的贴花材质")
            return {'CANCELLED'}
        self.report({'INFO'}, "%d 份材质: %s" % (len(done), self.mode))
        return {'FINISHED'}


class SURFDECAL_OT_rgb_split(bpy.types.Operator):
    """用图像的一个颜色通道当形状: 一张图打包了三张贴花时选其中一张"""
    bl_idname = "surfdecal.rgb_split"
    bl_label = "RGB分离"
    bl_options = {'REGISTER', 'UNDO'}

    channel: bpy.props.EnumProperty(
        name="通道",
        items=[('R', "红 R", "红通道当形状"),
               ('G', "绿 G", "绿通道当形状"),
               ('B', "蓝 B", "蓝通道当形状")],
        default='R')
    invert: bpy.props.BoolProperty(
        name="反相", default=False,
        description="通道里图形是暗的、背景是亮的时候打开")

    @classmethod
    def poll(cls, context):
        return context.mode == 'OBJECT'

    def execute(self, context):
        mats = split_target_materials(context)
        done = [m for m in mats if apply_rgb_split(m, self.channel,
                                                   self.invert)]
        if not done:
            self.report({'ERROR'}, "没有可处理的贴花材质(需要有图案贴图)")
            return {'CANCELLED'}
        self.report({'INFO'}, "%d 份材质改用 %s 通道%s"
                    % (len(done), self.channel, " (反相)" if self.invert
                       else ""))
        return {'FINISHED'}


class SURFDECAL_OT_rgb_split_clear(bpy.types.Operator):
    """关闭RGB分离, 恢复用图像自身的颜色与透明通道"""
    bl_idname = "surfdecal.rgb_split_clear"
    bl_label = "关闭分离"
    bl_options = {'REGISTER', 'UNDO'}

    @classmethod
    def poll(cls, context):
        return context.mode == 'OBJECT'

    def execute(self, context):
        mats = [m for m in split_target_materials(context) if m.get(KEY_SPLIT)]
        for m in mats:
            clear_rgb_split(m)
        if not mats:
            self.report({'WARNING'}, "所选贴花没有启用RGB分离")
            return {'CANCELLED'}
        self.report({'INFO'}, "已关闭 %d 份" % len(mats))
        return {'FINISHED'}


ADOPT_MARK = "ac_atlas"      # 外部插件(AtlasCut 图集取图)生成平面的标记


def _copy_into_library(src, context):
    """把文件复制进库目录, 重名则加序号。返回目标路径或 None。"""
    directory = library_dir_path(context)
    if not directory or not os.path.isdir(directory):
        return None
    base, ext = os.path.splitext(os.path.basename(src))
    dst = os.path.join(directory, base + ext)
    if _norm_path(dst) == _norm_path(src):
        return dst                          # 本来就在库里
    n = 1
    while os.path.exists(dst):
        dst = os.path.join(directory, "%s_%02d%s" % (base, n, ext))
        n += 1
        if n > 999:
            return None
    try:
        with open(src, "rb") as fh:
            data = fh.read()
        with open(dst, "wb") as fh:
            fh.write(data)
    except OSError:
        return None
    return dst


def uv_bounds(mesh):
    """UV 包围框 (u0, v0, u1, v1); 没有可用UV返回 None。"""
    if mesh is None or not mesh.uv_layers:
        return None
    layer = mesh.uv_layers.active or mesh.uv_layers[0]
    n = len(layer.data)
    if n == 0:
        return None
    buf = np.empty(n * 2, dtype=np.float32)
    try:
        layer.data.foreach_get("uv", buf)
    except (RuntimeError, TypeError):
        return None
    uv = buf.reshape(n, 2)
    return (float(uv[:, 0].min()), float(uv[:, 1].min()),
            float(uv[:, 0].max()), float(uv[:, 1].max()))


def mirror_uv_offsets(bounds):
    """镜像修改器要让 UV 在给定矩形内原地翻转所需的 Flip 偏移。

    修改器的实现是纯加法: u' = 1 - u + mirror_offset_u (+ offset_u)。
    默认偏移为 0 时等于绕 0.5 翻 —— UV 铺满 0~1 的贴花没问题, 但图集
    贴花只占一小块矩形, 绕 0.5 翻会落到图集的另一头, 取到别的图形。
    要原地翻转需要 u' = u0 + u1 - u, 于是偏移 = u0 + u1 - 1。
    """
    u0, v0, u1, v1 = bounds
    return (max(-1.0, min(1.0, u0 + u1 - 1.0)),
            max(-1.0, min(1.0, v0 + v1 - 1.0)))


MIRROR_UV_MODES = (
    ('AUTO', "字正", "两半都正读。按镜像轴推断该翻哪一路: X轴→翻U, Y轴→翻V"),
    ('FLIP180', "对着", "另一半旋转180°(U和V都翻): 两行字头对头, "
                        "各自从自己那一侧正读 —— 工业标识的常规做法"),
    ('MIRROR', "字反", "不翻UV: 图形跟着几何一起镜像, 字是反的"),
    ('U', "只翻U", "手动: 只做水平翻转"),
    ('V', "只翻V", "手动: 只做垂直翻转"),
)


def mirror_uv_mode(md):
    """从修改器现有设置反推当前是哪种状态, 用于面板高亮。"""
    u = bool(getattr(md, "use_mirror_u", False))
    v = bool(getattr(md, "use_mirror_v", False))
    if u and v:
        return 'FLIP180'
    if not u and not v:
        return 'MIRROR'
    return 'AUTO'


class SURFDECAL_OT_fix_mirror_uv(bpy.types.Operator):
    """设定镜像修改器怎么翻 UV: 字正 / 对着(转180°) / 字反"""
    bl_idname = "surfdecal.fix_mirror_uv"
    bl_label = "镜像UV"
    bl_options = {'REGISTER', 'UNDO'}

    mode: bpy.props.EnumProperty(name="方式", items=MIRROR_UV_MODES,
                                 default='AUTO')

    @classmethod
    def poll(cls, context):
        return context.mode == 'OBJECT'

    def execute(self, context):
        done, warned = 0, []
        for obj in context.selected_objects:
            if obj.type != 'MESH':
                continue
            mirrors = [m for m in obj.modifiers if m.type == 'MIRROR']
            if not mirrors:
                continue
            bounds = uv_bounds(obj.data)
            if bounds is None:
                warned.append("%s 没有UV" % obj.name)
                continue
            off_u, off_v = mirror_uv_offsets(bounds)
            names = [m.name for m in obj.modifiers]
            shrink_at = (names.index(MOD_SHRINK)
                         if MOD_SHRINK in names else None)
            for md in mirrors:
                if self.mode == 'AUTO':
                    do_u = bool(md.use_axis[0])
                    do_v = bool(md.use_axis[1])
                elif self.mode == 'FLIP180':
                    do_u = do_v = True      # 翻U+翻V 等价于旋转180°
                elif self.mode == 'MIRROR':
                    do_u = do_v = False
                else:
                    do_u = (self.mode == 'U')
                    do_v = (self.mode == 'V')
                md.use_mirror_u = do_u
                md.use_mirror_v = do_v
                md.mirror_offset_u = off_u if do_u else 0.0
                md.mirror_offset_v = off_v if do_v else 0.0
                md.offset_u = 0.0       # 这两个是烘焙用的位移, 不该掺进来
                md.offset_v = 0.0
                if hasattr(md, "use_mirror_udim"):
                    md.use_mirror_udim = False   # 按瓦片中心翻会绕回 0.5
                done += 1
                if (shrink_at is not None
                        and names.index(md.name) > shrink_at):
                    warned.append("%s: 镜像排在收缩包裹之后, 复制体会带着"
                                  "第一张的曲率" % obj.name)
        if not done:
            self.report({'ERROR'}, "所选物体上没有镜像修改器")
            return {'CANCELLED'}
        label = dict((k, n) for k, n, _d in MIRROR_UV_MODES)[self.mode]
        msg = "%d 个镜像修改器 → %s (Flip U %.4f / V %.4f)" % (
            done, label, off_u, off_v)
        if warned:
            self.report({'WARNING'}, msg + " — " + "; ".join(warned[:2]))
        else:
            self.report({'INFO'}, msg)
        return {'FINISHED'}


class SURFDECAL_OT_library_add(bpy.types.Operator):
    """把一张现成的贴花图收进贴花库(外部插件烘出的贴花走这个入口)"""
    bl_idname = "surfdecal.library_add"
    bl_label = "收进贴花库"
    bl_options = {'REGISTER'}

    filepath: bpy.props.StringProperty(subtype='FILE_PATH')
    filter_glob: bpy.props.StringProperty(default="*.png;*.jpg;*.jpeg",
                                          options={'HIDDEN'})
    copy_to_library: bpy.props.BoolProperty(
        name="复制进库目录", default=True,
        description="关掉则原地登记, 文件被移动或删除后条目会失效")

    def invoke(self, context, event):
        context.window_manager.fileselect_add(self)
        return {'RUNNING_MODAL'}

    def execute(self, context):
        src = bpy.path.abspath(self.filepath or "")
        if not src or not os.path.isfile(src):
            self.report({'ERROR'}, "文件不存在")
            return {'CANCELLED'}
        if os.path.splitext(src)[1].lower() not in LIB_BASE_EXTS:
            self.report({'ERROR'}, "贴花库只收 PNG / JPG")
            return {'CANCELLED'}
        if not library_dir_path(context):
            self.report({'ERROR'},
                        "还没设贴花库目录: 偏好设置 → 插件 → yo的贴花 → "
                        "贴花库目录。没有目录就写不了清单, 条目无法保留")
            return {'CANCELLED'}
        dst = _copy_into_library(src, context) if self.copy_to_library else src
        if dst is None:
            self.report({'WARNING'}, "复制进库失败, 已改为原地登记")
            dst = src
        try:
            img = bpy.data.images.load(dst, check_existing=True)
        except (RuntimeError, OSError) as exc:
            self.report({'ERROR'}, "加载失败: %s" % exc)
            return {'CANCELLED'}
        if not register_library_asset(img, dst, context,
                                      source=LIB_SRC_ADD):
            self.report({'ERROR'}, "登记失败")
            return {'CANCELLED'}
        n = scan_library(context)
        self.report({'INFO'}, "已收进贴花库: %s (共 %d 条)"
                    % (os.path.basename(dst), n))
        return {'FINISHED'}


class SURFDECAL_OT_adopt_external(bpy.types.Operator):
    """把外部插件生成的平面登记为贴花, 走与导入完全相同的收尾流程"""
    bl_idname = "surfdecal.adopt_external"
    bl_label = "接管外部平面"
    bl_options = {'REGISTER', 'UNDO'}

    after: bpy.props.EnumProperty(
        name="接管后",
        items=[
            ('CONFORM', "吸附到选中物体", "吸附到同时选中的目标网格或组实例"),
            ('PLACE', "进入交互投放", "登记后直接进入投放模式"),
            ('NONE', "仅登记", "只登记为贴花, 之后手动处理"),
        ],
        default='CONFORM')

    @classmethod
    def poll(cls, context):
        return context.mode == 'OBJECT'

    def _split(self, context):
        """分出待接管的平面与目标。

        带外部标记的网格优先当平面; 一个都没有时退回活动物体。
        目标从其余所选里取, 与 resolve_import_target 同口径。
        """
        sel = [o for o in context.selected_objects if o.type == 'MESH']
        planes = [o for o in sel if not is_decal(o) and ADOPT_MARK in o]
        if not planes:
            ao = context.active_object
            if ao is not None and ao.type == 'MESH' and not is_decal(ao):
                planes = [ao]
        cands = ([context.active_object]
                 if context.active_object is not None else [])
        cands.extend(context.selected_objects)
        for o in cands:
            if o is None or o in planes:
                continue
            if o.type == 'MESH' and not is_decal(o):
                return planes, o
            if o.type == 'EMPTY' and o.instance_collection is not None:
                return planes, o
        return planes, None

    def execute(self, context):
        p = context.scene.surfdecal
        planes, target = self._split(context)
        planes = [o for o in planes
                  if o.data is not None and len(o.data.polygons) > 0]
        if not planes:
            self.report({'ERROR'},
                        "没有可接管的平面: 请选中外部插件生成的网格")
            return {'CANCELLED'}
        after = self.after
        if after == 'PLACE' and len(planes) > 1:
            after = 'NONE'          # 交互投放一次只处理一张
        for obj in planes:
            # 先写持久ID: 之后 is_decal 即为真, 面板与诊断立刻认得它
            bind_decal_target(obj, target)
            finish_imported_decal(self, context, obj, p, after, target)
        if len(planes) > 1:
            self.report({'INFO'}, "已接管 %d 张外部平面" % len(planes))
        return {'FINISHED'}


class SURFDECAL_PT_import(bpy.types.Panel):
    """导入与贴花库。"""
    bl_label = "导入与贴花库"
    bl_idname = "SURFDECAL_PT_import"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = "yo的贴花"
    bl_parent_id = "SURFDECAL_PT_main"

    def draw(self, context):
        layout = self.layout
        p = context.scene.surfdecal
        row = layout.row(align=True)
        row.operator("surfdecal.import_svg", text="SVG", icon='IMPORT')
        row.operator("surfdecal.import_image", text="PNG/JPG", icon='IMPORT')

        layout.operator("surfdecal.open_image_tracer",
                        text="贴花生成(浏览器)", icon='URL')
        layout.operator("surfdecal.adopt_external",
                        text="接管外部平面", icon='LINKED')
        layout.operator("surfdecal.library_add",
                        text="收进贴花库", icon='IMPORT')

        box = layout.box()
        box.label(text="贴花库", icon='IMAGE_DATA')
        prefs = get_prefs(context)
        if prefs is not None:
            box.prop(prefs, "library_dir", text="")
        row = box.row(align=True)
        row.operator("surfdecal.lib_refresh", text="刷新贴花库",
                     icon='FILE_REFRESH')
        row.operator("surfdecal.lib_collect", icon='IMPORT')
        if _lib_items:
            box.template_icon_view(p, "library_item", show_labels=True,
                                   scale=5.0)
            col = box.column(align=True)
            col.prop(p, "lib_width")
            col.prop(p, "lib_after", text="")
            row = box.row(align=True)
            row.operator("surfdecal.lib_place", icon='ADD')
            row.operator("surfdecal.lib_remove", icon='X')
        else:
            box.label(text="尚未通过 SurfDecal 导入 PNG/JPG", icon='INFO')


class SURFDECAL_PT_place(bpy.types.Panel):
    """日常放置操作；低频生成参数放到默认收起的子面板。"""
    bl_label = "放置贴花"
    bl_idname = "SURFDECAL_PT_place"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = "yo的贴花"
    bl_parent_id = "SURFDECAL_PT_main"

    def draw(self, context):
        layout = self.layout
        p = context.scene.surfdecal
        col = layout.column(align=True)
        col.scale_y = 1.25
        op = col.operator("surfdecal.place", icon='MOD_SHRINKWRAP')
        op.use_selected = False
        op = col.operator("surfdecal.place", text="投放所选物体",
                          icon='OUTLINER_OB_MESH')
        op.use_selected = True
        col.operator("surfdecal.conform", icon='SNAP_ON')
        row = layout.row(align=True)
        row.operator("surfdecal.refresh", icon='FILE_REFRESH')
        row.operator("surfdecal.apply", icon='CHECKMARK')


class SURFDECAL_PT_generation(bpy.types.Panel):
    """只在新建/重建时参考的参数，默认收起避免干扰日常流程。"""
    bl_label = "生成参数（仅新建/重建）"
    bl_idname = "SURFDECAL_PT_generation"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = "yo的贴花"
    bl_parent_id = "SURFDECAL_PT_place"
    bl_options = {'DEFAULT_CLOSED'}

    def draw(self, context):
        p = context.scene.surfdecal
        col = self.layout.column(align=True)
        col.prop(p, "size")
        col.prop(p, "grid")
        col.prop(p, "subsurf_levels")
        col.prop(p, "offset")
        col.prop(p, "wrap_method", text="")
        if p.wrap_method == 'PROJECT':
            col.prop(p, "project_limit")
        col.prop(p, "live_limit")
        col.prop(p, "ignore_cutters")
        col.separator()
        col.prop(p, "use_normal_transfer")
        sub = col.column(align=True)
        sub.enabled = p.use_normal_transfer
        sub.prop(p, "normal_mix")
        col.prop(p, "use_solidify")
        sub = col.column(align=True)
        sub.enabled = p.use_solidify
        sub.prop(p, "thickness")
        col.separator()
        col.prop(p, "share_materials")
        col.label(text="单独调参时自动分家, 整面统一则继续共享", icon='INFO')


class SURFDECAL_PT_selected(bpy.types.Panel):
    """所选贴花: 直接调其修改器、缩放、包裹。"""
    bl_label = "所选贴花"
    bl_idname = "SURFDECAL_PT_selected"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = "yo的贴花"
    bl_parent_id = "SURFDECAL_PT_main"

    @classmethod
    def poll(cls, context):
        return context.object is not None and is_decal(context.object)

    def draw(self, context):
        layout = self.layout
        obj = context.object
        row = layout.row(align=True)
        row.label(text=obj.name, icon='OUTLINER_OB_MESH')
        row.label(text="%d 面" % len(obj.data.polygons), icon='MESH_GRID')
        if is_frozen(obj):
            row.label(text="几何已固化", icon='FREEZE')
        tgt = decal_target_of(context, obj)
        if tgt is None:
            box = layout.box()
            box.label(text="目标已丢失", icon='ERROR')
            box.label(text="选中贴花+把新目标设为活动物体后:", icon='BLANK1')
            box.operator("surfdecal.rebind_target", icon='SNAP_ON')


class SURFDECAL_PT_wrap(bpy.types.Panel):
    """所选贴花的几何贴合、包裹、缩放与固化后维护。"""
    bl_label = "包裹"
    bl_idname = "SURFDECAL_PT_wrap"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = "yo的贴花"
    bl_parent_id = "SURFDECAL_PT_selected"
    bl_order = 1

    @classmethod
    def poll(cls, context):
        return context.object is not None and is_decal(context.object)

    def draw(self, context):
        layout = self.layout
        obj = context.object
        wrapped = is_wrapped(obj)
        if wrapped:
            layout.label(text="已硬边包裹: 形状已烘入网格, 吸附修改器已退役",
                         icon='CHECKMARK')
            layout.label(text="移动后可直接重新包裹; 改生成参数请先还原",
                         icon='INFO')
            col = layout.column(align=True)
            col.operator("surfdecal.unwrap", icon='LOOP_BACK')
            col.operator("surfdecal.wrap_bake", text="按当前位置重新包裹",
                         icon='MOD_CLOTH')
            for md in obj.modifiers:        # 包裹后仍在的修改器照样能调
                if md.name == MOD_SOLID:
                    col.prop(md, "thickness", text="厚度")
                elif md.name == MOD_NORMAL:
                    col.prop(md, "mix_factor", text="法线融合强度")
            return
        if is_frozen(obj):
            col = layout.column(align=True)
            for md in obj.modifiers:        # 冻结后仍在的修改器照样能调
                if md.name == MOD_SOLID:
                    col.prop(md, "thickness", text="厚度")
                elif md.name == MOD_NORMAL:
                    col.prop(md, "mix_factor", text="法线融合强度")
            return
        col = layout.column(align=True)
        col.prop(obj, "surfdecal_scale", text="贴花缩放")
        for md in obj.modifiers:
            if md.name == MOD_SHRINK:
                col.prop(md, "offset", text="悬浮间距")
            elif md.name == MOD_SUBSURF:
                col.prop(md, "levels", text="细分级别")
            elif md.name == MOD_SOLID:
                col.prop(md, "thickness", text="厚度")
            elif md.name == MOD_NORMAL:
                col.prop(md, "mix_factor", text="法线融合强度")
        ms = obj.modifiers.get(MOD_SHRINK)
        if ms is not None:
            txt = ("切换为: 沿法线投射" if ms.wrap_method != 'PROJECT'
                   else "切换为: 最近表面点")
            col.operator("surfdecal.toggle_wrap", text=txt,
                         icon='ARROW_LEFTRIGHT')
        col.operator("surfdecal.wrap_bake", icon='MOD_CLOTH')
        col.operator("surfdecal.scale_decal", icon='FULLSCREEN_ENTER')
        if any(md.type == 'MIRROR' for md in obj.modifiers):
            mbox = layout.box()
            mbox.label(text="镜像", icon='MOD_MIRROR')
            bnd = uv_bounds(obj.data)
            if bnd is not None and (bnd[2] - bnd[0]) < 0.999:
                mbox.label(text="UV只占图集一角, 需要修正翻转点",
                           icon='INFO')
            md0 = next(md for md in obj.modifiers if md.type == 'MIRROR')
            cur = mirror_uv_mode(md0)
            row = mbox.row(align=True)
            for key, label, _desc in MIRROR_UV_MODES[:3]:
                o = row.operator("surfdecal.fix_mirror_uv", text=label,
                                 depress=(cur == key))
                o.mode = key
            mbox.label(text={'AUTO': "两半都正读",
                             'FLIP180': "另一半转180°, 字头对头",
                             'MIRROR': "字跟着几何一起反"}[cur],
                       icon='INFO')


class SURFDECAL_PT_match(bpy.types.Panel):
    """表面桥接入口：从目标材质取通道 + 动态目标UV。"""
    bl_label = "表面匹配"
    bl_idname = "SURFDECAL_PT_match"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = "yo的贴花"
    bl_parent_id = "SURFDECAL_PT_selected"
    bl_order = 0

    @classmethod
    def poll(cls, context):
        obj = context.object
        return (obj is not None and is_decal(obj)
                and bool(obj.material_slots))

    def draw(self, context):
        layout = self.layout
        p = context.scene.surfdecal
        layout.label(text="把目标通道原样复制给贴花(不生成图案)", icon='INFO')
        col = layout.column(align=True)
        col.prop(p, "match_rough")
        sub = col.column(align=True)
        sub.enabled = p.match_rough
        sub.prop(p, "match_rough_offset")
        col.prop(p, "match_normal")
        sub = col.column(align=True)
        sub.enabled = p.match_normal
        sub.prop(p, "match_normal_strength")
        mat = context.object.active_material
        if mat is not None:
            col.separator()
            col.prop(mat, "sd_surface_mode", text="")
            if mat.sd_surface_mode == 'PRINTED':
                col.prop(mat, "sd_ink_strength")
        row = layout.row(align=True)
        row.operator("surfdecal.match_roughness", text="匹配目标表面",
                     icon='NODETREE')
        row.operator("surfdecal.match_clear", icon='X')


class SURFDECAL_PT_maps(bpy.types.Panel):
    """贴花贴图: 磨损 / 边缘 / 法线与高度 三个独立资源槽同框。
    交互顺序按方案 §7.3 统一: 图 → UV/通道 → 阈值 → 各通道强度 → 建立/清除。"""
    bl_label = "贴花贴图"
    bl_idname = "SURFDECAL_PT_maps"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = "yo的贴花"
    bl_parent_id = "SURFDECAL_PT_selected"
    bl_options = {'DEFAULT_CLOSED'}
    bl_order = 2

    @classmethod
    def poll(cls, context):
        # 父面板已保证选中的是贴花, 这里不再重复空状态提示(方案§7.1)
        obj = context.object
        return (obj is not None and is_decal(obj)
                and bool(obj.material_slots))

    def draw(self, context):
        layout = self.layout
        obj = context.object
        amat = obj.active_material if obj.material_slots else None
        if amat is None:
            layout.label(text="贴花没有材质", icon='ERROR')
            return
        box = layout.box()
        cur = amat.get(KEY_SPLIT, "")
        inv = bool(amat.get(KEY_SPLIT_INV))
        box.label(text="RGB分离(一图三贴花)", icon='NODE_TEXTURE')
        row = box.row(align=True)
        for ch in ('R', 'G', 'B'):
            o = row.operator("surfdecal.rgb_split", text=ch,
                             depress=(cur == ch))
            o.channel = ch
            o.invert = inv
        if cur:
            row = box.row(align=True)
            o = row.operator("surfdecal.rgb_split", text="反相",
                             depress=inv)
            o.channel = cur
            o.invert = not inv
            row.operator("surfdecal.rgb_split_clear", text="关闭")
        else:
            box.label(text="通道接Alpha, 基础色改用纯色", icon='INFO')

        box = layout.box()
        box.label(text="上色(不影响透明)", icon='COLOR')
        tmode = amat.get(KEY_TINT, "") or 'OFF'
        row = box.row(align=True)
        for key, label in (('OFF', "原图"), ('INVERT', "黑白反转"),
                           ('SOLID', "纯色"), ('DUOTONE', "双色")):
            if cur and key in {'OFF', 'INVERT', 'DUOTONE'}:
                continue            # 分离状态下颜色只能是纯色
            o = row.operator("surfdecal.tint", text=label,
                             depress=(tmode == key))
            o.mode = key
        col_dst, _alpha = artwork_targets(amat)
        if tmode == 'SOLID' and col_dst is not None and not col_dst.links:
            box.prop(col_dst, "default_value", text="颜色")
            if cur:
                box.label(text="颜色由RGB分离接管", icon='INFO')
        elif tmode == 'DUOTONE':
            ramp = amat.node_tree.nodes.get(TINT_TAG + "双色")
            if ramp is not None:
                box.template_color_ramp(ramp, "color_ramp", expand=True)

        layout.label(text="按需要展开下面的贴图槽", icon='DISCLOSURE_TRI_RIGHT')


class SURFDECAL_PT_wear(bpy.types.Panel):
    bl_label = "磨损"
    bl_idname = "SURFDECAL_PT_wear"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = "yo的贴花"
    bl_parent_id = "SURFDECAL_PT_maps"
    bl_options = {'DEFAULT_CLOSED'}
    bl_order = 0

    @classmethod
    def poll(cls, context):
        obj = context.object
        return (obj is not None and is_decal(obj)
                and obj.active_material is not None)

    def draw(self, context):
        layout = self.layout
        amat = context.object.active_material
        box = layout
        built = bool(slot_nodes(amat, SLOT_WEAR))
        has_img = amat.sd_wear_image is not None
        box.label(text="磨损   %s" % ("已接入" if built else
                                     ("指定贴图即生效" if not has_img
                                      else "待重建")),
                  icon='CHECKMARK' if built else 'DOT')
        # 强度放在最前且加大 —— 它为0时整槽不显示, 埋在参数堆里很难被发现
        effect = box.box()
        effect.label(text="最终效果", icon='MOD_MASK')
        erow = effect.row(align=True)
        erow.scale_y = 1.6
        erow.prop(amat, "sd_wear_weight", text="磨损强度", slider=True)
        if amat.sd_wear_weight <= 0.0:
            effect.label(text="强度为 0, 这一槽不会产生任何磨损",
                         icon='ERROR')
        box.template_ID(amat, "sd_wear_image", open="image.open")
        if has_img:
            op = box.operator(
                "surfdecal.slot_preview",
                text=("关闭磨损预览" if amat.sd_bridge_preview == 'WEAR'
                      else "预览磨损贴图"),
                icon='HIDE_OFF', depress=amat.sd_bridge_preview == 'WEAR')
            op.mode = 'WEAR'
        col = box.column(align=True)
        col.enabled = has_img
        col.prop(amat, "sd_wear_uv_space", text="")
        row = col.row(align=True)
        row.prop(amat, "sd_wear_channel", text="")
        row.prop(amat, "sd_wear_invert", toggle=True)
        col.prop(amat, "sd_wear_threshold")
        col.prop(amat, "sd_wear_softness")
        mapbox = col.box()
        mapbox.label(text="纹理坐标与映射", icon='ORIENTATION_GLOBAL')
        mapbox.prop(amat, "sd_wear_map_location")
        mapbox.prop(amat, "sd_wear_map_rotation")
        mapbox.prop(amat, "sd_wear_map_scale")
        if has_img and not built:
            op = box.operator("surfdecal.slot_build", text="建立磨损链",
                              icon='NODETREE')
            op.slot = 'WEAR'
        elif built:
            op = box.operator("surfdecal.slot_clear", text="移除磨损",
                              icon='X')
            op.slot = 'WEAR'


class SURFDECAL_PT_shared_wear(bpy.types.Panel):
    bl_label = "共享磨损"
    bl_idname = "SURFDECAL_PT_shared_wear"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = "yo的贴花"
    bl_parent_id = "SURFDECAL_PT_maps"
    bl_options = {'DEFAULT_CLOSED'}
    bl_order = 1

    @classmethod
    def poll(cls, context):
        obj = context.object
        return (obj is not None and is_decal(obj)
                and obj.active_material is not None)

    def draw(self, context):
        layout = self.layout
        amat = context.object.active_material
        shared_box = layout
        shared_box.prop(amat, "sd_shared_wear_enabled")
        row = shared_box.row(align=True)
        row.enabled = amat.sd_shared_wear_enabled
        row.prop(amat, "sd_shared_wear_group", text="")
        row.operator("surfdecal.shared_wear_add", text="", icon='ADD')
        remove_row = row.row(align=True)
        remove_row.enabled = amat.sd_shared_wear_group != 'NONE'
        remove_row.operator("surfdecal.shared_wear_remove", text="", icon='REMOVE')
        shared = find_shared_wear_group(
            amat.sd_shared_wear_group, context.scene)
        if amat.sd_shared_wear_enabled and shared is not None:
            shared_box.prop(shared, "label")
            shared_box.template_ID(shared, "image", open="image.open")
            if shared.image is not None:
                op = shared_box.operator(
                    "surfdecal.slot_preview",
                    text=("关闭全组预览"
                          if amat.sd_bridge_preview == 'SHARED'
                          else "预览该组全部贴花"),
                    icon='HIDE_OFF',
                    depress=amat.sd_bridge_preview == 'SHARED')
                op.mode = 'SHARED'
            # 强度提到最前并加大 —— 为0时整组不显示, 埋在参数堆里难发现
            seffect = shared_box.box()
            seffect.label(text="最终效果", icon='MOD_MASK')
            erow2 = seffect.row(align=True)
            erow2.scale_y = 1.6
            erow2.prop(amat, "sd_shared_wear_weight", text="共享磨损强度",
                       slider=True)
            if amat.sd_shared_wear_weight <= 0.0:
                seffect.label(text="强度为 0, 共享磨损不会显示", icon='ERROR')
            scol = shared_box.column(align=True)
            scol.enabled = shared.image is not None
            srow = scol.row(align=True)
            srow.prop(shared, "channel", text="")
            srow.prop(shared, "invert", toggle=True)
            scol.prop(shared, "threshold")
            scol.prop(shared, "softness")
            scol.prop(shared, "space", text="")
            if shared.space == 'OBJECT':
                scol.label(text="阵列/镜像的复制体各自磨损", icon='INFO')
            mapping = scol.box()
            mapping.label(text=("目标物体空间共享映射"
                                if shared.space == 'OBJECT'
                                else "目标UV共享映射"),
                          icon='ORIENTATION_GLOBAL')
            mapping.prop(shared, "location")
            mapping.prop(shared, "rotation")
            mapping.prop(shared, "scale")
            scol.label(text="局部磨损仍可单独叠加", icon='INFO')


class SURFDECAL_PT_edge(bpy.types.Panel):
    bl_label = "边缘磨损"
    bl_idname = "SURFDECAL_PT_edge"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = "yo的贴花"
    bl_parent_id = "SURFDECAL_PT_maps"
    bl_options = {'DEFAULT_CLOSED'}
    bl_order = 2

    @classmethod
    def poll(cls, context):
        obj = context.object
        return (obj is not None and is_decal(obj)
                and obj.active_material is not None)

    def draw(self, context):
        layout = self.layout
        amat = context.object.active_material
        box = layout
        built = bool(slot_nodes(amat, SLOT_EDGE))
        has_e = amat.sd_edge_image is not None
        box.label(text="边缘   %s" % ("已接入" if built else
                                     ("指定贴图即生效" if not has_e
                                      else "待重建")),
                  icon='CHECKMARK' if built else 'DOT')
        effect = box.box()
        effect.label(text="最终效果", icon='MOD_MASK')
        erow = effect.row(align=True)
        erow.scale_y = 1.6
        erow.prop(amat, "sd_edge_weight", text="边缘磨损强度", slider=True)
        if amat.sd_edge_weight <= 0.0:
            effect.label(text="强度为 0, 这一槽不会产生任何磨损",
                         icon='ERROR')
        box.template_ID(amat, "sd_edge_image", open="image.open")
        texture_controls = box.column(align=True)
        texture_controls.enabled = amat.sd_edge_image is not None
        row = texture_controls.row(align=True)
        row.prop(amat, "sd_edge_channel", text="")
        row.prop(amat, "sd_edge_invert", toggle=True)
        texture_controls.prop(amat, "sd_edge_threshold")
        texture_controls.prop(amat, "sd_edge_softness")
        mapbox = texture_controls.box()
        mapbox.label(text="纹理坐标与映射", icon='ORIENTATION_GLOBAL')
        mapbox.prop(amat, "sd_edge_map_location")
        mapbox.prop(amat, "sd_edge_map_rotation")
        mapbox.prop(amat, "sd_edge_map_scale")
        if amat.sd_edge_image is None:
            box.label(text="选择贴图后可调通道、阈值和映射", icon='INFO')
        geo = box.box()
        geo.label(text="几何边缘限制", icon='MOD_NORMALEDIT')
        geo.prop(amat, "sd_edge_angle")
        geo.prop(amat, "sd_edge_width")
        if built:
            op = box.operator(
                "surfdecal.slot_preview",
                text=("关闭边缘预览" if amat.sd_bridge_preview == 'EDGE'
                      else "预览边缘磨损"),
                icon='HIDE_OFF', depress=amat.sd_bridge_preview == 'EDGE')
            op.mode = 'EDGE'
        if has_e and not built:
            op = box.operator("surfdecal.slot_build", text="建立边缘链",
                              icon='NODETREE')
            op.slot = 'EDGE'
        elif built:
            op = box.operator("surfdecal.slot_clear", text="移除边缘",
                              icon='X')
            op.slot = 'EDGE'


class SURFDECAL_PT_relief(bpy.types.Panel):
    bl_label = "法线与高度"
    bl_idname = "SURFDECAL_PT_relief"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = "yo的贴花"
    bl_parent_id = "SURFDECAL_PT_maps"
    bl_options = {'DEFAULT_CLOSED'}
    bl_order = 3

    @classmethod
    def poll(cls, context):
        obj = context.object
        return (obj is not None and is_decal(obj)
                and obj.active_material is not None)

    def draw(self, context):
        layout = self.layout
        amat = context.object.active_material
        box = layout
        built = bool(relief_nodes(amat))
        has_r = (amat.sd_relief_normal is not None
                 or amat.sd_relief_height is not None)
        box.label(text="法线与高度   %s" % ("已接入" if built else
                                          ("指定贴图即生效" if not has_r
                                           else "待重建")),
                  icon='CHECKMARK' if built else 'DOT')
        col = box.column(align=True)
        col.label(text="法线贴图")
        col.template_ID(amat, "sd_relief_normal", open="image.open")
        sub = col.column(align=True)
        sub.enabled = amat.sd_relief_normal is not None
        sub.prop(amat, "sd_relief_normal_strength")
        col.separator()
        col.label(text="高度贴图(Cycles真实Bump)")
        col.template_ID(amat, "sd_relief_height", open="image.open")
        sub = col.column(align=True)
        sub.enabled = amat.sd_relief_height is not None
        sub.prop(amat, "sd_relief_height_distance")
        sub.prop(amat, "sd_relief_height_strength")
        mapbox = col.box()
        mapbox.label(text="法线/高度共用映射", icon='ORIENTATION_GLOBAL')
        mapbox.prop(amat, "sd_relief_map_location")
        mapbox.prop(amat, "sd_relief_map_rotation")
        mapbox.prop(amat, "sd_relief_map_scale")
        if built:
            op = box.operator(
                "surfdecal.slot_preview",
                text=("关闭法线预览" if amat.sd_bridge_preview == 'NORMAL'
                      else "预览法线"),
                icon='HIDE_OFF', depress=amat.sd_bridge_preview == 'NORMAL')
            op.mode = 'NORMAL'
        if has_r and not built:
            op = box.operator("surfdecal.slot_build", text="建立法线/高度链",
                              icon='NODETREE')
            op.slot = 'RELIEF'
        elif built:
            op = box.operator("surfdecal.slot_clear", text="移除法线/高度",
                              icon='X')
            op.slot = 'RELIEF'


class SURFDECAL_PT_cutout(bpy.types.Panel):
    """所有损伤场合成后的最终镂空与残留控制，固定放在流程末尾。"""
    bl_label = "侵蚀输出（最终）"
    bl_idname = "SURFDECAL_PT_cutout"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = "yo的贴花"
    bl_parent_id = "SURFDECAL_PT_maps"
    bl_options = {'DEFAULT_CLOSED'}
    bl_order = 4

    @classmethod
    def poll(cls, context):
        obj = context.object
        return (obj is not None and is_decal(obj)
                and obj.active_material is not None)

    def draw(self, context):
        amat = context.object.active_material
        col = self.layout.column(align=True)
        col.prop(amat, "sd_cutout_range")
        col.prop(amat, "sd_cutout_hardness")
        col.prop(amat, "sd_cutout_feather")
        col.label(text="完全侵蚀处直接露出目标表面", icon='INFO')
        col.separator()
        col.prop(amat, "sd_residue_on")
        sub = col.column(align=True)
        sub.enabled = amat.sd_residue_on
        sub.prop(amat, "sd_residue_amount")
        sub.prop(amat, "sd_residue_color", text="")
        sub.prop(amat, "sd_residue_rough")
        col.separator()
        col.prop(amat, "sd_fade_mode")
        sub = col.column(align=True)
        sub.enabled = amat.sd_fade_mode
        sub.prop(amat, "sd_fade_amount")


class SURFDECAL_PT_advanced(bpy.types.Panel):
    """高级与修复: 默认收起, 不干扰日常工作流。"""
    bl_label = "高级与修复"
    bl_idname = "SURFDECAL_PT_advanced"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = "yo的贴花"
    bl_parent_id = "SURFDECAL_PT_main"
    bl_options = {'DEFAULT_CLOSED'}

    def draw(self, context):
        layout = self.layout
        p = context.scene.surfdecal
        col = layout.column(align=True)
        col.prop(p, "scope", text="")
        col.prop(p, "auto_subdiv")
        row = col.row(align=True)
        row.enabled = any(is_decal(o) for o in context.selected_objects)
        row.operator("surfdecal.decimate", icon='MOD_DECIM')
        col.separator()
        col.operator("surfdecal.apply_target_transform", icon='CHECKMARK')
        col.operator("surfdecal.make_material_unique", icon='DUPLICATE')
        op = col.operator("surfdecal.slot_build", text="重建全部贴图槽",
                          icon='FILE_REFRESH')
        op.slot = 'ALL'
        col.operator("surfdecal.migrate", icon='FILE_REFRESH')
        col.operator("surfdecal.rebind_target", icon='SNAP_ON')
        col.separator()
        col.operator("surfdecal.unmanage", icon='UNLINKED')
        col.separator()
        col.operator("surfdecal.tidy_nodes", icon='NODETREE')
        col.operator("surfdecal.diagnose", icon='CONSOLE')




# ============================================================
#  注册
# ============================================================

classes = (
    SD_SharedWearGroup,
    SURFDECAL_OT_adopt_external,
    SURFDECAL_OT_fix_mirror_uv,
    SURFDECAL_OT_library_add,
    SURFDECAL_OT_tint,
    SURFDECAL_OT_rgb_split,
    SURFDECAL_OT_rgb_split_clear,
    SD_Props,
    SURFDECAL_OT_place,
    SURFDECAL_OT_conform,
    SURFDECAL_OT_refresh,
    SURFDECAL_OT_toggle_wrap,
    SURFDECAL_OT_wrap,
    SURFDECAL_OT_unmanage,
    SURFDECAL_OT_rebind_target,
    SURFDECAL_OT_tidy_nodes,
    SURFDECAL_OT_diagnose,
    SURFDECAL_OT_unwrap,
    SURFDECAL_OT_decimate,
    SURFDECAL_OT_scale,
    SURFDECAL_OT_apply,
    SURFDECAL_OT_import_svg,
    SURFDECAL_OT_import_image,
    SURFDECAL_OT_relief_apply,
    SURFDECAL_OT_relief_remove,
    SURFDECAL_OT_make_material_unique,
    SURFDECAL_OT_fix_bounces,
    SURFDECAL_OT_migrate,
    SURFDECAL_OT_slot_build,
    SURFDECAL_OT_slot_clear,
    SURFDECAL_OT_shared_wear_add,
    SURFDECAL_OT_shared_wear_remove,
    SURFDECAL_OT_wear_apply,
    SURFDECAL_OT_wear_remove,
    SURFDECAL_OT_slot_preview,
    SURFDECAL_OT_wear_preview,
    SURFDECAL_OT_match_roughness,
    SURFDECAL_OT_match_clear,
    SURFDECAL_OT_apply_target_transform,
    SURFDECAL_OT_open_image_tracer,
    SURFDECAL_OT_lib_refresh,
    SURFDECAL_OT_lib_collect,
    SURFDECAL_OT_lib_remove,
    SURFDECAL_OT_lib_place,
    SURFDECAL_Prefs,
    SURFDECAL_PT_main,
    SURFDECAL_PT_import,
    SURFDECAL_PT_place,
    SURFDECAL_PT_generation,
    SURFDECAL_PT_selected,
    SURFDECAL_PT_match,
    SURFDECAL_PT_wrap,
    SURFDECAL_PT_maps,
    SURFDECAL_PT_wear,
    SURFDECAL_PT_shared_wear,
    SURFDECAL_PT_edge,
    SURFDECAL_PT_relief,
    SURFDECAL_PT_cutout,
    SURFDECAL_PT_advanced,
)


def _register_impl(transaction):
    global _lib_previews
    previous_previews = _lib_previews
    created_previews = bpy.utils.previews.new()
    _lib_previews = created_previews
    registered_classes = []
    try:
        for c in classes:
            bpy.utils.register_class(c)
            registered_classes.append(c)
    except Exception:              # 边界: 注册失败必须全捕获并回滚, 否则半注册
        for c in reversed(registered_classes):
            try:
                bpy.utils.unregister_class(c)
            except RuntimeError:
                pass
        try:
            bpy.utils.previews.remove(created_previews)
        except RuntimeError:
            pass
        _lib_previews = previous_previews
        raise
    transaction["owns_registration"] = True
    bpy.types.Scene.surfdecal = bpy.props.PointerProperty(type=SD_Props)
    bpy.types.Scene.surfdecal_shared_wear_groups = bpy.props.CollectionProperty(
        type=SD_SharedWearGroup)
    bpy.types.Scene.surfdecal_shared_wear_index = bpy.props.IntProperty(
        name="共享磨损索引", default=0, min=0)
    bpy.types.Object.surfdecal_wear_map = bpy.props.PointerProperty(
        name="磨损贴图", type=bpy.types.Image,
        description="旧版目标磨损贴图，仅供迁移到当前材质磨损槽")
    bpy.types.Material.sd_wear_weight = bpy.props.FloatProperty(
        name="磨损强度", default=0.5, min=0.0, max=1.0,
        description="本槽磨损并入总损伤的比重。0=完全不显示磨损",
        update=_bridge_update)
    bpy.types.Material.sd_shared_wear_enabled = bpy.props.BoolProperty(
        name="启用共享磨损", default=False,
        description="与局部磨损并存，按并集共同侵蚀贴花",
        update=_shared_material_update)
    bpy.types.Material.sd_shared_wear_group = bpy.props.EnumProperty(
        name="共享组", items=_shared_group_items,
        description="绑定一个保存在当前 .blend 中的共享磨损组",
        update=_shared_material_update)
    bpy.types.Material.sd_shared_wear_weight = bpy.props.FloatProperty(
        name="共享磨损强度", default=0.5, min=0.0, max=1.0,
        description="共享磨损并入总损伤的比重。0=完全不显示",
        update=_bridge_update)
    bpy.types.Material.sd_wear_threshold = bpy.props.FloatProperty(
        name="阈值", default=0.5, min=0.0, max=1.0, update=_slot_update)
    bpy.types.Material.sd_wear_softness = bpy.props.FloatProperty(
        name="过渡宽度", default=0.25, min=0.01, max=1.0, update=_slot_update)
    bpy.types.Material.sd_wear_invert = bpy.props.BoolProperty(
        name="反相", default=False,
        description="本槽约定: 白=磨损最强。你的图相反(白=完好)时勾上",
        update=_slot_update)
    bpy.types.Material.sd_surface_mode = bpy.props.EnumProperty(
        name="表面模式", items=SURFACE_MODE_ITEMS, default='STICKER',
        description="贴纸=贴花材质主导; 印刷/信息=目标材质作底层, 贴花当油墨",
        update=_bridge_update)
    bpy.types.Material.sd_ink_strength = bpy.props.FloatProperty(
        name="油墨强度", default=1.0, min=0.0, max=1.0,
        description="印刷模式下图案对底色的覆盖强度", update=_bridge_update)
    bpy.types.Material.sd_bridge_preview = bpy.props.EnumProperty(
        name="预览",
        items=[
            ('FINAL', "最终效果", "显示合成后的贴花"),
            ('WEAR', "局部磨损", "只预览当前材质的局部磨损场"),
            ('SHARED', "共享磨损", "预览共享组影响的全部贴花"),
            ('EDGE', "边缘磨损", "预览边缘磨损场"),
            ('NORMAL', "法线贴图", "预览表面桥接的最终法线"),
        ],
        default='FINAL', update=_bridge_preview_update)
    # --- Wear 槽 ---
    bpy.types.Material.sd_wear_image = bpy.props.PointerProperty(
        name="磨损贴图", type=bpy.types.Image,
        description="黑=无磨损, 白=磨损最强。指定后自动建链",
        update=_wear_img_update)
    bpy.types.Material.sd_wear_uv_space = bpy.props.EnumProperty(
        name="UV空间", items=UVSPACE_ITEMS, default='DECAL',
        update=_wear_img_update)
    bpy.types.Material.sd_wear_channel = bpy.props.EnumProperty(
        name="通道", items=CH_ITEMS, default='LUM', update=_wear_img_update)
    bpy.types.Material.sd_wear_map_location = bpy.props.FloatVectorProperty(
        name="位置", size=2, default=(0.0, 0.0), subtype='XYZ',
        update=_slot_update)
    bpy.types.Material.sd_wear_map_rotation = bpy.props.FloatProperty(
        name="旋转", subtype='ANGLE', default=0.0, update=_slot_update)
    bpy.types.Material.sd_wear_map_scale = bpy.props.FloatVectorProperty(
        name="图案大小", size=2, default=(1.0, 1.0), min=0.001,
        soft_max=20.0, update=_slot_update)
    bpy.types.Material.sd_cutout_range = bpy.props.FloatProperty(
        name="侵蚀范围", default=0.5, min=0.0, max=1.0,
        description="有多少面积被完全侵蚀并直接露出目标表面。"
                    "它控制面积, 不是把贴花整体变半透明",
        update=_bridge_update)
    bpy.types.Material.sd_cutout_hardness = bpy.props.FloatProperty(
        name="断裂硬度", default=0.7, min=0.0, max=1.0,
        description="灰度遮罩转成0/1缺口的锐利程度; 越高边界越硬",
        update=_bridge_update)
    bpy.types.Material.sd_cutout_feather = bpy.props.FloatProperty(
        name="边缘过渡", default=0.08, min=0.0, max=0.5,
        description="只控制缺口边缘的窄羽化带(抗锯齿用)",
        update=_bridge_update)
    bpy.types.Material.sd_residue_on = bpy.props.BoolProperty(
        name="残留污渍", default=False,
        description="仅作用于仍存在的贴花碎片; 完全掉落处不叠加深色",
        update=_bridge_update)
    bpy.types.Material.sd_residue_color = bpy.props.FloatVectorProperty(
        name="残留颜色", subtype='COLOR', size=3, min=0.0, max=1.0,
        default=(0.18, 0.16, 0.13), update=_bridge_update)
    bpy.types.Material.sd_residue_amount = bpy.props.FloatProperty(
        name="残留强度", default=0.5, min=0.0, max=1.0,
        update=_bridge_update)
    bpy.types.Material.sd_residue_rough = bpy.props.FloatProperty(
        name="残留粗糙度", default=0.2, min=-1.0, max=1.0,
        update=_bridge_update)
    bpy.types.Material.sd_fade_mode = bpy.props.BoolProperty(
        name="半透明淡化(高级)", default=False,
        description="让损伤区整体变半透明 —— 通常不需要, 默认关闭",
        update=_bridge_update)
    bpy.types.Material.sd_fade_amount = bpy.props.FloatProperty(
        name="淡化强度", default=0.3, min=0.0, max=1.0,
        update=_bridge_update)
    # --- Edge 槽 ---
    bpy.types.Material.sd_edge_image = bpy.props.PointerProperty(
        name="边缘贴图", type=bpy.types.Image,
        description="黑=边缘保留, 白=边缘损伤最强。指定后自动建链",
        update=_edge_img_update)
    bpy.types.Material.sd_edge_channel = bpy.props.EnumProperty(
        name="通道", items=CH_ITEMS, default='LUM', update=_edge_img_update)
    bpy.types.Material.sd_edge_invert = bpy.props.BoolProperty(
        name="反相", default=False, update=_slot_update)
    bpy.types.Material.sd_edge_threshold = bpy.props.FloatProperty(
        name="阈值", default=0.5, min=0.0, max=1.0, update=_slot_update)
    bpy.types.Material.sd_edge_softness = bpy.props.FloatProperty(
        name="过渡宽度", default=0.25, min=0.005, max=1.0,
        update=_slot_update)
    bpy.types.Material.sd_edge_width = bpy.props.FloatProperty(
        name="边缘宽度", default=0.02, min=0.0001, soft_max=0.5,
        subtype='DISTANCE',
        description="用户贴图受目标几何边缘限制时的空间衰减宽度",
        update=_edge_img_update)
    bpy.types.Material.sd_edge_angle = bpy.props.FloatProperty(
        name="曲率/硬边阈值", subtype='ANGLE', default=math.radians(8.0),
        min=0.0, max=math.pi,
        description="相邻面夹角超过该值才算边缘；提高可只保留更硬的折角",
        update=_edge_img_update)
    bpy.types.Material.sd_edge_weight = bpy.props.FloatProperty(
        name="边缘磨损强度", default=0.5, min=0.0, max=1.0,
        description="边缘损伤场并入总损伤的比重; 0=不参与",
        update=_edge_weight_update)
    bpy.types.Material.sd_edge_map_location = bpy.props.FloatVectorProperty(
        name="位置", size=2, default=(0.0, 0.0), subtype='XYZ',
        update=_slot_update)
    bpy.types.Material.sd_edge_map_rotation = bpy.props.FloatProperty(
        name="旋转", subtype='ANGLE', default=0.0, update=_slot_update)
    bpy.types.Material.sd_edge_map_scale = bpy.props.FloatVectorProperty(
        name="图案大小", size=2, default=(1.0, 1.0), min=0.001,
        soft_max=20.0, update=_slot_update)
    bpy.types.Material.sd_relief_normal = bpy.props.PointerProperty(
        name="法线贴图", type=bpy.types.Image,
        description="贴花自带的法线贴图, 用贴花自身UV采样。指定后自动建链",
        update=_relief_img_update)
    bpy.types.Material.sd_relief_normal_strength = bpy.props.FloatProperty(
        name="法线强度", default=1.0, min=0.0, max=4.0, update=_relief_update)
    bpy.types.Material.sd_relief_height = bpy.props.PointerProperty(
        name="高度贴图", type=bpy.types.Image,
        description="灰度高度图, Cycles下走真实Bump —— 凸起铭牌/蚀刻编号。"
                    "指定后自动建链",
        update=_relief_img_update)
    bpy.types.Material.sd_relief_height_distance = bpy.props.FloatProperty(
        name="凸起高度", default=0.002, min=0.0, max=0.1, precision=4,
        subtype='DISTANCE', update=_relief_update)
    bpy.types.Material.sd_relief_height_strength = bpy.props.FloatProperty(
        name="凹凸强度", default=1.0, min=0.0, max=2.0, update=_relief_update)
    bpy.types.Material.sd_relief_map_location = bpy.props.FloatVectorProperty(
        name="位置", size=2, default=(0.0, 0.0), subtype='XYZ',
        update=_relief_update)
    bpy.types.Material.sd_relief_map_rotation = bpy.props.FloatProperty(
        name="旋转", subtype='ANGLE', default=0.0, update=_relief_update)
    bpy.types.Material.sd_relief_map_scale = bpy.props.FloatVectorProperty(
        name="图案大小", size=2, default=(1.0, 1.0), min=0.001,
        soft_max=20.0, update=_relief_update)
    bpy.types.Object.surfdecal_scale = bpy.props.FloatProperty(
        name="贴花缩放", default=1.0, min=0.01,
        soft_min=0.25, soft_max=8.0,
        description="该贴花的累计缩放, 逐张独立记录(作用于网格本体)",
        update=_decal_scale_update)
    if _upgrade_loaded_bridges not in bpy.app.handlers.load_post:
        bpy.app.handlers.load_post.append(_upgrade_loaded_bridges)
    if not bpy.app.timers.is_registered(_deferred_upgrade_loaded_bridges):
        bpy.app.timers.register(_deferred_upgrade_loaded_bridges,
                                first_interval=0.1)


def register():
    """Register atomically so a failed enable leaves no partial add-on state."""
    transaction = {"owns_registration": False}
    try:
        _register_impl(transaction)
    except Exception:              # 边界: 同上, 回滚后原样抛给 Blender
        if transaction["owns_registration"]:
            try:
                unregister()
            except Exception as rollback_error:   # 边界: 回滚已是最后手段
                print("[SurfDecal] 注册回滚失败: %s" % rollback_error)
        raise


def _remove_rna_property(owner, name):
    """删除可能只注册了一半的 RNA 属性；重复调用也安全。"""
    if hasattr(owner, name):
        delattr(owner, name)


def _unregister_class_if_needed(cls):
    """部分注册失败后，跳过 Blender 已经卸载过的类。"""
    # _RNAMeta 会从基类解析 bl_rna，getattr/hasattr 在已卸载类上会误判；
    # 只有类自身字典里的 bl_rna 才代表本类仍由 Blender 注册。
    if "bl_rna" not in cls.__dict__:
        return
    bpy.utils.unregister_class(cls)


def unregister():
    global _lib_previews, _lib_items
    if _upgrade_loaded_bridges in bpy.app.handlers.load_post:
        bpy.app.handlers.load_post.remove(_upgrade_loaded_bridges)
    if bpy.app.timers.is_registered(_deferred_place):
        bpy.app.timers.unregister(_deferred_place)
    if bpy.app.timers.is_registered(_deferred_upgrade_loaded_bridges):
        bpy.app.timers.unregister(_deferred_upgrade_loaded_bridges)
    if _lib_previews is not None:
        bpy.utils.previews.remove(_lib_previews)
        _lib_previews = None
    _lib_items = []
    _remove_rna_property(bpy.types.Object, "surfdecal_wear_map")
    for attr in ("sd_wear_threshold", "sd_wear_softness", "sd_wear_invert",
                 "sd_relief_normal", "sd_relief_normal_strength",
                 "sd_relief_height", "sd_relief_height_distance",
                 "sd_relief_height_strength", "sd_relief_map_location",
                 "sd_relief_map_rotation", "sd_relief_map_scale",
                 "sd_surface_mode", "sd_ink_strength", "sd_bridge_preview",
                 "sd_wear_image", "sd_wear_uv_space", "sd_wear_channel",
                 "sd_wear_map_location", "sd_wear_map_rotation",
                 "sd_wear_map_scale",
                 "sd_wear_weight", "sd_shared_wear_enabled",
                 "sd_shared_wear_group", "sd_shared_wear_weight",
                 "sd_cutout_range", "sd_cutout_hardness",
                 "sd_cutout_feather", "sd_residue_on", "sd_residue_color",
                 "sd_residue_amount", "sd_residue_rough",
                 "sd_fade_mode", "sd_fade_amount",
                 "sd_edge_image", "sd_edge_channel",
                 "sd_edge_invert", "sd_edge_threshold", "sd_edge_softness",
                 "sd_edge_width", "sd_edge_angle", "sd_edge_weight", "sd_edge_map_location",
                 "sd_edge_map_rotation", "sd_edge_map_scale"):
        _remove_rna_property(bpy.types.Material, attr)
    _remove_rna_property(bpy.types.Object, "surfdecal_scale")
    _remove_rna_property(bpy.types.Scene, "surfdecal_shared_wear_index")
    _remove_rna_property(bpy.types.Scene, "surfdecal_shared_wear_groups")
    _remove_rna_property(bpy.types.Scene, "surfdecal")
    for c in reversed(classes):
        _unregister_class_if_needed(c)


if __name__ == "__main__":
    register()
